# Webserv - HTTP Server Implementation

![42 Badge](https://img.shields.io/badge/42-webserv-blue)
![C++98](https://img.shields.io/badge/C%2B%2B-98-brightgreen)
![Status](https://img.shields.io/badge/Status-Complete-success)

> HTTP/1.1 server implementation in C++98 for 42 School

**Author:** fcela-ga@student.42barcelona.com

---

## 📋 Table of Contents

- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Usage](#usage)
- [Configuration](#configuration)
- [Testing](#testing)
- [Project Structure](#project-structure)
- [Evaluation Checklist](#evaluation-checklist)

---

## ✨ Features

### Mandatory
- ✅ Non-blocking I/O with single `poll()` for all operations
- ✅ GET, POST, DELETE methods
- ✅ Static file serving
- ✅ CGI execution (Python, PHP, Perl)
- ✅ File uploads (multipart/form-data)
- ✅ Directory listing (autoindex)
- ✅ Custom error pages
- ✅ HTTP redirections (301, 302)
- ✅ Multiple virtual hosts
- ✅ Multiple ports
- ✅ Client body size limits
- ✅ Request timeouts
- ✅ Chunked transfer encoding

### Bonus
- ✅ Cookies support
- ✅ Session management
- ✅ Multiple CGI types (Python, PHP, Perl, Shell)

---

## 📦 Requirements

### Development
- C++98 compatible compiler (g++, clang++)
- Make
- POSIX-compatible OS (Linux, macOS)

### CGI Support
- Python 3
- PHP-CGI (optional)
- Perl (optional)

### Testing
- curl
- siege (stress testing)
- netcat/telnet
- valgrind (memory leak detection)

---

## 🚀 Installation

### Local Build
```bash
git clone <repository>
cd webserv
make
```

### Docker Build
```bash
cd docker
docker-compose up --build
```

### Alpine Linux (Manual)
```bash
apk add g++ make python3 curl siege valgrind
make
```

---

## 💻 Usage

### Start Server
```bash
./webserv [config_file]

# Default configuration
./webserv config/webserv.conf
```

### Access Server
- Main server: http://localhost:8080
- Secondary server: http://localhost:8081
- Restricted server: http://localhost:8082

### Stop Server
Press `Ctrl+C` to gracefully shutdown.

---

## ⚙️ Configuration

### Configuration File Syntax

```nginx
server {
    listen 0.0.0.0:8080;
    server_name localhost example.local;
    root ./www;
    index index.html;
    client_max_body_size 1048576;
    autoindex on;
    
    error_page 404 /errors/404.html;
    error_page 500 502 503 504 /errors/50x.html;
    
    location / {
        methods GET POST;
        autoindex on;
    }
    
    location /upload {
        methods GET POST DELETE;
        upload_store ./www/uploads;
    }
    
    location /cgi-bin {
        methods GET POST;
        root ./cgi-bin;
        cgi .py /usr/bin/python3;
        cgi .php /usr/bin/php-cgi;
    }
    
    location /redirect {
        redirect 301 /;
    }
}
```

### Directives

| Directive | Description |
|-----------|-------------|
| `listen` | IP:port to listen on |
| `server_name` | Virtual host names |
| `root` | Document root directory |
| `index` | Default index file(s) |
| `client_max_body_size` | Maximum request body size |
| `autoindex` | Enable directory listing |
| `error_page` | Custom error page paths |
| `methods` | Allowed HTTP methods |
| `upload_store` | Upload destination directory |
| `cgi` | CGI handler (extension + interpreter) |
| `redirect` | HTTP redirection |

---

## 🧪 Testing

### Automated Tests
```bash
./tests/test.sh
```

### Stress Testing (Siege)
```bash
./tests/siege_test.sh

# Manual siege
siege -b -c 50 -t 30s http://localhost:8080/
```

### Memory Leak Check
```bash
valgrind --leak-check=full ./webserv config/webserv.conf
```

### Manual Tests

#### GET Request
```bash
curl http://localhost:8080/
curl -I http://localhost:8080/  # Headers only
```

#### POST Request
```bash
curl -X POST -d "name=test&email=test@test.com" http://localhost:8080/cgi-bin/test.py
```

#### DELETE Request
```bash
curl -X DELETE http://localhost:8080/deletable/test.txt
```

#### File Upload
```bash
curl -X POST -F "file=@/path/to/file.txt" http://localhost:8080/upload
```

#### Virtual Host
```bash
curl --resolve example.local:8080:127.0.0.1 http://example.local:8080/
```

### Official Testers
```bash
# Alpine tester
./tester
./cgi_tester

# Ubuntu tester
./ubuntu_tester
./ubuntu_cgi_tester
```

---

## 📁 Project Structure

```
webserv/
├── Makefile              # Build configuration
├── Dockerfile            # Docker image definition
├── config/
│   └── webserv.conf      # Server configuration
├── includes/
│   ├── webserv.hpp       # Main header with all includes
│   ├── Server.hpp        # Server class definition
│   ├── Client.hpp        # Client connection management
│   ├── Request.hpp       # HTTP request parsing
│   ├── Response.hpp      # HTTP response building
│   ├── Config.hpp        # Configuration file parsing
│   ├── ServerConfig.hpp  # Server block configuration
│   ├── LocationConfig.hpp# Location block configuration
│   ├── CGIHandler.hpp    # CGI execution handler
│   ├── SessionManager.hpp# Session management (bonus)
│   ├── MimeTypes.hpp     # MIME type mappings
│   └── Utils.hpp         # Utility functions
├── srcs/
│   ├── main.cpp          # Entry point
│   ├── Server.cpp        # Server implementation (~1200 lines)
│   ├── Client.cpp        # Client implementation
│   ├── Request.cpp       # Request parsing
│   ├── Response.cpp      # Response building
│   ├── Config.cpp        # Configuration parsing
│   ├── ServerConfig.cpp  # Server config
│   ├── LocationConfig.cpp# Location config
│   ├── CGIHandler.cpp    # CGI handler
│   ├── SessionManager.cpp# Session management
│   ├── MimeTypes.cpp     # MIME types
│   └── Utils.cpp         # Utilities
├── www/
│   ├── index.html        # Main page
│   ├── errors/           # Custom error pages
│   ├── uploads/          # Upload directory
│   ├── static/           # Static assets
│   ├── secondary/        # Secondary server content
│   ├── restricted/       # Restricted area content
│   └── example/          # Virtual host content
├── cgi-bin/
│   ├── test.py           # Python CGI test
│   ├── info.py           # System info CGI
│   ├── session.py        # Session demo CGI
│   └── upload.py         # Upload handler CGI
├── tests/
│   ├── test.sh           # Automated test suite
│   └── siege_test.sh     # Stress testing script
└── docker/
    ├── Dockerfile        # Docker build file
    └── docker-compose.yml# Docker compose config
```

---

## ✅ Evaluation Checklist

### Compilation
- [x] Compiles with `-Wall -Wextra -Werror -std=c++98`
- [x] No relinking issues
- [x] Makefile with all, clean, fclean, re rules

### I/O Multiplexing
- [x] Single `poll()` for all I/O operations
- [x] Non-blocking sockets
- [x] No read/write without poll readiness
- [x] No errno checking after read/write

### HTTP Methods
- [x] GET method working
- [x] POST method working
- [x] DELETE method working
- [x] Unknown methods return 501

### Configuration
- [x] Multiple servers on different ports
- [x] Multiple servers on same port (virtual hosts)
- [x] Custom error pages
- [x] Client body size limits
- [x] Route-specific configuration
- [x] Directory listing toggle
- [x] Default index files
- [x] HTTP redirections

### CGI
- [x] CGI execution with GET
- [x] CGI execution with POST
- [x] Correct directory for CGI execution
- [x] Environment variables set correctly
- [x] Multiple CGI types (Python, PHP, Perl)

### Files
- [x] Static file serving
- [x] File uploads
- [x] Correct MIME types

### Stress Testing
- [x] Works with siege
- [x] Availability > 99.5%
- [x] No memory leaks
- [x] No hanging connections

### Bonus
- [x] Cookies support
- [x] Session management
- [x] Multiple CGI types

---

## 📝 License

This project is part of the 42 School curriculum.

---

## 🙏 Acknowledgments

- 42 Barcelona
- nginx (configuration inspiration)
- RFC 2616 (HTTP/1.1 specification)
