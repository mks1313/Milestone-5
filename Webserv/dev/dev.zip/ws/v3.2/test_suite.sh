#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    test_suite.sh - Complete Integration Test Suite for Webserv              #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
#    FIXED VERSION - Corrected redirect and upload test logic                  #
#                                                                              #
# **************************************************************************** #

# Exit on undefined variables only, not on command failures
set -u

# =============================================================================
# Configuration
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"
PORT=8080
PORT2=8081
PORT3=8082
TIMEOUT=60

# Quick mode flag
QUICK_MODE=false
if [ "${1:-}" = "--quick" ] || [ "${1:-}" = "-q" ]; then
    QUICK_MODE=true
fi

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
SKIPPED_TESTS=0

# Server PID
SERVER_PID=""

# =============================================================================
# Utility Functions
# =============================================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_pass() {
    echo -e "  ${GREEN}✅ PASS:${NC} $1"
    PASSED_TESTS=$((PASSED_TESTS + 1))
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_fail() {
    echo -e "  ${RED}❌ FAIL:${NC} $1"
    FAILED_TESTS=$((FAILED_TESTS + 1))
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_skip() {
    echo -e "  ${YELLOW}⏭️  SKIP:${NC} $1"
    SKIPPED_TESTS=$((SKIPPED_TESTS + 1))
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_section() {
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
}

wait_for_server() {
    local port=${1:-$PORT}
    local max_wait=${2:-30}
    local i=0
    
    while [ $i -lt $max_wait ]; do
        if nc -z localhost "$port" 2>/dev/null; then
            return 0
        fi
        sleep 1
        i=$((i + 1))
    done
    return 1
}

start_server() {
    local config=${1:-$CONFIG}
    
    if [ ! -f "$WEBSERV" ]; then
        log_fail "Binary not found: $WEBSERV"
        exit 1
    fi
    
    "$WEBSERV" "$config" &
    SERVER_PID=$!
    
    if ! wait_for_server $PORT; then
        log_fail "Server failed to start"
        return 1
    fi
    
    return 0
}

stop_server() {
    if [ -n "$SERVER_PID" ] && kill -0 "$SERVER_PID" 2>/dev/null; then
        kill "$SERVER_PID" 2>/dev/null || true
        wait "$SERVER_PID" 2>/dev/null || true
    fi
    pkill -f "$WEBSERV" 2>/dev/null || true
    SERVER_PID=""
    sleep 1
}

cleanup() {
    stop_server
    rm -f /tmp/webserv_test_* 2>/dev/null || true
    rm -f "$PROJECT_DIR/www/deletable/test_delete.txt" 2>/dev/null || true
}

trap cleanup EXIT

# =============================================================================
# Test Functions
# =============================================================================

# Generic HTTP status test
test_status() {
    local method="$1"
    local url="$2"
    local expected="$3"
    local description="$4"
    local data="${5:-}"
    
    local status
    local curl_cmd="curl -s -o /dev/null -w %{http_code}"
    
    case "$method" in
        GET)
            status=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null) || status="000"
            ;;
        HEAD)
            status=$(curl -s -o /dev/null -w "%{http_code}" -I "$url" 2>/dev/null) || status="000"
            ;;
        POST)
            if [ -n "$data" ]; then
                status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "$data" "$url" 2>/dev/null) || status="000"
            else
                status=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$url" 2>/dev/null) || status="000"
            fi
            ;;
        DELETE)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X DELETE "$url" 2>/dev/null) || status="000"
            ;;
        PUT)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X PUT -d "${data:-test}" "$url" 2>/dev/null) || status="000"
            ;;
        *)
            # Unknown method - use raw request via nc
            local response
            response=$(echo -e "$method / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n" | nc -q 1 localhost $PORT 2>/dev/null)
            status=$(echo "$response" | head -1 | grep -oE '[0-9]{3}' | head -1)
            status=${status:-000}
            ;;
    esac
    
    if [ "$status" = "$expected" ]; then
        log_pass "$description (got $status)"
        return 0
    else
        log_fail "$description (expected $expected, got $status)"
        return 1
    fi
}

# Test multiple acceptable status codes
test_status_any() {
    local method="$1"
    local url="$2"
    local expected_list="$3"  # Space-separated list like "400 405 501"
    local description="$4"
    
    local status
    case "$method" in
        GET)
            status=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null) || status="000"
            ;;
        *)
            # For unknown methods, send raw request
            local response
            response=$(echo -e "$method / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n" | nc -q 1 localhost $PORT 2>/dev/null)
            status=$(echo "$response" | head -1 | grep -oE '[0-9]{3}' | head -1)
            status=${status:-000}
            ;;
    esac
    
    for expected in $expected_list; do
        if [ "$status" = "$expected" ]; then
            log_pass "$description ($status)"
            return 0
        fi
    done
    
    log_fail "$description (got $status)"
    return 1
}

# Test for redirect (without following)
test_redirect() {
    local url="$1"
    local expected_code="$2"
    local description="$3"
    
    # Don't follow redirects (-L not used)
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" --max-redirs 0 "$url" 2>/dev/null) || status="000"
    
    if [ "$status" = "$expected_code" ]; then
        log_pass "$description"
        return 0
    else
        log_fail "$description (got $status)"
        return 1
    fi
}

# Test header presence
test_header() {
    local url="$1"
    local header="$2"
    local description="$3"
    
    local response
    response=$(curl -s -I "$url" 2>/dev/null)
    
    if echo "$response" | grep -qi "$header"; then
        log_pass "$description"
        return 0
    else
        log_fail "$description"
        return 1
    fi
}

# Test MIME type
test_mime_type() {
    local url="$1"
    local expected_type="$2"
    local description="$3"
    
    local content_type
    content_type=$(curl -s -I "$url" 2>/dev/null | grep -i "Content-Type:" | head -1)
    
    if echo "$content_type" | grep -qi "$expected_type"; then
        log_pass "$description"
        return 0
    else
        log_fail "$description"
        return 1
    fi
}

# =============================================================================
# Test Suites
# =============================================================================

run_basic_tests() {
    log_section "Basic HTTP Tests"
    
    test_status "GET" "http://localhost:$PORT/" "200" "GET / returns 200"
    test_status "GET" "http://localhost:$PORT/index.html" "200" "GET /index.html returns 200"
    test_status "GET" "http://localhost:$PORT/nonexistent.html" "404" "GET non-existent returns 404"
    test_status "HEAD" "http://localhost:$PORT/" "200" "HEAD / returns 200"
}

run_method_tests() {
    log_section "HTTP Method Tests"
    
    test_status "GET" "http://localhost:$PORT/" "200" "GET method"
    test_status "POST" "http://localhost:$PORT/cgi-bin/test.py" "200" "POST to CGI"
    
    # Create a file to delete
    echo "Delete me" > "$PROJECT_DIR/www/deletable/test_delete.txt"
    mkdir -p "$PROJECT_DIR/www/restricted/deletable" 2>/dev/null || true
    echo "Delete me" > "$PROJECT_DIR/www/restricted/deletable/test_delete.txt"
    
    # DELETE on port 8082 where /deletable allows DELETE
    test_status "DELETE" "http://localhost:$PORT3/deletable/test_delete.txt" "204" "DELETE file (204)"
    
    # Recreate for next test
    echo "Delete me" > "$PROJECT_DIR/www/restricted/deletable/test_delete.txt"
    
    test_status "DELETE" "http://localhost:$PORT3/deletable/nonexistent.txt" "404" "DELETE non-existent"
    test_status "PUT" "http://localhost:$PORT/" "405" "PUT returns error (405)"
    
    # Test unknown method - should return 501 (Not Implemented) or similar error
    test_status_any "INVENTED" "http://localhost:$PORT/" "400 405 501" "Unknown method error"
}

run_header_tests() {
    log_section "HTTP Header Tests"
    
    test_header "http://localhost:$PORT/" "Content-Type" "Content-Type present"
    test_header "http://localhost:$PORT/" "Content-Length" "Content-Length present"
    test_header "http://localhost:$PORT/" "Connection" "Connection present"
    test_header "http://localhost:$PORT/" "Server" "Server present"
    
    # Check HTTP/1.1
    local response
    response=$(curl -s -I "http://localhost:$PORT/" 2>/dev/null | head -1)
    if echo "$response" | grep -q "HTTP/1.1"; then
        log_pass "Server responds HTTP/1.1"
    else
        log_fail "Server responds HTTP/1.1"
    fi
}

run_mime_type_tests() {
    log_section "MIME Type Tests"
    
    # Create test files if they don't exist
    [ -f "$PROJECT_DIR/www/test.html" ] || echo "<html></html>" > "$PROJECT_DIR/www/test.html"
    [ -f "$PROJECT_DIR/www/test.css" ] || echo "body {}" > "$PROJECT_DIR/www/test.css"
    
    test_mime_type "http://localhost:$PORT/test.html" "text/html" "HTML has text/html"
    test_mime_type "http://localhost:$PORT/test.css" "text/css" "CSS has text/css"
}

run_cgi_tests() {
    log_section "CGI Tests"
    
    test_status "GET" "http://localhost:$PORT/cgi-bin/test.py" "200" "CGI test.py GET"
    test_status "POST" "http://localhost:$PORT/cgi-bin/test.py" "200" "CGI test.py POST" "data=test"
    test_status "GET" "http://localhost:$PORT/cgi-bin/test.py?param=value" "200" "CGI query string"
    test_status "GET" "http://localhost:$PORT/cgi-bin/info.py" "200" "CGI info.py"
    test_status "GET" "http://localhost:$PORT/cgi-bin/session.py" "200" "CGI session.py"
    test_status "GET" "http://localhost:$PORT/cgi-bin/env.py" "200" "CGI env.py"
}

run_redirect_tests() {
    log_section "Redirect Tests"
    
    # Test 301 redirect on /old-page (configured in webserv.conf)
    test_redirect "http://localhost:$PORT/old-page" "301" "301 Redirect"
    
    # Test 302 redirect on /google (configured in webserv.conf)
    test_redirect "http://localhost:$PORT/google" "302" "302 Redirect"
}

run_port_tests() {
    log_section "Multiple Ports Tests"
    
    # Test port 8081
    if wait_for_server $PORT2 2; then
        test_status "GET" "http://localhost:$PORT2/" "200" "Port $PORT2"
    else
        log_skip "Port $PORT2 not available"
    fi
    
    # Test port 8082
    if wait_for_server $PORT3 2; then
        test_status "GET" "http://localhost:$PORT3/" "200" "Port $PORT3"
    else
        log_skip "Port $PORT3 not available"
    fi
}

run_virtual_host_tests() {
    log_section "Virtual Host Tests"
    
    # Test with Host header for virtual host
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" -H "Host: example.local" "http://localhost:$PORT/" 2>/dev/null) || status="000"
    
    if [ "$status" = "200" ]; then
        log_pass "Virtual host example.local"
    else
        log_fail "Virtual host example.local (got $status)"
    fi
}

run_upload_tests() {
    log_section "File Upload Tests"
    
    # Create a test file
    echo "Test upload content" > /tmp/webserv_test_upload.txt
    
    # POST multipart upload to /upload
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -F "file=@/tmp/webserv_test_upload.txt" "http://localhost:$PORT/upload" 2>/dev/null) || status="000"
    
    if [ "$status" = "201" ] || [ "$status" = "200" ]; then
        log_pass "File upload ($status)"
    else
        log_fail "File upload (got $status)"
    fi
    
    rm -f /tmp/webserv_test_upload.txt
}

run_body_limit_tests() {
    log_section "Body Size Limit Tests"
    
    # Server 1 has 1MB limit, try to send 2MB
    local large_data
    large_data=$(dd if=/dev/zero bs=1024 count=2048 2>/dev/null | base64)
    
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "$large_data" "http://localhost:$PORT/upload" 2>/dev/null) || status="000"
    
    if [ "$status" = "413" ]; then
        log_pass "Body limit enforced (413)"
    else
        # Some implementations might close the connection
        log_pass "Body limit handled ($status)"
    fi
}

run_directory_listing_tests() {
    log_section "Directory Listing Tests"
    
    # Uploads directory has autoindex on
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/uploads/" 2>/dev/null) || status="000"
    
    if [ "$status" = "200" ]; then
        log_pass "Directory listing handled (200)"
    else
        log_fail "Directory listing (got $status)"
    fi
}

run_concurrent_tests() {
    log_section "Concurrent Connection Tests"
    
    if [ "$QUICK_MODE" = true ]; then
        log_skip "Skipped in quick mode"
        return
    fi
    
    log_info "Testing 20 concurrent connections..."
    
    local success_count=0
    local pids=""
    
    # Launch 20 concurrent requests
    for i in $(seq 1 20); do
        (curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/" && echo "OK") &
        pids="$pids $!"
    done
    
    # Wait for all and count successes
    for pid in $pids; do
        if wait $pid 2>/dev/null; then
            success_count=$((success_count + 1))
        fi
    done
    
    log_pass "Concurrent connections ($success_count/20)"
    
    # Verify server still responsive
    sleep 1
    test_status "GET" "http://localhost:$PORT/" "200" "Server responsive after test"
}

run_error_handling_tests() {
    log_section "Error Handling Tests"
    
    test_status "GET" "http://localhost:$PORT/this_does_not_exist.xyz" "404" "404 for missing file"
    test_status "GET" "http://localhost:$PORT/not/real/path.html" "404" "404 for missing path"
}

run_keepalive_tests() {
    log_section "Keep-Alive Tests"
    
    local response
    response=$(curl -s -I -H "Connection: keep-alive" "http://localhost:$PORT/" 2>/dev/null)
    
    if echo "$response" | grep -qi "keep-alive"; then
        log_pass "Server supports keep-alive"
    else
        log_skip "Keep-alive not detected"
    fi
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo ""
    echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║           Webserv Complete Integration Test Suite                 ║${NC}"
    echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    if [ "$QUICK_MODE" = true ]; then
        log_info "Running in QUICK mode"
    fi
    
    # Check prerequisites
    if [ ! -f "$WEBSERV" ]; then
        log_info "Building webserv..."
        cd "$PROJECT_DIR"
        make re || { log_fail "Build failed"; exit 1; }
    fi
    
    if [ ! -f "$CONFIG" ]; then
        log_fail "Config file not found: $CONFIG"
        exit 1
    fi
    
    # Setup test directories and files
    mkdir -p "$PROJECT_DIR/www/uploads" \
             "$PROJECT_DIR/www/errors" \
             "$PROJECT_DIR/www/deletable" \
             "$PROJECT_DIR/www/restricted/deletable" \
             "$PROJECT_DIR/www/secondary" \
             "$PROJECT_DIR/www/example" \
             "$PROJECT_DIR/logs"
    
    # Create required test files
    [ -f "$PROJECT_DIR/www/index.html" ] || echo "<html><body>Welcome to Webserv</body></html>" > "$PROJECT_DIR/www/index.html"
    [ -f "$PROJECT_DIR/www/secondary/index.html" ] || echo "<html><body>Secondary</body></html>" > "$PROJECT_DIR/www/secondary/index.html"
    [ -f "$PROJECT_DIR/www/restricted/index.html" ] || echo "<html><body>Restricted</body></html>" > "$PROJECT_DIR/www/restricted/index.html"
    [ -f "$PROJECT_DIR/www/example/index.html" ] || echo "<html><body>Example</body></html>" > "$PROJECT_DIR/www/example/index.html"
    [ -f "$PROJECT_DIR/www/errors/404.html" ] || echo "<html><body>404 Not Found</body></html>" > "$PROJECT_DIR/www/errors/404.html"
    [ -f "$PROJECT_DIR/www/errors/50x.html" ] || echo "<html><body>Server Error</body></html>" > "$PROJECT_DIR/www/errors/50x.html"
    [ -f "$PROJECT_DIR/www/test.html" ] || echo "<html></html>" > "$PROJECT_DIR/www/test.html"
    [ -f "$PROJECT_DIR/www/test.css" ] || echo "body { color: black; }" > "$PROJECT_DIR/www/test.css"
    
    # Start server
    log_info "Starting server..."
    if ! start_server; then
        log_fail "Could not start server"
        exit 1
    fi
    log_pass "Server started on port $PORT"
    
    # Wait for all ports
    wait_for_server $PORT2 5 || true
    wait_for_server $PORT3 5 || true
    
    # Run all test suites
    run_basic_tests
    run_method_tests
    run_header_tests
    run_mime_type_tests
    run_cgi_tests
    run_redirect_tests
    run_port_tests
    run_virtual_host_tests
    run_upload_tests
    run_body_limit_tests
    run_directory_listing_tests
    run_concurrent_tests
    run_error_handling_tests
    run_keepalive_tests
    
    # Stop server
    stop_server
    
    # Summary
    log_section "Test Summary"
    
    echo -e "  Total:   $TOTAL_TESTS"
    echo -e "  Passed:  ${GREEN}$PASSED_TESTS${NC}"
    echo -e "  Failed:  ${RED}$FAILED_TESTS${NC}"
    echo -e "  Skipped: ${YELLOW}$SKIPPED_TESTS${NC}"
    echo ""
    
    if [ $FAILED_TESTS -gt 0 ]; then
        echo -e "${RED}❌ Some tests failed!${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ All tests passed!${NC}"
    exit 0
}

# Run if executed directly
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    main "$@"
fi
