# Webserv - Correcciones Completas para Tests

## Resumen de Cambios Necesarios

Hay **3 componentes** que necesitan corrección:

1. **Server.cpp** - 2 bugs en el servidor
2. **test_suite.sh** - Lógica incorrecta de tests  
3. **session.py** - Error de sintaxis en f-string (opcional)

---

## 1. Correcciones en Server.cpp

### Bug 1: HEAD devuelve 405 (debe devolver 200)

**Ubicación:** `src/Server.cpp`, función `_processRequest()`

**Buscar este código:**
```cpp
    // Check method allowed
    const std::string& method = request.getMethod();
    if (location != NULL && !location->isMethodAllowed(method))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }
```

**Reemplazar con:**
```cpp
    // Check method allowed
    const std::string& method = request.getMethod();
    // HEAD should be allowed wherever GET is allowed (HTTP/1.1 spec)
    std::string methodToCheck = method;
    if (method == "HEAD")
        methodToCheck = "GET";
    if (location != NULL && !location->isMethodAllowed(methodToCheck))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }
```

---

### Bug 2: Unknown method devuelve 000 (debe devolver 501)

**Ubicación:** `src/Server.cpp`, función `_handleClientRead()`

**Buscar este código:**
```cpp
    // Try to parse request
    Request& request = client.getRequest();
    if (request.parse(client.getReadBuffer()))
    {
        client.clearReadBuffer();
        
        if (request.isComplete())
        {
            client.setState(CLIENT_PROCESSING);
            _processRequest(client);
        }
        else if (request.hasError())
        {
            _sendErrorResponse(client, request.getErrorCode());
        }
    }
```

**Reemplazar con:**
```cpp
    // Try to parse request
    Request& request = client.getRequest();
    request.parse(client.getReadBuffer());

    // Check for parse errors FIRST (e.g., invalid method returns 501)
    if (request.hasError())
    {
        client.clearReadBuffer();
        _sendErrorResponse(client, request.getErrorCode());
        return;
    }

    // Check if request is complete
    if (request.isComplete())
    {
        client.clearReadBuffer();
        client.setState(CLIENT_PROCESSING);
        _processRequest(client);
    }
    // else: need more data, keep buffer for next read
```

---

## 2. Reemplazar test_suite.sh

El archivo `test_suite.sh` actual tiene bugs en la lógica de tests de redirect.
El nuevo archivo proporcionado (`test_suite.sh`) corrige:

- Lógica incorrecta de redirect tests (mostraba PASS, SKIP y FAIL para el mismo test)
- Tests de upload que se saltaban incorrectamente
- Mejor manejo de puertos múltiples
- Contadores de tests corregidos

**Ubicación:** `tests/test_suite.sh`

**Acción:** Reemplazar completamente el archivo con la versión proporcionada.

---

## 3. Corrección en session.py (Opcional)

El error en `cgi-bin/session.py` línea 200:

```
TypeError: unhashable type: 'dict'
```

**Problema:** El f-string usa `{{}}` que se interpreta incorrectamente.

**Ubicación:** `cgi-bin/session.py`, línea ~200

**Buscar código similar a:**
```python
sessions.get(session_id, {{}}).get('timestamp', time.time())
```

**Reemplazar con:**
```python
sessions.get(session_id, {}).get('timestamp', time.time())
```

**Nota:** Si está dentro de un f-string, necesitas extraer esa expresión fuera:

```python
# En vez de esto (dentro de f-string):
f"...{sessions.get(session_id, {{}}).get('timestamp', time.time())}..."

# Hacer esto:
session_data = sessions.get(session_id, {})
timestamp = session_data.get('timestamp', time.time())
f"...{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))}..."
```

---

## Aplicación Rápida

### Paso 1: Aplicar correcciones a Server.cpp

Abre `src/Server.cpp` y haz los dos cambios descritos arriba.

### Paso 2: Reemplazar test_suite.sh

```bash
cp test_suite.sh tests/test_suite.sh
chmod +x tests/test_suite.sh
```

### Paso 3: Recompilar y probar

```bash
make re
make test
```

---

## Resultado Esperado

```
═══════════════════════════════════════════════════════════════
  Test Summary
═══════════════════════════════════════════════════════════════
  Total:   ~40
  Passed:  ~38-40
  Failed:  0
  Skipped: 0-2

✅ All tests passed!
```

---

## Archivos Proporcionados

1. `test_suite.sh` - Script de tests corregido
2. `FIXES_README.md` - Este documento
3. `apply_fixes.py` - Script Python para aplicar los cambios a Server.cpp automáticamente

