# Webserv Docker Development Environment

## Filosofía

Esta configuración Docker separa completamente:
- **Imagen Docker**: Solo contiene el **entorno de ejecución** (compiladores, herramientas, intérpretes CGI)
- **Código fuente**: Reside **siempre en tu máquina local** y se monta como volúmenes

### Ventajas de esta aproximación:

1. ✅ **No necesitas reconstruir** la imagen cuando cambias el código
2. ✅ **Los binarios compilados** quedan en tu máquina local (`bin/webserv`)
3. ✅ **Los cambios en www/, config/, cgi-bin/** se reflejan instantáneamente
4. ✅ **Puedes editar** con tu IDE favorito en Windows/Mac
5. ✅ **Un solo build** de la imagen, múltiples sesiones de desarrollo

## Estructura de Directorios

```
42-C06-Prj14-Webserv/
├── docker/                    # ← Archivos Docker (este directorio)
│   ├── Dockerfile             # Solo entorno, sin código
│   ├── docker-compose.yml     # Configuración con volúmenes
│   ├── webserv-docker.sh      # Script de gestión (Linux/Mac)
│   └── webserv-docker.bat     # Script de gestión (Windows)
├── src/                       # ← Código fuente (local)
├── inc/                       # ← Headers (local)
├── config/                    # ← Configuración webserv (local)
├── www/                       # ← Contenido web (local)
├── cgi-bin/                   # ← Scripts CGI (local)
├── bin/                       # ← Binario compilado (local, generado)
├── obj/                       # ← Archivos objeto (local, generado)
├── dep/                       # ← Dependencias (local, generado)
├── logs/                      # ← Logs (local, generado)
└── Makefile                   # ← Makefile (local)
```

## Uso Rápido

### Windows (PowerShell o CMD)

```batch
cd docker

REM Primera vez: construir imagen
webserv-docker.bat build

REM Iniciar entorno
webserv-docker.bat start

REM Compilar
webserv-docker.bat compile

REM Ejecutar servidor
webserv-docker.bat run

REM Acceder al contenedor
webserv-docker.bat shell
```

### Linux/Mac

```bash
cd docker

# Primera vez: construir imagen
./webserv-docker.sh build

# Iniciar entorno
./webserv-docker.sh start

# Compilar
./webserv-docker.sh compile

# Ejecutar servidor
./webserv-docker.sh run

# Acceder al contenedor
./webserv-docker.sh shell
```

## Comandos Disponibles

| Comando | Descripción |
|---------|-------------|
| `build` | Construir imagen Docker (solo primera vez o tras cambios en Dockerfile) |
| `start` | Iniciar contenedor en background |
| `stop` | Detener contenedor |
| `restart` | Reiniciar contenedor |
| `shell` | Abrir terminal bash dentro del contenedor |
| `compile` | Ejecutar `make re` dentro del contenedor |
| `run` | Compilar (si necesario) y ejecutar webserv |
| `test` | Ejecutar tests básicos |
| `siege` | Test de stress con siege (Linux/Mac) |
| `valgrind` | Ejecutar con valgrind (Linux/Mac) |
| `clean` | Ejecutar `make clean` |
| `fclean` | Ejecutar `make fclean` |
| `status` | Mostrar estado del entorno |
| `logs` | Ver logs del contenedor |
| `remove` | Eliminar contenedor e imagen |

## Flujo de Trabajo Típico

### 1. Setup inicial (una sola vez)

```bash
cd docker
./webserv-docker.sh build    # Construir imagen (~5 min)
```

### 2. Sesión de desarrollo

```bash
./webserv-docker.sh start    # Iniciar contenedor
./webserv-docker.sh compile  # Compilar
./webserv-docker.sh run      # Ejecutar servidor
# Ctrl+C para detener

# Modificar código en tu IDE...
./webserv-docker.sh compile  # Recompilar
./webserv-docker.sh run      # Ejecutar de nuevo
```

### 3. Debugging avanzado

```bash
./webserv-docker.sh shell    # Entrar al contenedor

# Dentro del contenedor:
make re
./bin/webserv config/webserv.conf

# O con valgrind:
valgrind --leak-check=full ./bin/webserv config/webserv.conf

# O con gdb:
gdb ./bin/webserv
```

### 4. Fin del día

```bash
./webserv-docker.sh stop     # Detener contenedor (opcional)
# El contenedor se puede dejar corriendo sin problema
```

## Usando docker-compose directamente

Si prefieres usar docker-compose:

```bash
cd docker

# Modo desarrollo (shell interactivo)
docker-compose up -d webserv-dev
docker-compose exec webserv-dev bash

# Dentro del contenedor:
make re
./bin/webserv config/webserv.conf
```

## Volúmenes Montados

| Local | Contenedor | Modo |
|-------|------------|------|
| `../src/` | `/app/src/` | rw |
| `../inc/` | `/app/inc/` | rw |
| `../Makefile` | `/app/Makefile` | rw |
| `../config/` | `/app/config/` | rw |
| `../www/` | `/app/www/` | rw |
| `../cgi-bin/` | `/app/cgi-bin/` | rw |
| `../bin/` | `/app/bin/` | rw |
| `../obj/` | `/app/obj/` | rw |
| `../dep/` | `/app/dep/` | rw |
| `../logs/` | `/app/logs/` | rw |

## Herramientas Incluidas en la Imagen

### Compilación
- g++, gcc (C++98 compatible)
- clang, llvm
- make

### Debugging
- gdb
- valgrind
- strace, ltrace

### CGI
- Python 3
- PHP-CGI
- Perl
- Bash

### Testing
- curl, wget
- netcat (nc)
- siege
- apache2-utils (ab)

### Utilidades
- vim, nano
- tree, file, less

## Puertos Expuestos

- **8080**: Servidor principal
- **8081**: Servidor secundario
- **8082**: Servidor restringido

## Troubleshooting

### El binario no se crea en bin/

Asegúrate de que el directorio `bin/` existe localmente:
```bash
mkdir -p bin obj dep logs
```

### Permisos en Linux/Mac

Si tienes problemas de permisos:
```bash
chmod +x webserv-docker.sh
chmod +x ../cgi-bin/*.py
```

### El contenedor no arranca

Verifica que Docker Desktop esté corriendo y que los puertos 8080-8082 estén libres:
```bash
docker ps
netstat -an | grep 8080
```

### Los cambios en CGI no funcionan

Los scripts CGI necesitan permisos de ejecución:
```bash
./webserv-docker.sh shell
chmod +x /app/cgi-bin/*.py
```

## Diferencias con el Dockerfile Original

| Aspecto | Original | Nuevo |
|---------|----------|-------|
| Código fuente | Copiado en imagen | Montado como volumen |
| Compilación | Durante build | Manual con `make` |
| Binario | Dentro del contenedor | En tu máquina local |
| Cambios en código | Requiere rebuild | Instantáneos |
| Tamaño imagen | ~900MB + código | ~850MB (solo entorno) |

## Notas sobre los Warnings

Los mensajes en rojo durante `docker build` son **warnings**, no errores:

- **OpenSSL deprecation warnings**: Funciones DES/MD4 obsoletas en OpenSSL 3.0 (usadas por siege)
- **wget output**: wget envía su progreso a stderr por defecto

Ninguno afecta la funcionalidad del entorno.
