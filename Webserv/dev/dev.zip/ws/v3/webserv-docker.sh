#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    webserv-docker.sh                                                         #
#                                                                              #
#    Script de gestión del entorno Docker para webserv                         #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Directorio del script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Nombre de la imagen y contenedor
IMAGE_NAME="webserv-dev"
CONTAINER_NAME="webserv-dev"

# Función para mostrar ayuda
show_help() {
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}           Webserv Docker Development Environment              ${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${GREEN}Uso:${NC} $0 <comando>"
    echo ""
    echo -e "${YELLOW}Comandos disponibles:${NC}"
    echo ""
    echo -e "  ${GREEN}build${NC}        Construir la imagen Docker (solo entorno)"
    echo -e "  ${GREEN}start${NC}        Iniciar contenedor en modo interactivo"
    echo -e "  ${GREEN}stop${NC}         Detener contenedor"
    echo -e "  ${GREEN}restart${NC}      Reiniciar contenedor"
    echo -e "  ${GREEN}shell${NC}        Abrir shell en contenedor en ejecución"
    echo -e "  ${GREEN}compile${NC}      Compilar webserv dentro del contenedor"
    echo -e "  ${GREEN}run${NC}          Compilar y ejecutar webserv"
    echo -e "  ${GREEN}test${NC}         Ejecutar tests básicos"
    echo -e "  ${GREEN}siege${NC}        Ejecutar test de stress con siege"
    echo -e "  ${GREEN}valgrind${NC}     Ejecutar con valgrind"
    echo -e "  ${GREEN}clean${NC}        Limpiar archivos compilados"
    echo -e "  ${GREEN}fclean${NC}       Limpiar todo (binarios incluidos)"
    echo -e "  ${GREEN}status${NC}       Mostrar estado del contenedor"
    echo -e "  ${GREEN}logs${NC}         Mostrar logs del contenedor"
    echo -e "  ${GREEN}remove${NC}       Eliminar contenedor e imagen"
    echo ""
    echo -e "${YELLOW}Ejemplos:${NC}"
    echo "  $0 build      # Construir imagen (primera vez)"
    echo "  $0 start      # Iniciar entorno de desarrollo"
    echo "  $0 compile    # Compilar el proyecto"
    echo "  $0 run        # Ejecutar el servidor"
    echo "  $0 shell      # Acceder al contenedor"
    echo ""
}

# Función para verificar Docker
check_docker() {
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}Error: Docker no está instalado${NC}"
        exit 1
    fi
    if ! docker info &> /dev/null; then
        echo -e "${RED}Error: Docker daemon no está corriendo${NC}"
        exit 1
    fi
}

# Función para crear directorios necesarios
create_dirs() {
    echo -e "${BLUE}Creando directorios necesarios...${NC}"
    mkdir -p "$PROJECT_DIR"/{bin,obj,dep,logs,www/uploads,www/errors,www/deletable}
}

# Construir imagen
cmd_build() {
    echo -e "${BLUE}Construyendo imagen Docker...${NC}"
    cd "$SCRIPT_DIR"
    docker build -t "$IMAGE_NAME:latest" .
    echo -e "${GREEN}✓ Imagen construida: $IMAGE_NAME:latest${NC}"
}

# Iniciar contenedor
cmd_start() {
    create_dirs
    
    # Verificar si ya está corriendo
    if docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${YELLOW}Contenedor ya está corriendo${NC}"
        return
    fi
    
    # Eliminar contenedor anterior si existe
    if docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${YELLOW}Eliminando contenedor anterior...${NC}"
        docker rm -f "$CONTAINER_NAME" > /dev/null
    fi
    
    echo -e "${BLUE}Iniciando contenedor...${NC}"
    docker run -d \
        --name "$CONTAINER_NAME" \
        -p 8080:8080 \
        -p 8081:8081 \
        -p 8082:8082 \
        -v "$PROJECT_DIR/src:/app/src:rw" \
        -v "$PROJECT_DIR/inc:/app/inc:rw" \
        -v "$PROJECT_DIR/Makefile:/app/Makefile:rw" \
        -v "$PROJECT_DIR/config:/app/config:rw" \
        -v "$PROJECT_DIR/www:/app/www:rw" \
        -v "$PROJECT_DIR/cgi-bin:/app/cgi-bin:rw" \
        -v "$PROJECT_DIR/bin:/app/bin:rw" \
        -v "$PROJECT_DIR/obj:/app/obj:rw" \
        -v "$PROJECT_DIR/dep:/app/dep:rw" \
        -v "$PROJECT_DIR/logs:/app/logs:rw" \
        -e TERM=xterm-256color \
        -it \
        "$IMAGE_NAME:latest" \
        /bin/bash -c "tail -f /dev/null"
    
    echo -e "${GREEN}✓ Contenedor iniciado: $CONTAINER_NAME${NC}"
    echo -e "${CYAN}Usa '$0 shell' para acceder al contenedor${NC}"
}

# Detener contenedor
cmd_stop() {
    echo -e "${BLUE}Deteniendo contenedor...${NC}"
    docker stop "$CONTAINER_NAME" 2>/dev/null || true
    echo -e "${GREEN}✓ Contenedor detenido${NC}"
}

# Reiniciar contenedor
cmd_restart() {
    cmd_stop
    cmd_start
}

# Abrir shell
cmd_shell() {
    if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${YELLOW}Contenedor no está corriendo. Iniciando...${NC}"
        cmd_start
    fi
    echo -e "${BLUE}Abriendo shell en contenedor...${NC}"
    docker exec -it "$CONTAINER_NAME" /bin/bash
}

# Compilar
cmd_compile() {
    if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${YELLOW}Contenedor no está corriendo. Iniciando...${NC}"
        cmd_start
    fi
    echo -e "${BLUE}Compilando webserv...${NC}"
    docker exec -it "$CONTAINER_NAME" make re
    echo -e "${GREEN}✓ Compilación completada${NC}"
    echo -e "${CYAN}Binario disponible en: $PROJECT_DIR/bin/webserv${NC}"
}

# Ejecutar servidor
cmd_run() {
    if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${YELLOW}Contenedor no está corriendo. Iniciando...${NC}"
        cmd_start
    fi
    
    # Verificar si existe el binario
    if [ ! -f "$PROJECT_DIR/bin/webserv" ]; then
        echo -e "${YELLOW}Binario no encontrado. Compilando...${NC}"
        cmd_compile
    fi
    
    echo -e "${BLUE}Ejecutando webserv...${NC}"
    echo -e "${CYAN}Servidor disponible en:${NC}"
    echo -e "  - http://localhost:8080"
    echo -e "  - http://localhost:8081"
    echo -e "  - http://localhost:8082"
    echo -e "${YELLOW}Presiona Ctrl+C para detener${NC}"
    echo ""
    docker exec -it "$CONTAINER_NAME" ./bin/webserv config/webserv.conf
}

# Ejecutar tests
cmd_test() {
    if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        cmd_start
    fi
    
    echo -e "${BLUE}Ejecutando tests básicos...${NC}"
    
    # Compilar si es necesario
    if [ ! -f "$PROJECT_DIR/bin/webserv" ]; then
        cmd_compile
    fi
    
    # Ejecutar servidor en background
    docker exec -d "$CONTAINER_NAME" ./bin/webserv config/webserv.conf
    sleep 2
    
    echo -e "\n${CYAN}Testing GET /...${NC}"
    curl -s http://localhost:8080/ | head -10
    
    echo -e "\n${CYAN}Testing 404...${NC}"
    curl -s -o /dev/null -w "Status: %{http_code}\n" http://localhost:8080/nonexistent
    
    echo -e "\n${CYAN}Testing CGI...${NC}"
    curl -s http://localhost:8080/cgi-bin/test.py
    
    # Detener servidor
    docker exec "$CONTAINER_NAME" pkill -f webserv 2>/dev/null || true
    
    echo -e "\n${GREEN}✓ Tests completados${NC}"
}

# Ejecutar siege
cmd_siege() {
    if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        cmd_start
    fi
    
    if [ ! -f "$PROJECT_DIR/bin/webserv" ]; then
        cmd_compile
    fi
    
    echo -e "${BLUE}Ejecutando test de stress con siege...${NC}"
    
    # Ejecutar servidor en background
    docker exec -d "$CONTAINER_NAME" ./bin/webserv config/webserv.conf
    sleep 2
    
    # Ejecutar siege
    docker exec -it "$CONTAINER_NAME" siege -b -c 50 -t 30S http://localhost:8080/
    
    # Detener servidor
    docker exec "$CONTAINER_NAME" pkill -f webserv 2>/dev/null || true
}

# Ejecutar valgrind
cmd_valgrind() {
    if ! docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        cmd_start
    fi
    
    if [ ! -f "$PROJECT_DIR/bin/webserv" ]; then
        cmd_compile
    fi
    
    echo -e "${BLUE}Ejecutando con valgrind...${NC}"
    docker exec -it "$CONTAINER_NAME" valgrind --leak-check=full --show-leak-kinds=all \
        --track-origins=yes ./bin/webserv config/webserv.conf
}

# Limpiar compilación
cmd_clean() {
    if docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${BLUE}Ejecutando make clean...${NC}"
        docker exec "$CONTAINER_NAME" make clean
    else
        echo -e "${BLUE}Limpiando localmente...${NC}"
        rm -rf "$PROJECT_DIR"/{obj,dep}
    fi
    echo -e "${GREEN}✓ Limpieza completada${NC}"
}

# Limpiar todo
cmd_fclean() {
    if docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${BLUE}Ejecutando make fclean...${NC}"
        docker exec "$CONTAINER_NAME" make fclean
    else
        echo -e "${BLUE}Limpiando localmente...${NC}"
        rm -rf "$PROJECT_DIR"/{obj,dep,bin}
    fi
    echo -e "${GREEN}✓ Limpieza completa${NC}"
}

# Mostrar estado
cmd_status() {
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}                    Estado del Entorno                          ${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Imagen
    if docker images --format '{{.Repository}}:{{.Tag}}' | grep -q "^${IMAGE_NAME}:latest$"; then
        echo -e "${GREEN}✓${NC} Imagen: $IMAGE_NAME:latest"
    else
        echo -e "${RED}✗${NC} Imagen: No encontrada"
    fi
    
    # Contenedor
    if docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${GREEN}✓${NC} Contenedor: Corriendo"
    elif docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo -e "${YELLOW}○${NC} Contenedor: Detenido"
    else
        echo -e "${RED}✗${NC} Contenedor: No existe"
    fi
    
    # Binario
    if [ -f "$PROJECT_DIR/bin/webserv" ]; then
        echo -e "${GREEN}✓${NC} Binario: $PROJECT_DIR/bin/webserv"
    else
        echo -e "${RED}✗${NC} Binario: No compilado"
    fi
    
    echo ""
}

# Mostrar logs
cmd_logs() {
    docker logs -f "$CONTAINER_NAME"
}

# Eliminar todo
cmd_remove() {
    echo -e "${YELLOW}¿Eliminar contenedor e imagen? (s/N)${NC}"
    read -r response
    if [[ "$response" =~ ^[sS]$ ]]; then
        echo -e "${BLUE}Eliminando contenedor...${NC}"
        docker rm -f "$CONTAINER_NAME" 2>/dev/null || true
        echo -e "${BLUE}Eliminando imagen...${NC}"
        docker rmi "$IMAGE_NAME:latest" 2>/dev/null || true
        echo -e "${GREEN}✓ Eliminado${NC}"
    else
        echo -e "${YELLOW}Cancelado${NC}"
    fi
}

# Main
check_docker

case "${1:-help}" in
    build)      cmd_build ;;
    start)      cmd_start ;;
    stop)       cmd_stop ;;
    restart)    cmd_restart ;;
    shell)      cmd_shell ;;
    compile)    cmd_compile ;;
    run)        cmd_run ;;
    test)       cmd_test ;;
    siege)      cmd_siege ;;
    valgrind)   cmd_valgrind ;;
    clean)      cmd_clean ;;
    fclean)     cmd_fclean ;;
    status)     cmd_status ;;
    logs)       cmd_logs ;;
    remove)     cmd_remove ;;
    help|--help|-h)
        show_help ;;
    *)
        echo -e "${RED}Comando desconocido: $1${NC}"
        show_help
        exit 1 ;;
esac
