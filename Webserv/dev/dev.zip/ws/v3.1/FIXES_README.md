# Webserv Server.cpp Fixes for Integration Test Failures

## Summary of Bugs Fixed

| Test | Problem | Root Cause | Fix |
|------|---------|------------|-----|
| HEAD / returns 405 | HEAD not in allowed methods | Default methods are GET/POST/DELETE | Treat HEAD as GET for permission check |
| Unknown method (000) | Connection closes without HTTP response | Parse errors not handled outside if block | Check hasError() separately after parse() |
| CSS MIME type | Failed due to HEAD returning 405 | Cascade from HEAD bug | Fixed by HEAD fix |

---

## FIX 1: _handleClientRead - Handle Parse Errors Properly

### Location: src/Server.cpp, function _handleClientRead()

### Problem
When an unknown HTTP method is sent, `Request::parse()` sets the error code to 501 and 
returns `false` (because `isComplete()` returns false when state is PARSE_ERROR). 
The original code only checks for errors inside `if (request.parse(...))`, which is 
never entered when parse fails.

### Original Code (BROKEN):
```cpp
    // Try to parse request
    Request& request = client.getRequest();
    if (request.parse(client.getReadBuffer()))
    {
        client.clearReadBuffer();
        
        if (request.isComplete())
        {
            client.setState(CLIENT_PROCESSING);
            _processRequest(client);
        }
        else if (request.hasError())
        {
            _sendErrorResponse(client, request.getErrorCode());
        }
    }
```

### Fixed Code:
```cpp
    // Try to parse request
    Request& request = client.getRequest();
    request.parse(client.getReadBuffer());

    // Check for parse errors FIRST (e.g., invalid method returns 501)
    if (request.hasError())
    {
        client.clearReadBuffer();
        _sendErrorResponse(client, request.getErrorCode());
        return;
    }

    // Check if request is complete
    if (request.isComplete())
    {
        client.clearReadBuffer();
        client.setState(CLIENT_PROCESSING);
        _processRequest(client);
    }
    // else: need more data, keep buffer for next read
```

---

## FIX 2: _processRequest - Allow HEAD Where GET Is Allowed

### Location: src/Server.cpp, function _processRequest()

### Problem
The default allowed methods in LocationConfig are GET, POST, and DELETE. HEAD is not 
included, causing HEAD requests to return 405 Method Not Allowed. Per HTTP/1.1 spec, 
HEAD MUST be supported wherever GET is supported.

### Original Code (BROKEN):
```cpp
    // Check method allowed
    const std::string& method = request.getMethod();
    if (location != NULL && !location->isMethodAllowed(method))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }
```

### Fixed Code:
```cpp
    // Check method allowed
    const std::string& method = request.getMethod();
    // HEAD should be allowed wherever GET is allowed (HTTP/1.1 spec requirement)
    std::string methodToCheck = method;
    if (method == "HEAD")
        methodToCheck = "GET";
    if (location != NULL && !location->isMethodAllowed(methodToCheck))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }
```

---

## How to Apply

### Option 1: Manual Edit
Open `src/Server.cpp` and make the two changes described above.

### Option 2: Use sed (for CI/CD)
```bash
# These commands would need to be adapted to your exact file content
# It's safer to use manual edit or a proper patch tool
```

---

## Expected Test Results After Fix

```
Total:   40
Passed:  36
Failed:  0
Skipped: 4
```

Note: The 301 Redirect test showing "FAIL" appears to be a test logic issue (it shows 
both PASS and FAIL for the same test), not a server bug. The server is correctly 
returning 301 as configured.
