#!/usr/bin/env python3
"""
apply_fixes.py - Apply webserv Server.cpp fixes for test failures

Fixes:
1. HEAD method returns 405 -> Treat HEAD like GET for permission check
2. Unknown method returns 000 -> Check parse errors separately

Usage:
    python3 apply_fixes.py [path/to/Server.cpp]
"""

import sys
import os
import re

def apply_fix1_handleClientRead(content):
    """Fix parse error handling - check hasError() separately"""
    
    # Find and replace the broken pattern
    old_pattern = r'''(\s+// Try to parse request\s+Request& request = client\.getRequest\(\);\s+)if \(request\.parse\(client\.getReadBuffer\(\)\)\)\s+\{\s+client\.clearReadBuffer\(\);\s+if \(request\.isComplete\(\)\)\s+\{\s+client\.setState\(CLIENT_PROCESSING\);\s+_processRequest\(client\);\s+\}\s+else if \(request\.hasError\(\)\)\s+\{\s+_sendErrorResponse\(client, request\.getErrorCode\(\)\);\s+\}\s+\}'''
    
    new_code = r'''\1request.parse(client.getReadBuffer());

    // Check for parse errors FIRST (e.g., invalid method returns 501)
    if (request.hasError())
    {
        client.clearReadBuffer();
        _sendErrorResponse(client, request.getErrorCode());
        return;
    }

    // Check if request is complete
    if (request.isComplete())
    {
        client.clearReadBuffer();
        client.setState(CLIENT_PROCESSING);
        _processRequest(client);
    }
    // else: need more data, keep buffer for next read'''
    
    new_content, count = re.subn(old_pattern, new_code, content, flags=re.MULTILINE | re.DOTALL)
    
    if count == 0:
        # Try a simpler replacement approach
        # Replace just the core if statement structure
        old_simple = '''if (request.parse(client.getReadBuffer()))
	{
		client.clearReadBuffer();
		
		if (request.isComplete())
		{
			client.setState(CLIENT_PROCESSING);
			_processRequest(client);
		}
		else if (request.hasError())
		{
			_sendErrorResponse(client, request.getErrorCode());
		}
	}'''
        
        new_simple = '''request.parse(client.getReadBuffer());

	// Check for parse errors FIRST (e.g., invalid method returns 501)
	if (request.hasError())
	{
		client.clearReadBuffer();
		_sendErrorResponse(client, request.getErrorCode());
		return;
	}

	// Check if request is complete
	if (request.isComplete())
	{
		client.clearReadBuffer();
		client.setState(CLIENT_PROCESSING);
		_processRequest(client);
	}
	// else: need more data, keep buffer for next read'''
        
        if old_simple in content:
            new_content = content.replace(old_simple, new_simple)
            count = 1
    
    return new_content, count > 0


def apply_fix2_processRequest(content):
    """Fix HEAD method - treat as GET for permission check"""
    
    # Find the method allowed check section
    old_pattern = r'''(// Check method allowed\s+)const std::string& method = request\.getMethod\(\);\s+if \(location != NULL && !location->isMethodAllowed\(method\)\)'''
    
    new_code = r'''\1const std::string& method = request.getMethod();
	// HEAD should be allowed wherever GET is allowed (HTTP/1.1 spec)
	std::string methodToCheck = method;
	if (method == "HEAD")
		methodToCheck = "GET";
	if (location != NULL && !location->isMethodAllowed(methodToCheck))'''
    
    new_content, count = re.subn(old_pattern, new_code, content, flags=re.MULTILINE)
    
    return new_content, count > 0


def main():
    # Determine file path
    if len(sys.argv) > 1:
        filepath = sys.argv[1]
    else:
        filepath = "src/Server.cpp"
    
    if not os.path.exists(filepath):
        print(f"Error: {filepath} not found")
        print("Usage: python3 apply_fixes.py [path/to/Server.cpp]")
        sys.exit(1)
    
    # Read file
    with open(filepath, 'r') as f:
        content = f.read()
    
    # Create backup
    backup_path = filepath + ".bak"
    with open(backup_path, 'w') as f:
        f.write(content)
    print(f"Created backup: {backup_path}")
    
    # Apply fixes
    print("\nApplying Fix 1: _handleClientRead error handling...")
    content, success1 = apply_fix1_handleClientRead(content)
    if success1:
        print("  ✅ Fix 1 applied successfully")
    else:
        print("  ⚠️  Fix 1: Pattern not found (may already be fixed)")
    
    print("\nApplying Fix 2: HEAD method permission check...")
    content, success2 = apply_fix2_processRequest(content)
    if success2:
        print("  ✅ Fix 2 applied successfully")
    else:
        print("  ⚠️  Fix 2: Pattern not found (may already be fixed)")
    
    # Write result
    with open(filepath, 'w') as f:
        f.write(content)
    
    print(f"\n{'='*50}")
    if success1 or success2:
        print("Fixes written to:", filepath)
        print("\nNext steps:")
        print("  1. Run: make re")
        print("  2. Run: make test-quick")
        print(f"\nTo revert: cp {backup_path} {filepath}")
    else:
        print("No changes were made - fixes may already be applied")
    
    return 0 if (success1 or success2) else 1


if __name__ == "__main__":
    sys.exit(main())
