# Webserv Testing Suite - Integración con 42 Official Testers

## Descripción

Este paquete contiene la suite completa de pruebas para el proyecto **webserv** de 42, 
incluyendo la integración con los **testers oficiales de 42** (`ubuntu_tester`, `cgi_tester`).

## Estructura de Archivos

```
webserv-testing/
├── .github/
│   └── workflows/
│       └── ci.yml              # Pipeline CI/CD con 42 testers
├── tests/
│   ├── test_suite.sh           # Suite principal (INCLUYE 42 TESTERS)
│   ├── benchmark_tests.sh      # Tests de rendimiento (siege)
│   ├── security_tests.sh       # Tests de seguridad
│   ├── siege_test.sh           # Wrapper backward compatibility
│   └── test.sh                 # Wrapper backward compatibility
├── cgi-bin/
│   ├── test.py                 # CGI de prueba
│   ├── env.py                  # Variables de entorno CGI
│   ├── info.py                 # Información del sistema
│   ├── session.py              # Demo de sesiones (BONUS)
│   ├── upload.py               # Manejador de uploads
│   ├── ubuntu_cgi_tester       # 42 CGI Tester (Linux)
│   └── cgi_tester              # 42 CGI Tester (macOS)
├── testers/
│   ├── ubuntu_tester           # 42 Tester oficial (Linux)
│   └── tester                  # 42 Tester oficial (macOS)
├── Makefile                    # Con targets para 42 testers
└── README.md                   # Este archivo
```

## Instalación

### 1. Copiar archivos a tu proyecto

```bash
# Desde la raíz de tu proyecto webserv:
cp -r webserv-testing/tests ./
cp -r webserv-testing/cgi-bin ./
cp -r webserv-testing/testers ./
cp -r webserv-testing/.github ./
cp webserv-testing/Makefile ./
```

### 2. Dar permisos de ejecución

```bash
chmod +x tests/*.sh
chmod +x cgi-bin/*.py
chmod +x cgi-bin/*_tester 2>/dev/null || true
chmod +x testers/* 2>/dev/null || true
```

## Uso

### Tests Completos (Incluye 42 Tester)

```bash
# Ejecutar suite completa (tests propios + 42 tester)
make test

# Ejecutar todos los tests (integración + seguridad + benchmark)
make test-all

# Modo rápido (para CI)
make test-quick
```

### Solo 42 Official Tester

```bash
# Ejecutar SOLO el tester oficial de 42
make test-42

# Con output detallado
make test-42-verbose

# Solo el CGI tester de 42
make test-42-cgi
```

### Tests Específicos

```bash
# Tests de CGI
make test-cgi

# Tests de seguridad
make test-security

# Tests de rendimiento (siege)
make test-benchmark

# Validación del subject de 42
make test-subject
```

### Verificar Disponibilidad de Testers

```bash
make check-42-testers
```

## Opciones del Script test_suite.sh

```bash
# Mostrar ayuda
./tests/test_suite.sh --help

# Modo rápido
./tests/test_suite.sh --quick

# Saltar 42 tester
./tests/test_suite.sh --skip-42

# SOLO ejecutar 42 tester
./tests/test_suite.sh --42-only

# Puerto personalizado
./tests/test_suite.sh --port 9090
```

## Integración CI/CD (GitHub Actions)

El archivo `.github/workflows/ci.yml` incluye un job específico para el 42 tester:

### Jobs del Pipeline

1. **build** - Compilación con g++ y clang++
2. **compilation-flags** - Verificación de flags estrictos
3. **unit-tests** - Tests unitarios básicos
4. **integration-tests** - Tests de integración
5. **official-42-tester** - 🆕 **42 Official Tester**
6. **cgi-tests** - Tests CGI (incluye 42 CGI tester)
7. **security-tests** - Tests de seguridad
8. **memory-tests** - Valgrind
9. **stress-tests** - Siege
10. **subject-validation** - Validación del subject
11. **summary** - Resumen final

### Activar 42 Testers en CI

Para que los testers de 42 se ejecuten en el pipeline:

```bash
# Añadir testers al repositorio
git add testers/ubuntu_tester testers/tester
git add cgi-bin/ubuntu_cgi_tester cgi-bin/cgi_tester
git commit -m "Add 42 official testers"
git push
```

## Targets del Makefile

### Tests

| Target | Descripción |
|--------|-------------|
| `test` | Tests de integración (incluye 42 tester) |
| `test-all` | Todos los tests |
| `test-quick` | Tests rápidos para CI |
| `test-42` | **Solo 42 Official Tester** |
| `test-42-verbose` | 42 Tester con output detallado |
| `test-42-cgi` | Solo 42 CGI Tester |
| `test-cgi` | Tests CGI |
| `test-security` | Tests de seguridad |
| `test-benchmark` | Tests de rendimiento |
| `test-subject` | Validación subject 42 |

### Utilidades

| Target | Descripción |
|--------|-------------|
| `setup-42-testers` | Copiar testers desde directorio padre |
| `check-42-testers` | Verificar disponibilidad de testers |

### Docker

| Target | Descripción |
|--------|-------------|
| `docker-test` | Tests en contenedor |
| `docker-test-42` | 42 Tester en contenedor |

## Ubicación de los Testers

### Tester Principal

El script busca automáticamente en:
1. `testers/ubuntu_tester` (preferido en Linux)
2. `testers/tester` (alternativa/macOS)

### CGI Tester

El script busca automáticamente en:
1. `cgi-bin/ubuntu_cgi_tester` (preferido en Linux)
2. `cgi-bin/cgi_tester` (alternativa/macOS)

## Ejemplo de Output

```
╔═══════════════════════════════════════════════════════════════════╗
║     Webserv Complete Integration Test Suite (with 42 Testers)     ║
╚═══════════════════════════════════════════════════════════════════╝

[INFO] 42 Tester found: testers/ubuntu_tester
[INFO] 42 CGI Tester found: cgi-bin/ubuntu_cgi_tester

═══════════════════════════════════════════════════════════════
  Basic HTTP Tests
═══════════════════════════════════════════════════════════════
  ✅ PASS: GET / returns 200 (got 200)
  ✅ PASS: GET /index.html returns 200 (got 200)
  ...

╔═══════════════════════════════════════════════════════════════╗
║  42 Official Tester                                            ║
╚═══════════════════════════════════════════════════════════════╝

[Running 42 Official Tester...]
...

═══════════════════════════════════════════════════════════════
  Test Summary
═══════════════════════════════════════════════════════════════

Custom Tests:
  Total:   45
  Passed:  43
  Failed:  0
  Skipped: 2

42 Official Tester:
  Passed:  12
  Failed:  0

✅ All tests passed!
```

## Notas Importantes

1. **No se eliminan tests existentes** - Los tests originales se mantienen intactos
2. **Sin redundancia** - El 42 tester se ejecuta como una sección separada
3. **Detección automática** - El sistema detecta qué tester usar según el SO
4. **Opcional** - Si no hay testers de 42, el script continúa con los tests propios
5. **Compatible CI/CD** - Funciona en GitHub Actions sin configuración adicional

## Troubleshooting

### El tester no se ejecuta

```bash
# Verificar permisos
chmod +x testers/*
chmod +x cgi-bin/*_tester

# Verificar detección
make check-42-testers
```

### Error "Permission denied"

```bash
# En Linux, puede ser necesario:
chmod 755 testers/ubuntu_tester
chmod 755 cgi-bin/ubuntu_cgi_tester
```

### El CGI tester da error

Asegúrate de que el CGI tester esté en `cgi-bin/` y que tu servidor 
tenga configurado correctamente el handler de CGI para ejecutables.

## Autor

**fcela-ga** - 42 Barcelona
