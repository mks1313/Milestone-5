# 42 TESTER - ANÁLISIS DE PROBLEMAS Y SOLUCIONES

## 📊 RESUMEN DEL DIAGNÓSTICO

| Test | Esperado | Actual | Estado | Causa |
|------|----------|--------|--------|-------|
| GET / | 200 | 200 | ✅ | OK |
| POST / | 405 | 405 | ✅ | OK |
| PUT /put_test/test.txt | 200/201 | **501** | ❌ | **PUT no implementado** |
| POST /post_body (pequeño) | 200 | **405** | ❌ | Location faltante |
| POST /post_body (>100 bytes) | 413 | **405** | ❌ | Location faltante |
| GET /directory/ | 200 | 200 | ✅ | OK |

---

## 🔴 PROBLEMA CRÍTICO: PUT NO IMPLEMENTADO (501)

Tu servidor devuelve **501 Not Implemented** para el método PUT.

### ¿Dónde está el problema?

En tu código C++ (probablemente `Response.cpp` o `Server.cpp`), necesitas implementar el manejo de PUT.

### Busca algo como esto:

```cpp
// En Response.cpp o Server.cpp
std::string Response::handleRequest(const Request& request, const ServerConfig& config) {
    std::string method = request.getMethod();
    
    if (method == "GET") {
        return handleGET(...);
    }
    else if (method == "POST") {
        return handlePOST(...);
    }
    else if (method == "DELETE") {
        return handleDELETE(...);
    }
    // ¿FALTA PUT?
    else {
        return generateErrorResponse(501, "Not Implemented");  // <-- Esto causa el error
    }
}
```

### Solución - Implementar PUT:

```cpp
else if (method == "PUT") {
    return handlePUT(request, config);
}

// Y añadir la función:
std::string Response::handlePUT(const Request& request, const ServerConfig& config) {
    // 1. Obtener el path del archivo
    std::string path = request.getPath();
    
    // 2. Obtener el directorio de upload de la location config
    LocationConfig* loc = config.getMatchingLocation(path);
    if (!loc || !loc->isMethodAllowed("PUT")) {
        return generateErrorResponse(405, "Method Not Allowed");
    }
    
    std::string uploadDir = loc->getUploadStore();
    if (uploadDir.empty()) {
        uploadDir = config.getRoot();
    }
    
    // 3. Construir el path completo del archivo
    std::string filename = path.substr(path.find_last_of('/') + 1);
    std::string fullPath = uploadDir + "/" + filename;
    
    // 4. Escribir el body al archivo
    std::ofstream file(fullPath.c_str(), std::ios::binary);
    if (!file.is_open()) {
        return generateErrorResponse(500, "Cannot create file");
    }
    
    file << request.getBody();
    file.close();
    
    // 5. Devolver 201 Created o 200 OK
    std::string response = "HTTP/1.1 201 Created\r\n";
    response += "Content-Length: 0\r\n";
    response += "Location: " + path + "\r\n";
    response += "\r\n";
    
    return response;
}
```

---

## 🟡 PROBLEMA: LOCATION /post_body NO RECONOCIDA

El diagnóstico muestra que POST a `/post_body` devuelve 405.

### Causa probable:

1. La location `/post_body` no está en tu configuración actual
2. O el orden de las locations hace que `/` capture primero

### Solución:

1. **Usa el `webserv.conf` que te entrego** - tiene todas las locations necesarias
2. Verifica que tu parser de configuración procese las locations en orden de especificidad (más específicas primero)

---

## 🟡 PROBLEMA: 42 TESTER FALLA EN GET /

El 42 tester falla con "bad status code" en GET / aunque curl funciona.

### Posibles causas:

1. **El tester espera headers específicos** que tu servidor no envía
2. **El tester verifica el formato exacto** de la respuesta HTTP
3. **Problemas de timing** o conexión

### Verificar:

```bash
# Ver qué headers devuelve tu servidor
curl -v http://localhost:8080/ 2>&1 | head -30

# Debe incluir al menos:
# HTTP/1.1 200 OK
# Content-Type: text/html
# Content-Length: XXXX
```

### Posible solución:

Asegúrate de que tu respuesta HTTP tiene el formato correcto:

```
HTTP/1.1 200 OK\r\n
Content-Type: text/html\r\n
Content-Length: 1234\r\n
Connection: close\r\n
\r\n
<contenido>
```

---

## ✅ PASOS PARA CORREGIR

### Paso 1: Aplicar la configuración correcta

```bash
cp webserv.conf config/webserv.conf
```

### Paso 2: Verificar estructura YoupiBanane

```bash
make setup-42-env
ls -la YoupiBanane/
```

Debe mostrar:
- youpi.bad_extension
- youpi.bla
- nop/
- Yeah/

### Paso 3: Implementar PUT (CÓDIGO C++)

Añade el manejo de PUT en tu servidor (ver código arriba).

### Paso 4: Recompilar y probar

```bash
make re
make test-42-diagnose
```

### Paso 5: Si todo está OK, ejecutar 42 tester

```bash
make test-42
```

---

## 📝 REQUISITOS DEL 42 TESTER (RECORDATORIO)

1. **/ must answer to GET request ONLY**
   - GET / → 200
   - POST / → 405
   - PUT / → 405
   - DELETE / → 405

2. **/put_test/* must answer to PUT request**
   - PUT /put_test/file.txt → 201 (crea archivo)
   - Archivos se guardan en www/put_test/

3. **.bla files must call cgi_test executable**
   - POST /directory/youpi.bla → ejecuta testers/ubuntu_cgi_tester

4. **/post_body must answer to POST with maxBody of 100**
   - POST /post_body (body < 100) → 200
   - POST /post_body (body > 100) → 413 Payload Too Large

5. **/directory/ must serve YoupiBanane**
   - GET /directory/ → contenido de YoupiBanane/youpi.bad_extension
   - Root = ./YoupiBanane
   - Index = youpi.bad_extension

---

## 🆘 SI AÚN FALLA

Si después de implementar PUT el tester sigue fallando:

1. **Comparte tu código de Response.cpp** para que pueda revisarlo
2. **Ejecuta el tester manualmente** y copia el output completo
3. **Verifica con curl** qué devuelve cada endpoint:

```bash
# GET /
curl -v http://localhost:8080/

# POST /
curl -v -X POST http://localhost:8080/

# PUT /put_test/test.txt
curl -v -X PUT -d "contenido" http://localhost:8080/put_test/test.txt

# POST /post_body (pequeño)
curl -v -X POST -d "abc" http://localhost:8080/post_body

# POST /post_body (grande)
curl -v -X POST -d "$(printf 'A%.0s' {1..150})" http://localhost:8080/post_body
```
