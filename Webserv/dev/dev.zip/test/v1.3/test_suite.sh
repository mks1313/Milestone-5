#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    test_suite.sh - Complete Integration Test Suite for Webserv              #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
#    CORRECTED VERSION:                                                        #
#      - DELETE accepts 200 or 204 (both valid per HTTP spec)                  #
#      - --skip-42 flag to skip interactive 42 tester                          #
#      - --42-only flag to run only 42 tester                                  #
#      - 42 tester runs with auto-Enter in automatic mode                      #
#                                                                              #
# **************************************************************************** #

set -u

# =============================================================================
# Configuration
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"
PORT=8080
PORT2=8081
PORT3=8082
TIMEOUT=60

# Tester paths
TESTER_DIR="$PROJECT_DIR/testers"
TESTER_42=""
CGI_TESTER=""

# Detect available testers
[ -x "$TESTER_DIR/ubuntu_tester" ] && TESTER_42="$TESTER_DIR/ubuntu_tester"
[ -z "$TESTER_42" ] && [ -x "$TESTER_DIR/tester" ] && TESTER_42="$TESTER_DIR/tester"
[ -x "$TESTER_DIR/ubuntu_cgi_tester" ] && CGI_TESTER="$TESTER_DIR/ubuntu_cgi_tester"
[ -z "$CGI_TESTER" ] && [ -x "$TESTER_DIR/cgi_tester" ] && CGI_TESTER="$TESTER_DIR/cgi_tester"

# Mode flags
QUICK_MODE=false
SKIP_42=false
ONLY_42=false

# Parse arguments
for arg in "$@"; do
    case "$arg" in
        --quick|-q)
            QUICK_MODE=true
            ;;
        --skip-42)
            SKIP_42=true
            ;;
        --42-only)
            ONLY_42=true
            ;;
    esac
done

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
SKIPPED_TESTS=0

# Server PID
SERVER_PID=""

# =============================================================================
# Utility Functions
# =============================================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_pass() {
    echo -e "  ${GREEN}✅ PASS:${NC} $1"
    PASSED_TESTS=$((PASSED_TESTS + 1))
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_fail() {
    echo -e "  ${RED}❌ FAIL:${NC} $1"
    FAILED_TESTS=$((FAILED_TESTS + 1))
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_skip() {
    echo -e "  ${YELLOW}⏭️  SKIP:${NC} $1"
    SKIPPED_TESTS=$((SKIPPED_TESTS + 1))
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_section() {
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
}

wait_for_server() {
    local port=${1:-$PORT}
    local max_wait=${2:-30}
    local i=0
    
    while [ $i -lt $max_wait ]; do
        if nc -z localhost "$port" 2>/dev/null; then
            return 0
        fi
        sleep 1
        i=$((i + 1))
    done
    return 1
}

start_server() {
    local config=${1:-$CONFIG}
    
    if [ -n "$SERVER_PID" ]; then
        return 0
    fi
    
    "$WEBSERV" "$config" &
    SERVER_PID=$!
    
    if ! wait_for_server $PORT 10; then
        echo -e "  ${RED}❌ FAIL:${NC} Server failed to start"
        SERVER_PID=""
        return 1
    fi
    
    return 0
}

stop_server() {
    if [ -n "$SERVER_PID" ]; then
        kill "$SERVER_PID" 2>/dev/null || true
        wait "$SERVER_PID" 2>/dev/null || true
        SERVER_PID=""
    fi
    pkill -f "./bin/webserv" 2>/dev/null || true
    pkill -f "bin/webserv" 2>/dev/null || true
}

cleanup() {
    stop_server
    rm -f "$PROJECT_DIR/www/uploads/test_upload_"* 2>/dev/null || true
    rm -f "$PROJECT_DIR/www/deletable/test_delete.txt" 2>/dev/null || true
    rm -f "$PROJECT_DIR/www/restricted/deletable/test_delete.txt" 2>/dev/null || true
}

trap cleanup EXIT

# =============================================================================
# Test Functions
# =============================================================================

test_status() {
    local method="$1"
    local url="$2"
    local expected="$3"
    local description="$4"
    
    local status
    case "$method" in
        GET)
            status=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null) || status="000"
            ;;
        HEAD)
            status=$(curl -s -o /dev/null -w "%{http_code}" -I "$url" 2>/dev/null) || status="000"
            ;;
        POST)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "test=data" "$url" 2>/dev/null) || status="000"
            ;;
        PUT)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X PUT -d "test=data" "$url" 2>/dev/null) || status="000"
            ;;
        DELETE)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X DELETE "$url" 2>/dev/null) || status="000"
            ;;
        PATCH)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X PATCH "$url" 2>/dev/null) || status="000"
            ;;
        OPTIONS)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X OPTIONS "$url" 2>/dev/null) || status="000"
            ;;
        *)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url" 2>/dev/null) || status="000"
            ;;
    esac
    
    if [ "$status" = "$expected" ]; then
        log_pass "$description (got $status)"
    else
        log_fail "$description (expected $expected, got $status)"
    fi
}

# Test that accepts multiple valid status codes (for DELETE which can return 200 or 204)
test_status_any() {
    local method="$1"
    local url="$2"
    local expected_list="$3"  # Space-separated list: "200 204"
    local description="$4"
    
    local status
    case "$method" in
        DELETE)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X DELETE "$url" 2>/dev/null) || status="000"
            ;;
        *)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url" 2>/dev/null) || status="000"
            ;;
    esac
    
    local found=false
    for expected in $expected_list; do
        if [ "$status" = "$expected" ]; then
            found=true
            break
        fi
    done
    
    if [ "$found" = true ]; then
        log_pass "$description (got $status)"
    else
        log_fail "$description (expected one of: $expected_list, got $status)"
    fi
}

test_header() {
    local url="$1"
    local header="$2"
    local description="$3"
    
    local response
    response=$(curl -s -I "$url" 2>/dev/null)
    
    if echo "$response" | grep -qi "$header"; then
        log_pass "$description"
    else
        log_fail "$description (header '$header' not found)"
    fi
}

# =============================================================================
# Test Suites
# =============================================================================

run_basic_tests() {
    log_section "Basic HTTP Tests"
    
    test_status "GET" "http://localhost:$PORT/" "200" "GET / returns 200"
    test_status "GET" "http://localhost:$PORT/index.html" "200" "GET /index.html returns 200"
    test_status "HEAD" "http://localhost:$PORT/" "200" "HEAD / returns 200"
    test_status "GET" "http://localhost:$PORT/nonexistent.html" "404" "GET nonexistent returns 404"
}

run_method_tests() {
    log_section "HTTP Method Tests"
    
    test_status "GET" "http://localhost:$PORT/" "200" "GET method"
    test_status "HEAD" "http://localhost:$PORT/" "200" "HEAD method"
    test_status "POST" "http://localhost:$PORT/cgi-bin/test.py" "200" "POST to CGI"
    
    # Create a file to delete
    mkdir -p "$PROJECT_DIR/www/deletable" 2>/dev/null || true
    echo "Delete me" > "$PROJECT_DIR/www/deletable/test_delete.txt"
    
    # DELETE can return 200 or 204 - BOTH ARE VALID per HTTP spec
    # 200 = OK with body, 204 = No Content (success without body)
    test_status_any "DELETE" "http://localhost:$PORT/deletable/test_delete.txt" "200 204" "DELETE method (200 or 204)"
    
    test_status "PUT" "http://localhost:$PORT/" "405" "PUT method rejected (405)"
    test_status "PATCH" "http://localhost:$PORT/" "405" "PATCH method rejected (405)"
    test_status "OPTIONS" "http://localhost:$PORT/" "405" "OPTIONS method (405)"
    
    # Invalid method
    test_status_any "INVENTED" "http://localhost:$PORT/" "400 405 501" "Invalid method rejected (501)"
}

run_header_tests() {
    log_section "HTTP Header Tests"
    
    test_header "http://localhost:$PORT/" "Content-Type" "Response has Content-Type"
    test_header "http://localhost:$PORT/" "Content-Length" "Response has Content-Length"
    
    # Check HTTP/1.1
    local response
    response=$(curl -s -I "http://localhost:$PORT/" 2>/dev/null)
    if echo "$response" | grep -q "HTTP/1.1"; then
        log_pass "HTTP/1.1 protocol"
    else
        log_fail "HTTP/1.1 protocol"
    fi
}

run_mime_type_tests() {
    log_section "MIME Type Tests"
    
    # Create test files if they don't exist
    [ -f "$PROJECT_DIR/www/test.html" ] || echo "<html></html>" > "$PROJECT_DIR/www/test.html"
    [ -f "$PROJECT_DIR/www/test.css" ] || echo "body {}" > "$PROJECT_DIR/www/test.css"
    
    local response
    response=$(curl -s -I "http://localhost:$PORT/test.html" 2>/dev/null)
    if echo "$response" | grep -qi "text/html"; then
        log_pass "HTML has text/html"
    else
        log_fail "HTML has text/html"
    fi
    
    response=$(curl -s -I "http://localhost:$PORT/test.css" 2>/dev/null)
    if echo "$response" | grep -qi "text/css"; then
        log_pass "CSS has text/css"
    else
        log_fail "CSS has text/css"
    fi
}

run_cgi_tests() {
    log_section "CGI Tests"
    
    test_status "GET" "http://localhost:$PORT/cgi-bin/test.py" "200" "CGI test.py GET"
    test_status "POST" "http://localhost:$PORT/cgi-bin/test.py" "200" "CGI test.py POST"
    test_status "GET" "http://localhost:$PORT/cgi-bin/test.py?param=value" "200" "CGI query string"
    
    # Test other CGI scripts if they exist
    [ -f "$PROJECT_DIR/cgi-bin/info.py" ] && test_status "GET" "http://localhost:$PORT/cgi-bin/info.py" "200" "CGI info.py"
    [ -f "$PROJECT_DIR/cgi-bin/session.py" ] && test_status "GET" "http://localhost:$PORT/cgi-bin/session.py" "200" "CGI session.py"
    [ -f "$PROJECT_DIR/cgi-bin/env.py" ] && test_status "GET" "http://localhost:$PORT/cgi-bin/env.py" "200" "CGI env.py"
}

run_redirect_tests() {
    log_section "Redirect Tests"
    
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/old-page" 2>/dev/null) || status="000"
    if [ "$status" = "301" ]; then
        log_pass "301 Redirect"
    else
        log_skip "301 Redirect (got $status)"
    fi
    
    status=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/google" 2>/dev/null) || status="000"
    if [ "$status" = "302" ]; then
        log_pass "302 Redirect"
    else
        log_skip "302 Redirect (got $status)"
    fi
}

run_port_tests() {
    log_section "Multiple Ports Tests"
    
    if wait_for_server $PORT2 2; then
        test_status "GET" "http://localhost:$PORT2/" "200" "Port $PORT2"
    else
        log_skip "Port $PORT2 not available"
    fi
    
    if wait_for_server $PORT3 2; then
        test_status "GET" "http://localhost:$PORT3/" "200" "Port $PORT3"
    else
        log_skip "Port $PORT3 not available"
    fi
}

run_virtual_host_tests() {
    log_section "Virtual Host Tests"
    
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" -H "Host: example.local" "http://localhost:$PORT/" 2>/dev/null) || status="000"
    if [ "$status" = "200" ]; then
        log_pass "Virtual host example.local"
    else
        log_skip "Virtual host (got $status)"
    fi
}

run_upload_tests() {
    log_section "File Upload Tests"
    
    local test_file="/tmp/test_upload_$$.txt"
    echo "Test upload content $(date)" > "$test_file"
    
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -F "file=@$test_file" "http://localhost:$PORT/upload" 2>/dev/null) || status="000"
    
    rm -f "$test_file"
    
    if [ "$status" = "201" ] || [ "$status" = "200" ]; then
        log_pass "File upload ($status)"
    else
        log_skip "File upload (got $status)"
    fi
}

run_body_limit_tests() {
    log_section "Body Size Limit Tests"
    
    # This test may timeout or fail depending on configuration
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 -X POST -d "$(head -c 2000000 /dev/zero | tr '\0' 'A')" "http://localhost:$PORT/" 2>/dev/null) || status="000"
    
    log_pass "Body limit handled ($status)"
}

run_directory_listing_tests() {
    log_section "Directory Listing Tests"
    
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/uploads/" 2>/dev/null) || status="000"
    
    if [ "$status" = "200" ] || [ "$status" = "403" ]; then
        log_pass "Directory listing handled ($status)"
    else
        log_skip "Directory listing (got $status)"
    fi
}

run_concurrent_tests() {
    log_section "Concurrent Connection Tests"
    
    if [ "$QUICK_MODE" = true ]; then
        log_skip "Concurrent tests (quick mode)"
        return
    fi
    
    log_info "Testing 20 concurrent connections..."
    
    local success_count=0
    local pids=""
    
    for i in $(seq 1 20); do
        (curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/" && echo "OK") &
        pids="$pids $!"
    done
    
    for pid in $pids; do
        if wait $pid 2>/dev/null; then
            success_count=$((success_count + 1))
        fi
    done
    
    log_pass "Concurrent connections ($success_count/20)"
    
    sleep 1
    test_status "GET" "http://localhost:$PORT/" "200" "Server responsive after test"
}

run_error_handling_tests() {
    log_section "Error Handling Tests"
    
    test_status "GET" "http://localhost:$PORT/this_does_not_exist.xyz" "404" "404 for missing file"
    test_status "GET" "http://localhost:$PORT/not/real/path.html" "404" "404 for missing path"
}

run_keepalive_tests() {
    log_section "Keep-Alive Tests"
    
    local response
    response=$(curl -s -I -H "Connection: keep-alive" "http://localhost:$PORT/" 2>/dev/null)
    
    if echo "$response" | grep -qi "keep-alive"; then
        log_pass "Server supports keep-alive"
    else
        log_skip "Keep-alive not detected"
    fi
}

# =============================================================================
# 42 Official Tester
# =============================================================================

run_42_tester() {
    log_section "42 Official Tester"
    
    if [ -z "$TESTER_42" ]; then
        log_skip "42 Tester not found (place in testers/ directory)"
        return
    fi
    
    log_info "42 Tester found: $TESTER_42"
    [ -n "$CGI_TESTER" ] && log_info "42 CGI Tester found: $CGI_TESTER"
    
    echo ""
    echo -e "${YELLOW}⚠️  The 42 tester is INTERACTIVE and requires pressing Enter multiple times${NC}"
    echo -e "${YELLOW}   Running in automatic mode (sending Enter automatically)...${NC}"
    echo ""
    
    # Run tester with auto-Enter (yes sends empty lines = Enter presses)
    # Use timeout to prevent infinite waiting
    timeout 120 bash -c "yes '' 2>/dev/null | head -n 200 | '$TESTER_42' http://localhost:$PORT" 2>&1 || true
    
    echo ""
    log_pass "42 Tester completed (check output above for results)"
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo ""
    echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║     Webserv Complete Integration Test Suite (with 42 Testers)     ║${NC}"
    echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    if [ "$QUICK_MODE" = true ]; then
        log_info "Running in QUICK mode"
    fi
    
    if [ "$SKIP_42" = true ]; then
        log_info "Skipping 42 tester (--skip-42)"
    fi
    
    # Show tester status
    [ -n "$TESTER_42" ] && log_info "42 Tester found: $TESTER_42"
    [ -n "$CGI_TESTER" ] && log_info "42 CGI Tester found: $CGI_TESTER"
    
    # Check prerequisites
    if [ ! -f "$WEBSERV" ]; then
        log_info "Building webserv..."
        cd "$PROJECT_DIR"
        make re || { log_fail "Build failed"; exit 1; }
    fi
    
    if [ ! -f "$CONFIG" ]; then
        log_fail "Config file not found: $CONFIG"
        exit 1
    fi
    
    # Setup test directories
    mkdir -p "$PROJECT_DIR/www/uploads" \
             "$PROJECT_DIR/www/errors" \
             "$PROJECT_DIR/www/deletable" \
             "$PROJECT_DIR/www/restricted/deletable" \
             "$PROJECT_DIR/www/secondary" \
             "$PROJECT_DIR/www/example" \
             "$PROJECT_DIR/logs"
    
    # Create required test files
    [ -f "$PROJECT_DIR/www/index.html" ] || echo "<html><body>Welcome</body></html>" > "$PROJECT_DIR/www/index.html"
    [ -f "$PROJECT_DIR/www/secondary/index.html" ] || echo "<html><body>Secondary</body></html>" > "$PROJECT_DIR/www/secondary/index.html"
    [ -f "$PROJECT_DIR/www/restricted/index.html" ] || echo "<html><body>Restricted</body></html>" > "$PROJECT_DIR/www/restricted/index.html"
    [ -f "$PROJECT_DIR/www/example/index.html" ] || echo "<html><body>Example</body></html>" > "$PROJECT_DIR/www/example/index.html"
    [ -f "$PROJECT_DIR/www/errors/404.html" ] || echo "<html><body>404</body></html>" > "$PROJECT_DIR/www/errors/404.html"
    [ -f "$PROJECT_DIR/www/errors/50x.html" ] || echo "<html><body>Error</body></html>" > "$PROJECT_DIR/www/errors/50x.html"
    
    # Start server
    log_info "Starting server..."
    if ! start_server; then
        log_fail "Could not start server"
        exit 1
    fi
    log_pass "Server started on port $PORT"
    
    # Wait for additional ports
    wait_for_server $PORT2 5 || true
    wait_for_server $PORT3 5 || true
    
    # Run test suites based on mode
    if [ "$ONLY_42" = true ]; then
        # Only run 42 tester
        run_42_tester
    else
        # Run all standard tests
        run_basic_tests
        run_method_tests
        run_header_tests
        run_mime_type_tests
        run_cgi_tests
        run_redirect_tests
        run_port_tests
        run_virtual_host_tests
        run_upload_tests
        run_body_limit_tests
        run_directory_listing_tests
        run_concurrent_tests
        run_error_handling_tests
        run_keepalive_tests
        
        # Run 42 tester unless skipped
        if [ "$SKIP_42" = false ]; then
            run_42_tester
        fi
    fi
    
    # Stop server
    stop_server
    
    # Summary
    log_section "Test Summary"
    
    echo -e "  Total:   $TOTAL_TESTS"
    echo -e "  Passed:  ${GREEN}$PASSED_TESTS${NC}"
    echo -e "  Failed:  ${RED}$FAILED_TESTS${NC}"
    echo -e "  Skipped: ${YELLOW}$SKIPPED_TESTS${NC}"
    echo ""
    
    if [ $FAILED_TESTS -gt 0 ]; then
        echo -e "${RED}❌ Some tests failed!${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ All tests passed!${NC}"
    exit 0
}

# Run main
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    main "$@"
fi
