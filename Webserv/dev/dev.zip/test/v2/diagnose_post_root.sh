#!/bin/bash

echo "=== Diagnóstico POST a / ==="
echo ""

# Test 1: POST con body vacío
echo "Test 1: POST / (body vacío)"
curl -v -X POST http://localhost:8080/ 2>&1 | grep -E "< HTTP|< Content-Length|< Connection"
echo ""

# Test 2: POST con Content-Length: 0
echo "Test 2: POST / (Content-Length: 0)"
curl -v -X POST -H "Content-Length: 0" http://localhost:8080/ 2>&1 | grep -E "< HTTP|< Content-Length|< Connection"
echo ""

# Test 3: POST con body size 0 explícito
echo "Test 3: POST / con -d '' (body vacío explícito)"
curl -v -X POST -d '' http://localhost:8080/ 2>&1 | grep -E "< HTTP|< Content-Length|< Connection"
echo ""

# Test 4: Ver respuesta completa
echo "Test 4: Respuesta completa HTTP"
curl -i -X POST http://localhost:8080/ 2>&1 | head -20
