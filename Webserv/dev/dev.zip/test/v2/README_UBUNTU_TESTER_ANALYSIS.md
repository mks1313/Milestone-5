# Análisis del Fallo: ubuntu_tester POST /

## 📊 Estado del Tester

### ✅ Test que PASÓ:
```
Test GET http://localhost:8080/
content returned: <!DOCTYPE html>...
```

**Logs del servidor:**
```
[DEBUG] New connection from 172.17.0.1 on fd 6
[INFO] GET / from 172.17.0.1
[DEBUG] Closing connection fd 6
```

---

### ❌ Test que FALLÓ:
```
Test POST http://localhost:8080/ with a size of 0
FATAL ERROR ON LAST TEST: bad status code
```

**Logs del servidor:**
```
NO HAY NINGÚN LOG DEL POST ← ESTE ES EL PROBLEMA
```

---

## 🚨 PROBLEMA IDENTIFICADO

El servidor **NO está procesando el POST** en absoluto. El request POST no aparece en los logs, lo que significa una de estas cosas:

### Hipótesis 1: El servidor no responde al POST
- El socket acepta la conexión
- Pero no envía ninguna respuesta
- La conexión se cierra o timeout
- El tester ve esto como "bad status code"

### Hipótesis 2: El servidor responde con un código que el tester no espera
- El servidor devuelve 405 (correcto según HTTP)
- Pero el tester espera 200, 204 u otro código
- El tester considera 405 como "bad status code"

### Hipótesis 3: Hay un crash silencioso
- El parsing del POST con Content-Length: 0 causa un problema
- El servidor crashea o entra en un estado inválido
- No hay respuesta

---

## 🔍 DIAGNÓSTICO NECESARIO

He creado 3 scripts de diagnóstico. **Ejecuta estos pasos:**

### Paso 1: Iniciar el servidor
```bash
# En una terminal
./bin/webserv config/webserv.conf
```

### Paso 2: Ejecutar diagnóstico completo
```bash
# En otra terminal
bash diagnose_post_complete.sh
```

Este script:
1. ✅ Verifica que GET / funciona (200 OK)
2. 🔍 Envía POST / con Content-Length: 0 usando `nc` (raw)
3. 🔍 Envía POST / usando `curl`
4. 🔍 Simula exactamente lo que hace el ubuntu_tester
5. 📊 Muestra la respuesta completa del servidor

### Paso 3: Capturar los logs
Mientras ejecutas el script, **observa los logs del servidor** y anota:
- ¿Aparece `[INFO] POST / from ...`?
- ¿Hay algún error o excepción?
- ¿Se cierra la conexión inmediatamente?

---

## 🎯 LO QUE NECESITO VER

Envíame el output de:

### 1. Output del script de diagnóstico
```bash
bash diagnose_post_complete.sh > diagnostico.txt 2>&1
cat diagnostico.txt
```

### 2. Logs del servidor
```
Copia TODO el output del servidor durante las pruebas
Especialmente busca si hay alguna línea relacionada con POST
```

### 3. Respuesta HTTP completa
El script mostrará la respuesta RAW que devuelve el servidor. Necesito ver:
- Status code
- Headers (especialmente `Allow`, `Content-Length`, `Connection`)
- Body (si hay)

---

## 💡 SOLUCIONES POSIBLES (según lo que encontremos)

### Si el servidor NO responde:
**Problema**: Hay un bug en el manejo de POST con Content-Length: 0

**Solución**: Revisar el código de parsing y asegurar que envía una respuesta (aunque sea 405).

### Si el servidor devuelve 405:
**Problema**: El tester espera otro código

**Soluciones posibles:**
1. **Opción A**: Hacer que POST con body vacío devuelva 204 No Content
2. **Opción B**: Hacer que POST con body vacío devuelva 200 con body vacío
3. **Opción C**: Investigar qué espera exactamente el tester (buscar en Slack de 42)

### Si el servidor devuelve 200:
**Problema**: La configuración no está siendo respetada

**Solución**: Verificar que la location `/` tiene `methods GET;` y que el código de verificación funciona.

---

## 📝 CONFIGURACIÓN ACTUAL

Tu `webserv.conf` tiene:
```nginx
location / {
    methods GET;
    autoindex on;
}
```

Esto es **correcto según el subject**:
> "/ must answer to GET request ONLY"

El comportamiento HTTP correcto sería devolver **405 Method Not Allowed** para POST.

**PERO** algunos testers de 42 tienen bugs o expectativas no estándar.

---

## 🔬 INVESTIGACIÓN EN SLACK DE 42

Busca en el Slack de 42 Barcelona threads sobre:
- "ubuntu_tester POST bad status code"
- "POST / with size 0"
- "405 Method Not Allowed"

Algunos estudiantes reportaron que el tester:
- Espera 200 para POST vacío (aunque sea extraño)
- Tiene problemas con el header `Allow` en 405
- Requiere `Connection: close` específicamente

---

## 🚀 SIGUIENTE PASO INMEDIATO

1. **Ejecuta** `bash diagnose_post_complete.sh`
2. **Copia** el output completo
3. **Copia** los logs del servidor
4. **Envíame** ambos outputs

Con esa información sabré exactamente qué está pasando y cómo solucionarlo.

---

## 📦 Scripts Incluidos

1. **diagnose_post_complete.sh** - Diagnóstico completo (USAR ESTE)
2. **diagnose_post_root.sh** - Diagnóstico simple con curl
3. **simulate_tester.sh** - Simula el comportamiento del tester

---

**IMPORTANTE**: El hecho de que no haya logs del POST es muy sospechoso. Esto indica un problema fundamental en el manejo del request, no solo un código de status incorrecto.
