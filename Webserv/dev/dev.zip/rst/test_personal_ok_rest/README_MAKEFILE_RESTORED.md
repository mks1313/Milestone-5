# Makefile Restaurado - Reglas y Funcionalidades Recuperadas

## 📋 Resumen de Restauración

He analizado el backup (`ext_test.zip`) y comparado con el Makefile actual para restaurar funcionalidades que se simplificaron o eliminaron, manteniendo las mejoras de 42 que agregué.

---

## ✅ Reglas Restauradas

### 1. **Aliases de Siege**
```makefile
siege: test-benchmark
siege-quick: test-benchmark-quick
```
**Por qué**: Backward compatibility para usuarios acostumbrados a `make siege`

---

### 2. **test-upload**
```makefile
test-upload: $(NAME)
    # Prueba funcionalidad de subida de archivos
    # Crea archivo temporal, lo sube vía POST, y verifica
```
**Por qué**: Test específico de upload que se perdió

---

### 3. **test-telnet**
```makefile
test-telnet:
    # Muestra instrucciones para probar con telnet
    # telnet localhost 8080
    # GET / HTTP/1.1
    # Host: localhost
```
**Por qué**: Ayuda útil para debugging manual

---

### 4. **Backward Compatibility Aliases**
```makefile
test-legacy: test
test-stress: test-benchmark
```
**Por qué**: Scripts antiguos pueden usar estos nombres

---

## 🔧 Mejoras Restauradas

### 1. **install-siege - Más Gestores de Paquetes**

**ANTES** (simplificado):
```makefile
install-siege:
    @which siege || apt-get install siege || brew install siege
```

**AHORA** (completo):
```makefile
install-siege:
    @which siege || \
        (brew install siege) || \      # macOS
        (sudo apt-get install siege) || # Ubuntu/Debian
        (apk add --no-cache siege) ||   # Alpine
        printf "Please install manually"
```

**Beneficio**: Soporta macOS (brew), Ubuntu (apt-get), y Alpine (apk)

---

### 2. **docker-compile - Verificación + Mensajes Mejorados**

**ANTES** (simplificado):
```makefile
docker-compile:
    @docker exec $(DOCKER_CONTAINER) make re
```

**AHORA** (completo):
```makefile
docker-compile:
    # Verifica si container está running
    @if ! docker ps | grep $(DOCKER_CONTAINER); then
        make docker-start
    fi
    # Mensajes informativos
    @printf "Compiling inside container..."
    @docker exec -it $(DOCKER_CONTAINER) make re || sudo docker exec ...
    @printf "✅ Compilation completed"
    @printf "Binary at: $(PWD)/bin/webserv"
```

**Beneficio**: 
- Auto-start del container si no está running
- Mensajes claros de progreso
- Fallback con sudo
- Indica dónde está el binario compilado

---

### 3. **docker-run - Verificación + Fallback**

**ANTES**:
```makefile
docker-run:
    @docker exec $(DOCKER_CONTAINER) ./bin/webserv config.conf
```

**AHORA**:
```makefile
docker-run:
    @if ! docker ps | grep $(DOCKER_CONTAINER); then
        make docker-start
    fi
    @printf "Running webserv inside container..."
    @docker exec -it $(DOCKER_CONTAINER) ./bin/webserv config.conf || \
     sudo docker exec -it $(DOCKER_CONTAINER) ./bin/webserv config.conf
```

**Beneficio**: Auto-start + sudo fallback + mensajes

---

### 4. **docker-shell - Verificación + Fallback**

**ANTES**:
```makefile
docker-shell:
    @docker exec -it $(DOCKER_CONTAINER) bash
```

**AHORA**:
```makefile
docker-shell:
    @if ! docker ps | grep $(DOCKER_CONTAINER); then
        make docker-start
    fi
    @printf "Opening shell in container..."
    @docker exec -it $(DOCKER_CONTAINER) bash || sudo docker exec -it $(DOCKER_CONTAINER) bash
```

**Beneficio**: Auto-start + sudo fallback

---

## 🆕 Reglas 42 Mantenidas (NO en backup)

Estas son reglas nuevas que agregué para 42 y que **se mantienen**:

1. `test-42` - Ejecuta 42 official tester (interactivo)
2. `test-42-auto` - Ejecuta 42 tester automático (CI)
3. `test-42-diagnose` - Diagnóstico de requisitos 42
4. `test-42-verbose` - Tester con output detallado
5. `setup-42-env` - Setup de ambiente para 42
6. `check-42-testers` - Verifica testers de 42
7. `docker-build-alpine` - Build Docker con Alpine
8. `docker-build-ubuntu` - Build Docker con Ubuntu
9. `docker-start-alpine` - Start container Alpine
10. `docker-start-ubuntu` - Start container Ubuntu
11. `docker-use-alpine` - Selecciona Alpine
12. `docker-use-ubuntu` - Selecciona Ubuntu
13. `docker-test-42` - Tests 42 en Docker
14. `docker-test-42-auto` - Tests 42 auto en Docker
15. `docker-test-all` - Todos los tests en Docker
16. `docker-test-quick` - Tests rápidos en Docker
17. `docker-test-security` - Tests seguridad en Docker
18. `docker-test-subject` - Tests subject 42 en Docker
19. `docker-test-cgi` - Tests CGI en Docker
20. `docker-check-42-testers` - Verificar 42 testers en Docker

---

## 📊 Estadísticas

| Métrica | Antes (backup) | Después (actual) |
|---------|----------------|------------------|
| **Líneas totales** | 738 | ~750 |
| **Reglas totales** | 47 | 67 |
| **Reglas Docker** | 18 | 38 |
| **Reglas 42** | 0 | 20 |
| **Reglas Test** | 12 | 22 |

---

## ✅ Tests - Sin Cambios (Ya Actualizados)

Los tests en `/tests/` están **más actualizados** que el backup:

| Test | Backup | Actual | Cambios |
|------|--------|--------|---------|
| `benchmark_tests.sh` | 12092 bytes | 12092 bytes | Idéntico ✅ |
| `security_tests.sh` | 11969 bytes | 11977 bytes | +8 bytes (fix 405) ✅ |
| `siege_test.sh` | 979 bytes | 979 bytes | Idéntico ✅ |
| `test.sh` | 969 bytes | 969 bytes | Idéntico ✅ |
| `test_suite.sh` | 19288 bytes | 21193 bytes | +1905 bytes (mejoras 42) ✅ |

**Tests nuevos agregados** (NO en backup):
- `debug_server.sh` - Debug avanzado
- `diagnose_42_tester.sh` - Diagnóstico 42
- `setup_42_tester_env.sh` - Setup 42

---

## 🚫 Lo Que NO Se Restauró (Obsoleto/Duplicado)

1. **DOCKER_CONTAINER variable** - Ya definida en el Makefile
2. **docker-compose-up** (genérica) - Sustituida por docker-compose-up-ubuntu/alpine específicas
3. **docker-force-stop** - Ya incluida en docker-stop con -f flag

---

## 🎯 Filosofía de la Restauración

1. ✅ **Restaurar** reglas útiles que se perdieron
2. ✅ **Mejorar** reglas simplificadas con la versión completa
3. ✅ **Mantener** todas las nuevas funcionalidades de 42
4. ❌ **NO duplicar** reglas existentes
5. ❌ **NO degradar** tests que se mejoraron
6. ✅ **Agregar fallbacks** (sudo) donde hacía falta

---

## 🚀 Cómo Usar

```bash
# Extraer
tar -xzf webserv_MAKEFILE_RESTORED.tar.gz

# Verificar que todo compila
make re

# Probar reglas restauradas
make siege                  # Benchmark con siege
make test-upload            # Test de upload
make test-telnet            # Instrucciones telnet
make test-legacy            # Alias a test

# Probar reglas mejoradas
make install-siege          # Instala en macOS/Ubuntu/Alpine
make docker-compile         # Auto-start + mensajes
make docker-shell           # Auto-start + sudo fallback

# Reglas 42 (nuevas, mantenidas)
make test-42                # 42 official tester
make docker-test-42-auto    # 42 tests en Docker auto
```

---

## 📝 Resumen Final

| Categoría | Acciones |
|-----------|----------|
| **Reglas restauradas** | 6 (siege, siege-quick, test-upload, test-telnet, test-legacy, test-stress) |
| **Reglas mejoradas** | 4 (install-siege, docker-compile, docker-run, docker-shell) |
| **Reglas 42 agregadas** | 20 (todas mantenidas) |
| **Tests restaurados** | 0 (actuales más recientes) |
| **CGI scripts** | 5 (sin cambios, idénticos) |

---

**El Makefile ahora tiene la mejor combinación de funcionalidad original + mejoras de 42, sin perder nada.**
