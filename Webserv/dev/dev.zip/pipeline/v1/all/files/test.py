#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#    test.py - CGI Test Script for Webserv                                     #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

import os
import sys
import cgi
import cgitb

# Enable CGI error reporting
cgitb.enable()

# Output HTTP headers
print("Content-Type: text/html")
print("")

# Start HTML output
print("""<!DOCTYPE html>
<html>
<head>
    <title>CGI Test - Python</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; }
        table { border-collapse: collapse; width: 100%; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #4CAF50; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .success { color: green; }
        .section { margin: 20px 0; padding: 10px; background: #f9f9f9; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>🐍 Python CGI Test</h1>
    <p class="success">✅ CGI is working!</p>
""")

# Request Information
print('<div class="section">')
print('<h2>Request Information</h2>')
print('<table>')
print('<tr><th>Property</th><th>Value</th></tr>')
print(f'<tr><td>Request Method</td><td>{os.environ.get("REQUEST_METHOD", "N/A")}</td></tr>')
print(f'<tr><td>Query String</td><td>{os.environ.get("QUERY_STRING", "N/A")}</td></tr>')
print(f'<tr><td>Content Type</td><td>{os.environ.get("CONTENT_TYPE", "N/A")}</td></tr>')
print(f'<tr><td>Content Length</td><td>{os.environ.get("CONTENT_LENGTH", "N/A")}</td></tr>')
print(f'<tr><td>Script Name</td><td>{os.environ.get("SCRIPT_NAME", "N/A")}</td></tr>')
print(f'<tr><td>Path Info</td><td>{os.environ.get("PATH_INFO", "N/A")}</td></tr>')
print('</table>')
print('</div>')

# Server Information
print('<div class="section">')
print('<h2>Server Information</h2>')
print('<table>')
print('<tr><th>Property</th><th>Value</th></tr>')
print(f'<tr><td>Server Name</td><td>{os.environ.get("SERVER_NAME", "N/A")}</td></tr>')
print(f'<tr><td>Server Port</td><td>{os.environ.get("SERVER_PORT", "N/A")}</td></tr>')
print(f'<tr><td>Server Protocol</td><td>{os.environ.get("SERVER_PROTOCOL", "N/A")}</td></tr>')
print(f'<tr><td>Gateway Interface</td><td>{os.environ.get("GATEWAY_INTERFACE", "N/A")}</td></tr>')
print(f'<tr><td>Server Software</td><td>{os.environ.get("SERVER_SOFTWARE", "N/A")}</td></tr>')
print('</table>')
print('</div>')

# POST Data
if os.environ.get("REQUEST_METHOD") == "POST":
    print('<div class="section">')
    print('<h2>POST Data</h2>')
    
    content_length = int(os.environ.get("CONTENT_LENGTH", 0))
    if content_length > 0:
        post_data = sys.stdin.read(content_length)
        print(f'<pre>{post_data}</pre>')
    else:
        print('<p>No POST data received</p>')
    print('</div>')

# Query String Parameters
query_string = os.environ.get("QUERY_STRING", "")
if query_string:
    print('<div class="section">')
    print('<h2>Query String Parameters</h2>')
    print('<table>')
    print('<tr><th>Key</th><th>Value</th></tr>')
    
    for param in query_string.split("&"):
        if "=" in param:
            key, value = param.split("=", 1)
            print(f'<tr><td>{key}</td><td>{value}</td></tr>')
    
    print('</table>')
    print('</div>')

# All Environment Variables
print('<div class="section">')
print('<h2>All Environment Variables</h2>')
print('<table>')
print('<tr><th>Variable</th><th>Value</th></tr>')

for key, value in sorted(os.environ.items()):
    # Escape HTML
    value = str(value).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    print(f'<tr><td>{key}</td><td>{value}</td></tr>')

print('</table>')
print('</div>')

# Footer
print("""
    <hr>
    <p><small>Python CGI Test Script - Webserv 42 Project</small></p>
</body>
</html>
""")
