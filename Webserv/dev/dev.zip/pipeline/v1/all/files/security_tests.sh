#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    security_tests.sh - Security and Input Validation Tests                   #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"
PORT=8080

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

PASSED=0
FAILED=0

log_success() {
    echo -e "  ${GREEN}✅ PASS${NC}: $1"
    ((PASSED++))
}

log_fail() {
    echo -e "  ${RED}❌ FAIL${NC}: $1"
    ((FAILED++))
}

log_warn() {
    echo -e "  ${YELLOW}⚠️  WARN${NC}: $1"
}

wait_for_server() {
    for i in {1..30}; do
        nc -z localhost $PORT 2>/dev/null && return 0
        sleep 1
    done
    return 1
}

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}              Security & Input Validation Tests                ${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""

# Start server
"$WEBSERV" "$CONFIG" &
SERVER_PID=$!
trap "kill $SERVER_PID 2>/dev/null || true" EXIT

wait_for_server || { echo "Server failed to start"; exit 1; }

# =============================================================================
echo ""
echo "📝 Path Traversal Tests"
# =============================================================================

# Test directory traversal attempts
TRAVERSAL_PATHS=(
    "/../etc/passwd"
    "/..%2f..%2fetc/passwd"
    "/....//....//etc/passwd"
    "/%2e%2e/%2e%2e/etc/passwd"
    "/..\\..\\etc\\passwd"
    "/..%252f..%252fetc/passwd"
)

for path in "${TRAVERSAL_PATHS[@]}"; do
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT$path" 2>/dev/null || echo "000")
    BODY=$(curl -s "http://localhost:$PORT$path" 2>/dev/null || echo "")
    
    # Should not return actual /etc/passwd content
    if echo "$BODY" | grep -q "root:"; then
        log_fail "Path traversal possible: $path"
    elif [ "$STATUS" = "400" ] || [ "$STATUS" = "403" ] || [ "$STATUS" = "404" ]; then
        log_success "Path traversal blocked: $path ($STATUS)"
    else
        log_warn "Path traversal test inconclusive: $path ($STATUS)"
    fi
done

# =============================================================================
echo ""
echo "📝 Request Size Tests"
# =============================================================================

# Very long URL
LONG_PATH=$(python3 -c "print('/' + 'a' * 10000)")
STATUS=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT$LONG_PATH" 2>/dev/null || echo "414")
if [ "$STATUS" = "414" ] || [ "$STATUS" = "400" ] || [ "$STATUS" = "404" ]; then
    log_success "Long URL rejected ($STATUS)"
else
    log_warn "Long URL handling: $STATUS"
fi

# Very long header
LONG_HEADER=$(python3 -c "print('X-Test: ' + 'a' * 10000)")
STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "$LONG_HEADER" "http://localhost:$PORT/" 2>/dev/null || echo "431")
if [ "$STATUS" = "431" ] || [ "$STATUS" = "400" ] || [ "$STATUS" = "200" ]; then
    log_success "Long header handled ($STATUS)"
else
    log_warn "Long header handling: $STATUS"
fi

# Many headers
HEADERS=""
for i in {1..100}; do
    HEADERS="$HEADERS -H 'X-Custom-$i: value$i'"
done
STATUS=$(eval curl -s -o /dev/null -w "%{http_code}" $HEADERS "http://localhost:$PORT/" 2>/dev/null || echo "431")
if [ "$STATUS" = "431" ] || [ "$STATUS" = "400" ] || [ "$STATUS" = "200" ]; then
    log_success "Many headers handled ($STATUS)"
else
    log_warn "Many headers handling: $STATUS"
fi

# =============================================================================
echo ""
echo "📝 Malformed Request Tests"
# =============================================================================

# Request with no path
RESPONSE=$(echo -e "GET HTTP/1.1\r\nHost: localhost\r\n\r\n" | nc -w 2 localhost $PORT 2>/dev/null | head -1)
if echo "$RESPONSE" | grep -q "HTTP/1\.[01] [45]"; then
    log_success "Malformed request (no path) rejected"
else
    log_warn "Malformed request (no path) handling unclear"
fi

# Request with no HTTP version
RESPONSE=$(echo -e "GET /\r\nHost: localhost\r\n\r\n" | nc -w 2 localhost $PORT 2>/dev/null | head -1)
if echo "$RESPONSE" | grep -q "HTTP"; then
    log_success "Request without version handled"
else
    log_warn "Request without version handling unclear"
fi

# Double Content-Length (HTTP smuggling attempt)
RESPONSE=$(echo -e "GET / HTTP/1.1\r\nHost: localhost\r\nContent-Length: 0\r\nContent-Length: 10\r\n\r\n" | nc -w 2 localhost $PORT 2>/dev/null | head -1)
if echo "$RESPONSE" | grep -q "HTTP/1\.[01] [245]"; then
    log_success "Double Content-Length handled"
else
    log_warn "Double Content-Length handling unclear"
fi

# =============================================================================
echo ""
echo "📝 HTTP Method Tests"
# =============================================================================

METHODS=("TRACE" "CONNECT" "OPTIONS" "PATCH" "PROPFIND" "MKCOL" "COPY" "MOVE" "LOCK" "UNLOCK")

for method in "${METHODS[@]}"; do
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "http://localhost:$PORT/" 2>/dev/null || echo "501")
    if [ "$STATUS" = "501" ] || [ "$STATUS" = "405" ] || [ "$STATUS" = "400" ] || [ "$STATUS" = "200" ]; then
        log_success "Method $method handled ($STATUS)"
    else
        log_warn "Method $method returned $STATUS"
    fi
done

# =============================================================================
echo ""
echo "📝 Host Header Tests"
# =============================================================================

# Empty host
STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "Host:" "http://localhost:$PORT/" 2>/dev/null || echo "400")
if [ "$STATUS" = "400" ] || [ "$STATUS" = "200" ]; then
    log_success "Empty Host header handled ($STATUS)"
else
    log_warn "Empty Host header returned $STATUS"
fi

# Very long host
LONG_HOST=$(python3 -c "print('a' * 1000 + '.com')")
STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "Host: $LONG_HOST" "http://localhost:$PORT/" 2>/dev/null || echo "400")
if [ "$STATUS" = "400" ] || [ "$STATUS" = "200" ]; then
    log_success "Long Host header handled ($STATUS)"
else
    log_warn "Long Host header returned $STATUS"
fi

# =============================================================================
echo ""
echo "📝 Content-Type Tests"
# =============================================================================

# POST without Content-Type
STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "data" "http://localhost:$PORT/" 2>/dev/null || echo "200")
if [ "$STATUS" = "200" ] || [ "$STATUS" = "400" ]; then
    log_success "POST without Content-Type handled ($STATUS)"
else
    log_warn "POST without Content-Type returned $STATUS"
fi

# =============================================================================
echo ""
echo "📝 Slow Client Tests (Limited)"
# =============================================================================

# Slow headers (potential Slowloris)
{
    echo -ne "GET / HTTP/1.1\r\n"
    echo -ne "Host: localhost\r\n"
    sleep 2
    echo -ne "Connection: close\r\n"
    echo -ne "\r\n"
} | nc -w 5 localhost $PORT > /dev/null 2>&1 &
SLOW_PID=$!

# Server should still be responsive
sleep 1
STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://localhost:$PORT/" 2>/dev/null || echo "000")
if [ "$STATUS" = "200" ]; then
    log_success "Server responsive during slow client"
else
    log_warn "Server response during slow client: $STATUS"
fi

kill $SLOW_PID 2>/dev/null || true

# =============================================================================
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "Results: $PASSED passed, $FAILED failed"
echo ""

if [ $FAILED -gt 0 ]; then
    echo -e "${RED}❌ Some security tests failed${NC}"
    exit 1
fi

echo -e "${GREEN}✅ All security tests passed${NC}"
exit 0
