#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    benchmark_tests.sh - Performance and Benchmark Tests                      #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"
PORT=8080

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Default values
CONCURRENT_USERS=${1:-50}
DURATION=${2:-30}
WARMUP_REQUESTS=100

wait_for_server() {
    for i in {1..30}; do
        nc -z localhost $PORT 2>/dev/null && return 0
        sleep 1
    done
    return 1
}

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}              Performance & Benchmark Tests                     ${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${BLUE}Configuration:${NC}"
echo "  Concurrent users: $CONCURRENT_USERS"
echo "  Duration: ${DURATION}s"
echo "  Port: $PORT"
echo ""

# Check for required tools
if ! command -v siege &> /dev/null; then
    echo -e "${RED}Error: siege is not installed${NC}"
    echo "Install with: apt install siege / brew install siege"
    exit 1
fi

# Start server
"$WEBSERV" "$CONFIG" &
SERVER_PID=$!
trap "kill $SERVER_PID 2>/dev/null || true" EXIT

wait_for_server || { echo "Server failed to start"; exit 1; }
echo -e "${GREEN}✅ Server started${NC}"

# =============================================================================
echo ""
echo -e "${CYAN}📝 Warmup Phase${NC}"
# =============================================================================

echo "Running $WARMUP_REQUESTS warmup requests..."
for i in $(seq 1 $WARMUP_REQUESTS); do
    curl -s "http://localhost:$PORT/" > /dev/null &
done
wait
echo "Warmup complete"

# =============================================================================
echo ""
echo -e "${CYAN}📝 Siege Stress Test${NC}"
# =============================================================================

echo "Running siege with $CONCURRENT_USERS concurrent users for ${DURATION}s..."
echo ""

# Configure siege silently
mkdir -p ~/.siege 2>/dev/null
cat > ~/.siege/siege.conf << EOF
verbose = false
quiet = true
json_output = false
show-logfile = false
logging = false
protocol = HTTP/1.1
chunked = true
connection = keep-alive
concurrent = $CONCURRENT_USERS
time = ${DURATION}S
EOF

# Run siege and capture output
siege -b -c $CONCURRENT_USERS -t ${DURATION}S "http://localhost:$PORT/" 2>&1 | tee /tmp/siege_results.txt

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}                    Benchmark Results                           ${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"

# Parse results
AVAILABILITY=$(grep "Availability:" /tmp/siege_results.txt | awk '{print $2}' | tr -d '%')
TRANSACTIONS=$(grep "Transactions:" /tmp/siege_results.txt | awk '{print $2}')
TRANS_RATE=$(grep "Transaction rate:" /tmp/siege_results.txt | awk '{print $3}')
RESPONSE_TIME=$(grep "Response time:" /tmp/siege_results.txt | awk '{print $3}')
THROUGHPUT=$(grep "Throughput:" /tmp/siege_results.txt | awk '{print $2}')
CONCURRENCY=$(grep "Concurrency:" /tmp/siege_results.txt | awk '{print $2}')
FAILED=$(grep "Failed transactions:" /tmp/siege_results.txt | awk '{print $3}')
LONGEST=$(grep "Longest transaction:" /tmp/siege_results.txt | awk '{print $3}')
SHORTEST=$(grep "Shortest transaction:" /tmp/siege_results.txt | awk '{print $3}')

echo ""
echo -e "${BLUE}Performance Metrics:${NC}"
echo "  Availability:      ${AVAILABILITY:-N/A}%"
echo "  Total Transactions: ${TRANSACTIONS:-N/A}"
echo "  Transaction Rate:  ${TRANS_RATE:-N/A} trans/sec"
echo "  Response Time:     ${RESPONSE_TIME:-N/A} secs"
echo "  Throughput:        ${THROUGHPUT:-N/A} MB/sec"
echo "  Concurrency:       ${CONCURRENCY:-N/A}"
echo "  Failed:            ${FAILED:-N/A}"
echo "  Longest Trans:     ${LONGEST:-N/A} secs"
echo "  Shortest Trans:    ${SHORTEST:-N/A} secs"

# =============================================================================
echo ""
echo -e "${CYAN}📝 Performance Evaluation${NC}"
# =============================================================================

PASS_COUNT=0
WARN_COUNT=0
FAIL_COUNT=0

# Availability check (target: > 99.5%)
if [ -n "$AVAILABILITY" ]; then
    if (( $(echo "$AVAILABILITY >= 99.5" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${GREEN}✅ Availability >= 99.5%${NC} ($AVAILABILITY%)"
        ((PASS_COUNT++))
    elif (( $(echo "$AVAILABILITY >= 95" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${YELLOW}⚠️  Availability between 95-99.5%${NC} ($AVAILABILITY%)"
        ((WARN_COUNT++))
    else
        echo -e "  ${RED}❌ Availability < 95%${NC} ($AVAILABILITY%)"
        ((FAIL_COUNT++))
    fi
fi

# Response time check (target: < 1s)
if [ -n "$RESPONSE_TIME" ]; then
    if (( $(echo "$RESPONSE_TIME < 1.0" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${GREEN}✅ Response time < 1s${NC} (${RESPONSE_TIME}s)"
        ((PASS_COUNT++))
    elif (( $(echo "$RESPONSE_TIME < 2.0" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${YELLOW}⚠️  Response time between 1-2s${NC} (${RESPONSE_TIME}s)"
        ((WARN_COUNT++))
    else
        echo -e "  ${RED}❌ Response time > 2s${NC} (${RESPONSE_TIME}s)"
        ((FAIL_COUNT++))
    fi
fi

# Transaction rate check (target: > 100 trans/sec for 50 concurrent users)
if [ -n "$TRANS_RATE" ]; then
    if (( $(echo "$TRANS_RATE >= 100" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${GREEN}✅ Transaction rate >= 100/sec${NC} (${TRANS_RATE}/sec)"
        ((PASS_COUNT++))
    elif (( $(echo "$TRANS_RATE >= 50" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${YELLOW}⚠️  Transaction rate between 50-100/sec${NC} (${TRANS_RATE}/sec)"
        ((WARN_COUNT++))
    else
        echo -e "  ${RED}❌ Transaction rate < 50/sec${NC} (${TRANS_RATE}/sec)"
        ((FAIL_COUNT++))
    fi
fi

# Failed transactions check (target: 0)
if [ -n "$FAILED" ]; then
    if [ "$FAILED" = "0" ]; then
        echo -e "  ${GREEN}✅ No failed transactions${NC}"
        ((PASS_COUNT++))
    elif [ "$FAILED" -lt "10" ]; then
        echo -e "  ${YELLOW}⚠️  Few failed transactions${NC} ($FAILED)"
        ((WARN_COUNT++))
    else
        echo -e "  ${RED}❌ Many failed transactions${NC} ($FAILED)"
        ((FAIL_COUNT++))
    fi
fi

# =============================================================================
echo ""
echo -e "${CYAN}📝 Additional Quick Tests${NC}"
# =============================================================================

# Test server responsiveness after stress test
echo -n "  Server responsive after stress test: "
STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://localhost:$PORT/" 2>/dev/null)
if [ "$STATUS" = "200" ]; then
    echo -e "${GREEN}✅ Yes${NC}"
    ((PASS_COUNT++))
else
    echo -e "${RED}❌ No ($STATUS)${NC}"
    ((FAIL_COUNT++))
fi

# Test multiple quick consecutive requests
echo -n "  Handles rapid requests: "
SUCCESS=0
for i in {1..10}; do
    S=$(curl -s -o /dev/null -w "%{http_code}" --max-time 2 "http://localhost:$PORT/" 2>/dev/null)
    [ "$S" = "200" ] && ((SUCCESS++))
done
if [ $SUCCESS -eq 10 ]; then
    echo -e "${GREEN}✅ 10/10${NC}"
    ((PASS_COUNT++))
else
    echo -e "${YELLOW}⚠️  $SUCCESS/10${NC}"
    ((WARN_COUNT++))
fi

# =============================================================================
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}                    Summary                                     ${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${GREEN}Passed:${NC}   $PASS_COUNT"
echo -e "  ${YELLOW}Warnings:${NC} $WARN_COUNT"
echo -e "  ${RED}Failed:${NC}   $FAIL_COUNT"
echo ""

# Clean up
rm -f /tmp/siege_results.txt

if [ $FAIL_COUNT -gt 0 ]; then
    echo -e "${RED}❌ Performance issues detected${NC}"
    exit 1
elif [ $WARN_COUNT -gt 0 ]; then
    echo -e "${YELLOW}⚠️  Performance acceptable with warnings${NC}"
    exit 0
else
    echo -e "${GREEN}✅ Performance test passed!${NC}"
    exit 0
fi
