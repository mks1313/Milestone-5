#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    test_suite.sh - Complete Test Suite for Webserv                           #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

set -e

# =============================================================================
# Configuration
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"
PORT=8080
TIMEOUT=60

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
SKIPPED_TESTS=0

# =============================================================================
# Utility Functions
# =============================================================================

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[PASS]${NC} $1"
    ((PASSED_TESTS++))
    ((TOTAL_TESTS++))
}

log_fail() {
    echo -e "${RED}[FAIL]${NC} $1"
    ((FAILED_TESTS++))
    ((TOTAL_TESTS++))
}

log_skip() {
    echo -e "${YELLOW}[SKIP]${NC} $1"
    ((SKIPPED_TESTS++))
    ((TOTAL_TESTS++))
}

log_section() {
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
}

wait_for_server() {
    local port=${1:-$PORT}
    local max_wait=${2:-30}
    
    for i in $(seq 1 $max_wait); do
        if nc -z localhost $port 2>/dev/null; then
            return 0
        fi
        sleep 1
    done
    return 1
}

start_server() {
    local config=${1:-$CONFIG}
    
    if [ ! -f "$WEBSERV" ]; then
        log_fail "Binary not found: $WEBSERV"
        exit 1
    fi
    
    "$WEBSERV" "$config" &
    SERVER_PID=$!
    
    if ! wait_for_server; then
        log_fail "Server failed to start"
        return 1
    fi
    
    return 0
}

stop_server() {
    if [ -n "$SERVER_PID" ]; then
        kill $SERVER_PID 2>/dev/null || true
        wait $SERVER_PID 2>/dev/null || true
        SERVER_PID=""
    fi
    pkill -f "$WEBSERV" 2>/dev/null || true
    sleep 1
}

cleanup() {
    stop_server
    rm -f /tmp/webserv_test_* 2>/dev/null || true
}

trap cleanup EXIT

# =============================================================================
# Test Functions
# =============================================================================

test_http_status() {
    local method="$1"
    local url="$2"
    local expected="$3"
    local description="$4"
    local data="$5"
    
    local curl_opts="-s -o /dev/null -w %{http_code}"
    
    if [ "$method" = "POST" ] && [ -n "$data" ]; then
        curl_opts="$curl_opts -X POST -d '$data'"
    elif [ "$method" != "GET" ]; then
        curl_opts="$curl_opts -X $method"
    fi
    
    local status
    if [ "$method" = "POST" ] && [ -n "$data" ]; then
        status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "$data" "$url")
    elif [ "$method" != "GET" ]; then
        status=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url")
    else
        status=$(curl -s -o /dev/null -w "%{http_code}" "$url")
    fi
    
    if [ "$status" = "$expected" ]; then
        log_success "$description (got $status)"
    else
        log_fail "$description (expected $expected, got $status)"
    fi
}

test_header_exists() {
    local url="$1"
    local header="$2"
    local description="$3"
    
    local response
    response=$(curl -s -I "$url")
    
    if echo "$response" | grep -qi "$header"; then
        log_success "$description"
    else
        log_fail "$description (header '$header' not found)"
    fi
}

test_body_contains() {
    local url="$1"
    local pattern="$2"
    local description="$3"
    
    local response
    response=$(curl -s "$url")
    
    if echo "$response" | grep -q "$pattern"; then
        log_success "$description"
    else
        log_fail "$description (pattern '$pattern' not found)"
    fi
}

# =============================================================================
# Test Suites
# =============================================================================

run_basic_tests() {
    log_section "Basic HTTP Tests"
    
    test_http_status "GET" "http://localhost:$PORT/" "200" "GET / returns 200"
    test_http_status "GET" "http://localhost:$PORT/index.html" "200" "GET /index.html returns 200"
    test_http_status "GET" "http://localhost:$PORT/nonexistent" "404" "GET /nonexistent returns 404"
    test_http_status "HEAD" "http://localhost:$PORT/" "200" "HEAD / returns 200"
}

run_method_tests() {
    log_section "HTTP Method Tests"
    
    test_http_status "GET" "http://localhost:$PORT/" "200" "GET method works"
    test_http_status "POST" "http://localhost:$PORT/" "200" "POST method works" "test=data"
    
    # DELETE test - create a file first
    echo "test content" > "$PROJECT_DIR/www/deletable/ci_test_delete.txt"
    test_http_status "DELETE" "http://localhost:$PORT/deletable/ci_test_delete.txt" "200" "DELETE method works"
    
    # Invalid method
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" -X INVALID "http://localhost:$PORT/")
    if [ "$status" = "501" ] || [ "$status" = "405" ] || [ "$status" = "400" ]; then
        log_success "Invalid method returns error ($status)"
    else
        log_fail "Invalid method should return 501/405/400 (got $status)"
    fi
}

run_header_tests() {
    log_section "HTTP Header Tests"
    
    test_header_exists "http://localhost:$PORT/" "Content-Type" "Content-Type header present"
    test_header_exists "http://localhost:$PORT/" "Content-Length" "Content-Length header present"
    test_header_exists "http://localhost:$PORT/" "Connection" "Connection header present"
    test_header_exists "http://localhost:$PORT/" "Server" "Server header present"
    
    # Check HTTP version
    local response
    response=$(curl -s -I "http://localhost:$PORT/")
    if echo "$response" | grep -q "HTTP/1.1"; then
        log_success "Server responds with HTTP/1.1"
    else
        log_fail "Server should respond with HTTP/1.1"
    fi
}

run_mime_type_tests() {
    log_section "MIME Type Tests"
    
    # Create test files
    echo "<html></html>" > "$PROJECT_DIR/www/test.html"
    echo "body {}" > "$PROJECT_DIR/www/test.css"
    echo "alert(1);" > "$PROJECT_DIR/www/test.js"
    echo "plain text" > "$PROJECT_DIR/www/test.txt"
    
    local content_type
    
    content_type=$(curl -s -I "http://localhost:$PORT/test.html" | grep -i "Content-Type" | tr -d '\r')
    if echo "$content_type" | grep -qi "text/html"; then
        log_success "HTML files have text/html MIME type"
    else
        log_fail "HTML files should have text/html MIME type"
    fi
    
    content_type=$(curl -s -I "http://localhost:$PORT/test.css" | grep -i "Content-Type" | tr -d '\r')
    if echo "$content_type" | grep -qi "text/css"; then
        log_success "CSS files have text/css MIME type"
    else
        log_fail "CSS files should have text/css MIME type"
    fi
    
    # Cleanup
    rm -f "$PROJECT_DIR/www/test.html" "$PROJECT_DIR/www/test.css" \
          "$PROJECT_DIR/www/test.js" "$PROJECT_DIR/www/test.txt"
}

run_cgi_tests() {
    log_section "CGI Tests"
    
    if [ ! -f "$PROJECT_DIR/cgi-bin/test.py" ]; then
        log_skip "CGI test script not found"
        return
    fi
    
    chmod +x "$PROJECT_DIR/cgi-bin/"*.py 2>/dev/null || true
    
    test_http_status "GET" "http://localhost:$PORT/cgi-bin/test.py" "200" "CGI GET returns 200"
    test_http_status "POST" "http://localhost:$PORT/cgi-bin/test.py" "200" "CGI POST returns 200" "name=test"
    
    # Test CGI with query string
    test_http_status "GET" "http://localhost:$PORT/cgi-bin/test.py?param=value" "200" "CGI with query string"
    
    # Test CGI content
    test_body_contains "http://localhost:$PORT/cgi-bin/test.py" "Python" "CGI returns expected content"
}

run_redirect_tests() {
    log_section "Redirect Tests"
    
    # Test redirect (if configured)
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" -L "http://localhost:$PORT/redirect" 2>/dev/null || echo "N/A")
    
    if [ "$status" = "N/A" ] || [ "$status" = "000" ]; then
        log_skip "Redirect endpoint not configured"
    elif [ "$status" = "200" ] || [ "$status" = "301" ] || [ "$status" = "302" ]; then
        log_success "Redirect works ($status)"
    else
        log_fail "Redirect should return 301/302 (got $status)"
    fi
}

run_concurrent_tests() {
    log_section "Concurrent Connection Tests"
    
    log_info "Testing concurrent connections..."
    
    # Launch multiple requests simultaneously
    local pids=()
    for i in {1..20}; do
        curl -s "http://localhost:$PORT/" > /dev/null &
        pids+=($!)
    done
    
    # Wait for all requests
    local failed=0
    for pid in "${pids[@]}"; do
        wait $pid || ((failed++))
    done
    
    if [ $failed -eq 0 ]; then
        log_success "Handled 20 concurrent connections"
    else
        log_fail "Failed $failed out of 20 concurrent connections"
    fi
    
    # Verify server still responsive
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/")
    if [ "$status" = "200" ]; then
        log_success "Server responsive after concurrent test"
    else
        log_fail "Server not responsive after concurrent test"
    fi
}

run_error_handling_tests() {
    log_section "Error Handling Tests"
    
    # 404 error
    test_http_status "GET" "http://localhost:$PORT/this_does_not_exist" "404" "404 for missing file"
    
    # Method not allowed (if configured)
    # This depends on your configuration
    
    # Large request (body size limit)
    local large_data
    large_data=$(dd if=/dev/zero bs=1M count=2 2>/dev/null | base64)
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "$large_data" "http://localhost:$PORT/" 2>/dev/null || echo "413")
    
    if [ "$status" = "413" ] || [ "$status" = "200" ]; then
        log_success "Large request handled ($status)"
    else
        log_fail "Large request handling (got $status)"
    fi
}

run_keepalive_tests() {
    log_section "Keep-Alive Tests"
    
    # Multiple requests on same connection
    log_info "Testing HTTP keep-alive..."
    
    local response
    response=$(curl -s -I "http://localhost:$PORT/" -H "Connection: keep-alive")
    
    if echo "$response" | grep -qi "keep-alive"; then
        log_success "Server supports keep-alive"
    else
        log_skip "Keep-alive may not be enabled"
    fi
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo ""
    echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║           Webserv Complete Test Suite                         ║${NC}"
    echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # Check prerequisites
    if [ ! -f "$WEBSERV" ]; then
        log_info "Building webserv..."
        cd "$PROJECT_DIR"
        make re || { log_fail "Build failed"; exit 1; }
    fi
    
    if [ ! -f "$CONFIG" ]; then
        log_fail "Config file not found: $CONFIG"
        exit 1
    fi
    
    # Setup test directories
    mkdir -p "$PROJECT_DIR/www/uploads" \
             "$PROJECT_DIR/www/errors" \
             "$PROJECT_DIR/www/deletable" \
             "$PROJECT_DIR/logs"
    
    # Create test files if missing
    [ -f "$PROJECT_DIR/www/index.html" ] || echo "<html><body>Test</body></html>" > "$PROJECT_DIR/www/index.html"
    [ -f "$PROJECT_DIR/www/errors/404.html" ] || echo "<html><body>404</body></html>" > "$PROJECT_DIR/www/errors/404.html"
    
    # Start server
    log_info "Starting server..."
    if ! start_server; then
        log_fail "Could not start server"
        exit 1
    fi
    log_success "Server started on port $PORT"
    
    # Run all test suites
    run_basic_tests
    run_method_tests
    run_header_tests
    run_mime_type_tests
    run_cgi_tests
    run_redirect_tests
    run_concurrent_tests
    run_error_handling_tests
    run_keepalive_tests
    
    # Stop server
    stop_server
    
    # Summary
    log_section "Test Summary"
    
    echo -e "Total:   ${CYAN}$TOTAL_TESTS${NC}"
    echo -e "Passed:  ${GREEN}$PASSED_TESTS${NC}"
    echo -e "Failed:  ${RED}$FAILED_TESTS${NC}"
    echo -e "Skipped: ${YELLOW}$SKIPPED_TESTS${NC}"
    echo ""
    
    if [ $FAILED_TESTS -gt 0 ]; then
        echo -e "${RED}❌ Some tests failed!${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ All tests passed!${NC}"
    exit 0
}

# Run if executed directly
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    main "$@"
fi
