#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#    env.py - Environment Variables CGI Script                                 #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

import os

# Output headers
print("Content-Type: text/plain")
print("")

# Required CGI environment variables per RFC 3875
required_vars = [
    'REQUEST_METHOD',
    'QUERY_STRING',
    'CONTENT_TYPE',
    'CONTENT_LENGTH',
    'SERVER_NAME',
    'SERVER_PORT',
    'SERVER_PROTOCOL',
    'GATEWAY_INTERFACE',
    'SCRIPT_NAME',
    'PATH_INFO',
    'PATH_TRANSLATED',
    'REMOTE_ADDR',
    'REMOTE_HOST',
    'HTTP_HOST',
    'HTTP_USER_AGENT',
    'HTTP_ACCEPT',
    'HTTP_COOKIE'
]

print("=== Required CGI Environment Variables ===")
print("")

for var in required_vars:
    value = os.environ.get(var, 'NOT_SET')
    status = '✅' if value != 'NOT_SET' else '❌'
    print(f"{status} {var}={value}")

print("")
print("=== All Environment Variables ===")
print("")

for key, value in sorted(os.environ.items()):
    print(f"{key}={value}")
