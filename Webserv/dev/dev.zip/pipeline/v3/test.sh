#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    test.sh - Backward Compatibility Wrapper                                  #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
#    This script wraps test_suite.sh for backward compatibility.               #
#    All functionality has been consolidated into test_suite.sh                #
#                                                                              #
# **************************************************************************** #

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Forward all arguments to the main test script
exec "$SCRIPT_DIR/test_suite.sh" "$@"
