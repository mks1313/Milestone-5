#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    test_suite.sh - Complete Integration Test Suite for Webserv               #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
#    This is the MAIN test script. For backward compatibility:                 #
#    - test.sh calls this script                                               #
#                                                                              #
# **************************************************************************** #

# =============================================================================
# Configuration
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"

# Default ports
PORT=8080
PORT2=8081
PORT3=8082

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Counters
PASSED=0
FAILED=0
SKIPPED=0

# Options
QUICK_MODE=0
VERBOSE=0
NO_START=0

# =============================================================================
# Argument Parsing
# =============================================================================
show_help() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -q, --quick       Skip slow tests (concurrent, stress)"
    echo "  -v, --verbose     Show detailed output"
    echo "  -p, --port PORT   Use custom port (default: 8080)"
    echo "  -c, --config FILE Use custom config file"
    echo "  --no-start        Don't start server (assume running)"
    echo "  -h, --help        Show this help"
}

while [[ $# -gt 0 ]]; do
    case $1 in
        -q|--quick) QUICK_MODE=1; shift ;;
        -v|--verbose) VERBOSE=1; shift ;;
        -p|--port) PORT="$2"; shift 2 ;;
        -c|--config) CONFIG="$2"; shift 2 ;;
        --no-start) NO_START=1; shift ;;
        -h|--help) show_help; exit 0 ;;
        *) echo "Unknown option: $1"; show_help; exit 1 ;;
    esac
done

# =============================================================================
# Utility Functions
# =============================================================================
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "  ${GREEN}✅ PASS${NC}: $1"; ((PASSED++)); }
log_fail() { echo -e "  ${RED}❌ FAIL${NC}: $1"; ((FAILED++)); }
log_skip() { echo -e "  ${YELLOW}⏭️  SKIP${NC}: $1"; ((SKIPPED++)); }

log_section() {
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
}

wait_for_server() {
    local port=${1:-$PORT}
    for i in $(seq 1 30); do
        nc -z localhost $port 2>/dev/null && return 0
        sleep 1
    done
    return 1
}

start_server() {
    if [ ! -f "$WEBSERV" ]; then
        log_info "Binary not found, building..."
        cd "$PROJECT_DIR"
        make -j$(nproc) 2>/dev/null || make 2>/dev/null || { log_fail "Build failed"; return 1; }
    fi
    
    "$WEBSERV" "$CONFIG" &
    SERVER_PID=$!
    
    wait_for_server $PORT || { log_fail "Server failed to start"; return 1; }
    return 0
}

stop_server() {
    [ -n "$SERVER_PID" ] && { kill $SERVER_PID 2>/dev/null; wait $SERVER_PID 2>/dev/null; }
    SERVER_PID=""
    pkill -f "webserv.*$CONFIG" 2>/dev/null || true
    sleep 1
}

cleanup() {
    stop_server
    rm -f /tmp/webserv_test_* /tmp/large_body.txt /tmp/test_upload.txt 2>/dev/null
    rm -f "$PROJECT_DIR/www/deletable/test_delete.txt" 2>/dev/null
    rm -f "$PROJECT_DIR/www/test.html" "$PROJECT_DIR/www/test.css" "$PROJECT_DIR/www/test.js" 2>/dev/null
}

trap cleanup EXIT

# =============================================================================
# Test Functions
# =============================================================================
test_http_status() {
    local method="$1" url="$2" expected="$3" description="$4" data="$5"
    local status
    
    case "$method" in
        GET)  status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "$url" 2>/dev/null) ;;
        POST) status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -X POST ${data:+-d "$data"} "$url" 2>/dev/null) ;;
        DELETE) status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -X DELETE "$url" 2>/dev/null) ;;
        HEAD) status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -I "$url" 2>/dev/null) ;;
        *) status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -X "$method" "$url" 2>/dev/null) ;;
    esac
    
    [ "$status" = "$expected" ] && log_success "$description (got $status)" || log_fail "$description (expected $expected, got $status)"
}

test_header_exists() {
    local url="$1" header="$2" description="$3"
    curl -s -I --max-time 10 "$url" 2>/dev/null | grep -qi "$header" && log_success "$description" || log_fail "$description (header not found)"
}

# =============================================================================
# Test Suites
# =============================================================================
run_basic_tests() {
    log_section "Basic HTTP Tests"
    test_http_status "GET" "http://localhost:$PORT/" "200" "GET / returns 200"
    test_http_status "GET" "http://localhost:$PORT/index.html" "200" "GET /index.html returns 200"
    test_http_status "GET" "http://localhost:$PORT/nonexistent.html" "404" "GET non-existent returns 404"
    test_http_status "HEAD" "http://localhost:$PORT/" "200" "HEAD / returns 200"
}

run_method_tests() {
    log_section "HTTP Method Tests"
    test_http_status "GET" "http://localhost:$PORT/" "200" "GET method"
    test_http_status "POST" "http://localhost:$PORT/cgi-bin/test.py" "200" "POST to CGI" "name=test"
    
    # DELETE test
    mkdir -p "$PROJECT_DIR/www/deletable" 2>/dev/null
    echo "test" > "$PROJECT_DIR/www/deletable/test_delete.txt"
    local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -X DELETE "http://localhost:$PORT/deletable/test_delete.txt" 2>/dev/null)
    [[ "$status" =~ ^(200|204)$ ]] && log_success "DELETE file ($status)" || log_fail "DELETE file (got $status)"
    
    test_http_status "DELETE" "http://localhost:$PORT/deletable/nonexistent.txt" "404" "DELETE non-existent"
    
    # Invalid methods
    status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -X PUT "http://localhost:$PORT/" 2>/dev/null)
    [[ "$status" =~ ^(405|501)$ ]] && log_success "PUT returns error ($status)" || log_fail "PUT (got $status)"
    
    status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -X UNKNOWN "http://localhost:$PORT/" 2>/dev/null)
    [[ "$status" =~ ^(400|405|501)$ ]] && log_success "Unknown method error ($status)" || log_fail "Unknown method (got $status)"
}

run_header_tests() {
    log_section "HTTP Header Tests"
    test_header_exists "http://localhost:$PORT/" "Content-Type" "Content-Type present"
    test_header_exists "http://localhost:$PORT/" "Content-Length" "Content-Length present"
    test_header_exists "http://localhost:$PORT/" "Connection" "Connection present"
    test_header_exists "http://localhost:$PORT/" "Server" "Server present"
    
    curl -s -I --max-time 10 "http://localhost:$PORT/" 2>/dev/null | grep -q "HTTP/1.1" && \
        log_success "Server responds HTTP/1.1" || log_fail "Should respond HTTP/1.1"
}

run_mime_type_tests() {
    log_section "MIME Type Tests"
    echo "<html></html>" > "$PROJECT_DIR/www/test.html"
    echo "body {}" > "$PROJECT_DIR/www/test.css"
    echo "alert(1);" > "$PROJECT_DIR/www/test.js"
    
    curl -s -I --max-time 10 "http://localhost:$PORT/test.html" 2>/dev/null | grep -qi "text/html" && \
        log_success "HTML has text/html" || log_fail "HTML MIME type"
    curl -s -I --max-time 10 "http://localhost:$PORT/test.css" 2>/dev/null | grep -qi "text/css" && \
        log_success "CSS has text/css" || log_fail "CSS MIME type"
    
    rm -f "$PROJECT_DIR/www/test.html" "$PROJECT_DIR/www/test.css" "$PROJECT_DIR/www/test.js" 2>/dev/null
}

run_cgi_tests() {
    log_section "CGI Tests"
    
    [ -f "$PROJECT_DIR/cgi-bin/test.py" ] || { log_skip "CGI test.py not found"; return; }
    chmod +x "$PROJECT_DIR/cgi-bin/"*.py 2>/dev/null || true
    
    test_http_status "GET" "http://localhost:$PORT/cgi-bin/test.py" "200" "CGI test.py GET"
    test_http_status "POST" "http://localhost:$PORT/cgi-bin/test.py" "200" "CGI test.py POST" "name=test"
    test_http_status "GET" "http://localhost:$PORT/cgi-bin/test.py?param=value" "200" "CGI query string"
    
    [ -f "$PROJECT_DIR/cgi-bin/info.py" ] && test_http_status "GET" "http://localhost:$PORT/cgi-bin/info.py" "200" "CGI info.py" || log_skip "info.py not found"
    [ -f "$PROJECT_DIR/cgi-bin/session.py" ] && test_http_status "GET" "http://localhost:$PORT/cgi-bin/session.py" "200" "CGI session.py" || log_skip "session.py not found"
    [ -f "$PROJECT_DIR/cgi-bin/env.py" ] && test_http_status "GET" "http://localhost:$PORT/cgi-bin/env.py" "200" "CGI env.py" || log_skip "env.py not found"
}

run_redirect_tests() {
    log_section "Redirect Tests"
    local status
    
    status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 --max-redirs 0 "http://localhost:$PORT/old-page" 2>/dev/null)
    [ "$status" = "301" ] && log_success "301 Redirect" || [ "$status" = "404" ] && log_skip "301 not configured" || log_fail "301 Redirect (got $status)"
    
    status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 --max-redirs 0 "http://localhost:$PORT/google" 2>/dev/null)
    [ "$status" = "302" ] && log_success "302 Redirect" || [ "$status" = "404" ] && log_skip "302 not configured" || log_fail "302 Redirect (got $status)"
}

run_multi_port_tests() {
    log_section "Multiple Ports Tests"
    nc -z localhost $PORT2 2>/dev/null && test_http_status "GET" "http://localhost:$PORT2/" "200" "Port $PORT2" || log_skip "Port $PORT2 not listening"
    nc -z localhost $PORT3 2>/dev/null && test_http_status "GET" "http://localhost:$PORT3/" "200" "Port $PORT3" || log_skip "Port $PORT3 not listening"
}

run_virtual_host_tests() {
    log_section "Virtual Host Tests"
    local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -H "Host: example.local" "http://localhost:$PORT/" 2>/dev/null)
    [ "$status" = "200" ] && log_success "Virtual host example.local" || log_fail "Virtual host (got $status)"
}

run_upload_tests() {
    log_section "File Upload Tests"
    echo "Test upload $(date)" > /tmp/test_upload.txt
    local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -F "file=@/tmp/test_upload.txt" "http://localhost:$PORT/upload" 2>/dev/null)
    [[ "$status" =~ ^(200|201)$ ]] && log_success "File upload ($status)" || [ "$status" = "404" ] && log_skip "Upload not configured" || log_fail "Upload (got $status)"
    rm -f /tmp/test_upload.txt
}

run_body_size_tests() {
    log_section "Body Size Limit Tests"
    head -c 2097152 /dev/zero 2>/dev/null | tr '\0' 'A' > /tmp/large_body.txt
    local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 30 -X POST -d "@/tmp/large_body.txt" "http://localhost:$PORT/upload" 2>/dev/null)
    [ "$status" = "413" ] && log_success "Body limit enforced (413)" || log_skip "Body limit not enforced ($status)"
    rm -f /tmp/large_body.txt
}

run_directory_listing_tests() {
    log_section "Directory Listing Tests"
    local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "http://localhost:$PORT/uploads/" 2>/dev/null)
    [[ "$status" =~ ^(200|403)$ ]] && log_success "Directory listing handled ($status)" || log_fail "Directory listing (got $status)"
}

run_concurrent_tests() {
    log_section "Concurrent Connection Tests"
    [ $QUICK_MODE -eq 1 ] && { log_skip "Skipped in quick mode"; return; }
    
    log_info "Testing 20 concurrent connections..."
    local pids=() failed=0
    for i in {1..20}; do
        curl -s --max-time 10 "http://localhost:$PORT/" > /dev/null 2>&1 &
        pids+=($!)
    done
    for pid in "${pids[@]}"; do wait $pid 2>/dev/null || ((failed++)); done
    
    [ $failed -lt 5 ] && log_success "Concurrent connections ($((20-failed))/20)" || log_fail "Failed $failed/20"
    
    local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "http://localhost:$PORT/" 2>/dev/null)
    [ "$status" = "200" ] && log_success "Server responsive after test" || log_fail "Server not responsive ($status)"
}

run_error_handling_tests() {
    log_section "Error Handling Tests"
    test_http_status "GET" "http://localhost:$PORT/this_does_not_exist.xyz" "404" "404 for missing file"
    test_http_status "GET" "http://localhost:$PORT/not/real/path.html" "404" "404 for missing path"
}

run_keepalive_tests() {
    log_section "Keep-Alive Tests"
    curl -s -I --max-time 10 "http://localhost:$PORT/" -H "Connection: keep-alive" 2>/dev/null | grep -qi "keep-alive" && \
        log_success "Server supports keep-alive" || log_skip "Keep-alive not indicated"
}

# =============================================================================
# Main
# =============================================================================
main() {
    echo ""
    echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║           Webserv Complete Integration Test Suite                 ║${NC}"
    echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    [ $QUICK_MODE -eq 1 ] && log_info "Running in QUICK mode"
    
    # Setup directories
    mkdir -p "$PROJECT_DIR/www/uploads" "$PROJECT_DIR/www/errors" "$PROJECT_DIR/www/deletable" "$PROJECT_DIR/logs" 2>/dev/null
    [ -f "$PROJECT_DIR/www/index.html" ] || echo "<html><body><h1>Webserv</h1></body></html>" > "$PROJECT_DIR/www/index.html"
    
    # Start server
    if [ $NO_START -eq 0 ]; then
        log_info "Starting server..."
        start_server || exit 1
        log_success "Server started on port $PORT"
    else
        log_info "Using running server on port $PORT"
        nc -z localhost $PORT 2>/dev/null || { log_fail "No server on port $PORT"; exit 1; }
    fi
    
    # Run tests
    run_basic_tests
    run_method_tests
    run_header_tests
    run_mime_type_tests
    run_cgi_tests
    run_redirect_tests
    run_multi_port_tests
    run_virtual_host_tests
    run_upload_tests
    run_body_size_tests
    run_directory_listing_tests
    run_concurrent_tests
    run_error_handling_tests
    run_keepalive_tests
    
    # Summary
    log_section "Test Summary"
    local TOTAL=$((PASSED + FAILED + SKIPPED))
    echo -e "  Total:   ${CYAN}$TOTAL${NC}"
    echo -e "  Passed:  ${GREEN}$PASSED${NC}"
    echo -e "  Failed:  ${RED}$FAILED${NC}"
    echo -e "  Skipped: ${YELLOW}$SKIPPED${NC}"
    echo ""
    
    [ $FAILED -gt 0 ] && { echo -e "${RED}❌ Some tests failed!${NC}"; exit 1; }
    echo -e "${GREEN}✅ All tests passed!${NC}"
    exit 0
}

[ "${BASH_SOURCE[0]}" = "$0" ] && main "$@"
