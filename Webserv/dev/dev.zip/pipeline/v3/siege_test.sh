#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    siege_test.sh - Backward Compatibility Wrapper                            #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
#    This script wraps benchmark_tests.sh for backward compatibility.          #
#    All functionality has been consolidated into benchmark_tests.sh           #
#                                                                              #
# **************************************************************************** #

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Forward all arguments to the main benchmark script
exec "$SCRIPT_DIR/benchmark_tests.sh" "$@"
