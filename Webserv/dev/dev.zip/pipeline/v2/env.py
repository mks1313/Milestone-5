#!/usr/bin/env python3
# **************************************************************************** #
#                                                                              #
#    env.py - Environment Variables CGI Script                                 #
#                                                                              #
#    Simple CGI that outputs environment variables in plain text.              #
#    Useful for CI/CD testing and debugging CGI configuration.                 #
#    Validates RFC 3875 required CGI variables.                                #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

import os

# Output headers - plain text for easy CI parsing
print("Content-Type: text/plain; charset=utf-8")
print()

# Required CGI environment variables per RFC 3875
required_vars = [
    'REQUEST_METHOD',
    'QUERY_STRING',
    'CONTENT_TYPE',
    'CONTENT_LENGTH',
    'SERVER_NAME',
    'SERVER_PORT',
    'SERVER_PROTOCOL',
    'GATEWAY_INTERFACE',
    'SCRIPT_NAME',
    'PATH_INFO',
    'PATH_TRANSLATED',
    'REMOTE_ADDR',
    'REMOTE_HOST',
    'HTTP_HOST',
    'HTTP_USER_AGENT',
    'HTTP_ACCEPT',
    'HTTP_COOKIE'
]

print("=== CGI Environment Check ===")
print()

set_count = 0
not_set_count = 0

for var in required_vars:
    value = os.environ.get(var)
    if value is not None:
        status = 'OK'
        set_count += 1
        print(f"{status} {var}={value}")
    else:
        status = 'NOT_SET'
        not_set_count += 1
        print(f"{status} {var}")

print()
print(f"=== Summary: {set_count}/{len(required_vars)} variables set ===")
print()

# HTTP headers section
print("=== HTTP Headers ===")
for key, value in sorted(os.environ.items()):
    if key.startswith('HTTP_'):
        print(f"{key}={value}")

print()

# All environment variables
print("=== All Environment Variables ===")
for key, value in sorted(os.environ.items()):
    print(f"{key}={value}")
