#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    test_suite.sh - Complete Test Suite for Webserv                           #
#                                                                              #
#    MAIN TEST SCRIPT - Comprehensive testing with flexible options.           #
#    - Absorbs all functionality from test.sh                                  #
#    - Use --no-start if server is already running                             #
#    - Use --quick for CI/CD (skips slow tests)                                #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

# =============================================================================
# Configuration
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"
PORT=${WEBSERV_PORT:-8080}
PORT2=${WEBSERV_PORT_2:-8081}
PORT3=${WEBSERV_PORT_3:-8082}
HOST="localhost"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
SKIPPED_TESTS=0

# Options (defaults)
START_SERVER=true
QUICK_MODE=false
VERBOSE=false

# =============================================================================
# Parse Arguments
# =============================================================================
while [[ $# -gt 0 ]]; do
    case $1 in
        --no-start)
            START_SERVER=false
            shift
            ;;
        -q|--quick)
            QUICK_MODE=true
            shift
            ;;
        -v|--verbose)
            VERBOSE=true
            shift
            ;;
        -p|--port)
            PORT="$2"
            shift 2
            ;;
        -c|--config)
            CONFIG="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --no-start    Don't start server (assume already running)"
            echo "  -q, --quick   Run quick tests only (for CI/CD)"
            echo "  -v, --verbose Verbose output"
            echo "  -p, --port N  Port to test (default: 8080)"
            echo "  -c, --config  Config file to use"
            echo "  -h, --help    Show this help"
            echo ""
            echo "Examples:"
            echo "  $0                    # Full tests, starts server"
            echo "  $0 --no-start         # Tests only, server must be running"
            echo "  $0 --quick            # Fast tests for CI/CD"
            exit 0
            ;;
        *)
            shift
            ;;
    esac
done

# =============================================================================
# Utility Functions
# =============================================================================

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[PASS]${NC} $1"; ((PASSED_TESTS++)); ((TOTAL_TESTS++)); }
log_fail() { echo -e "${RED}[FAIL]${NC} $1"; ((FAILED_TESTS++)); ((TOTAL_TESTS++)); }
log_skip() { echo -e "${YELLOW}[SKIP]${NC} $1"; ((SKIPPED_TESTS++)); ((TOTAL_TESTS++)); }

log_section() {
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
}

wait_for_server() {
    local port=${1:-$PORT}
    local max_wait=${2:-30}
    for i in $(seq 1 $max_wait); do
        nc -z $HOST $port 2>/dev/null && return 0
        sleep 1
    done
    return 1
}

start_server() {
    if [ ! -f "$WEBSERV" ]; then
        log_info "Binary not found, building..."
        cd "$PROJECT_DIR" && make re || { log_fail "Build failed"; return 1; }
    fi
    
    "$WEBSERV" "$CONFIG" &
    SERVER_PID=$!
    
    if ! wait_for_server $PORT 30; then
        log_fail "Server failed to start on port $PORT"
        return 1
    fi
    return 0
}

stop_server() {
    [ -n "$SERVER_PID" ] && { kill $SERVER_PID 2>/dev/null; wait $SERVER_PID 2>/dev/null; }
    pkill -f "$WEBSERV" 2>/dev/null || true
    sleep 1
}

cleanup() {
    [ "$START_SERVER" = true ] && stop_server
    rm -f /tmp/webserv_test_* /tmp/test_upload.txt /tmp/large_body.txt 2>/dev/null
}
trap cleanup EXIT

# =============================================================================
# Test Helper Functions
# =============================================================================

# Test HTTP status code
test_status() {
    local method="$1" url="$2" expected="$3" desc="$4" data="$5"
    local status
    
    case "$method" in
        POST)
            if [ -n "$data" ]; then
                status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "$data" "$url" 2>/dev/null)
            else
                status=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$url" 2>/dev/null)
            fi
            ;;
        HEAD)
            status=$(curl -s -o /dev/null -w "%{http_code}" -I "$url" 2>/dev/null)
            ;;
        GET)
            status=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)
            ;;
        *)
            status=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url" 2>/dev/null)
            ;;
    esac
    
    [ "$status" = "$expected" ] && log_success "$desc ($status)" || log_fail "$desc (expected $expected, got $status)"
}

# Test status with multiple acceptable codes
test_status_multi() {
    local method="$1" url="$2" desc="$3"; shift 3
    local status
    
    case "$method" in
        GET)  status=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null) ;;
        HEAD) status=$(curl -s -o /dev/null -w "%{http_code}" -I "$url" 2>/dev/null) ;;
        *)    status=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "$url" 2>/dev/null) ;;
    esac
    
    for code in "$@"; do
        [ "$status" = "$code" ] && { log_success "$desc ($status)"; return 0; }
    done
    log_fail "$desc (expected one of: $*, got $status)"
}

# Test header presence
test_header() {
    local url="$1" header="$2" desc="$3"
    curl -s -I "$url" 2>/dev/null | grep -qi "$header" && log_success "$desc" || log_fail "$desc (header not found)"
}

# Test body contains pattern
test_body() {
    local url="$1" pattern="$2" desc="$3"
    curl -s "$url" 2>/dev/null | grep -q "$pattern" && log_success "$desc" || log_fail "$desc (pattern not found)"
}

# =============================================================================
# Test Suites
# =============================================================================

run_basic_tests() {
    log_section "Basic HTTP Tests"
    
    test_status "GET" "http://$HOST:$PORT/" "200" "GET / returns 200"
    test_status "GET" "http://$HOST:$PORT/index.html" "200" "GET /index.html returns 200"
    test_status "GET" "http://$HOST:$PORT/nonexistent.xyz" "404" "GET nonexistent returns 404"
    test_status "HEAD" "http://$HOST:$PORT/" "200" "HEAD / returns 200"
    
    # Directory listing (from test.sh)
    test_status "GET" "http://$HOST:$PORT/uploads/" "200" "GET directory listing"
}

run_method_tests() {
    log_section "HTTP Method Tests"
    
    test_status "GET" "http://$HOST:$PORT/" "200" "GET method works"
    test_status "POST" "http://$HOST:$PORT/" "200" "POST method works" "test=data"
    
    # DELETE test (from test.sh)
    if [ -d "$PROJECT_DIR/www/deletable" ]; then
        echo "test content" > "$PROJECT_DIR/www/deletable/test_delete.txt"
        test_status_multi "DELETE" "http://$HOST:$PORT/deletable/test_delete.txt" "DELETE existing file" "200" "204"
        test_status "DELETE" "http://$HOST:$PORT/deletable/nonexistent.txt" "404" "DELETE nonexistent returns 404"
    else
        log_skip "DELETE tests (www/deletable not found)"
    fi
    
    # Invalid/Unknown methods
    local status=$(curl -s -o /dev/null -w "%{http_code}" -X INVALID "http://$HOST:$PORT/" 2>/dev/null)
    [[ "$status" =~ ^(400|405|501)$ ]] && log_success "Invalid method returns error ($status)" || log_fail "Invalid method (got $status)"
    
    status=$(curl -s -o /dev/null -w "%{http_code}" -X PUT "http://$HOST:$PORT/" 2>/dev/null)
    [ "$status" = "405" ] && log_success "PUT on root returns 405 ($status)" || log_skip "PUT returned $status"
}

run_header_tests() {
    log_section "HTTP Header Tests"
    
    test_header "http://$HOST:$PORT/" "Content-Type" "Content-Type header present"
    test_header "http://$HOST:$PORT/" "Content-Length" "Content-Length header present"
    test_header "http://$HOST:$PORT/" "Connection" "Connection header present"
    test_header "http://$HOST:$PORT/" "Server" "Server header present"
    
    # HTTP version check
    local resp=$(curl -s -I "http://$HOST:$PORT/" 2>/dev/null)
    echo "$resp" | grep -q "HTTP/1.1" && log_success "Server responds with HTTP/1.1" || log_fail "Should respond with HTTP/1.1"
}

run_mime_type_tests() {
    log_section "MIME Type Tests"
    
    # Create test files if needed
    [ -f "$PROJECT_DIR/www/test_mime.html" ] || echo "<html></html>" > "$PROJECT_DIR/www/test_mime.html"
    [ -f "$PROJECT_DIR/www/test_mime.css" ] || echo "body {}" > "$PROJECT_DIR/www/test_mime.css"
    
    local ct
    ct=$(curl -s -I "http://$HOST:$PORT/test_mime.html" 2>/dev/null | grep -i "Content-Type" | tr -d '\r')
    echo "$ct" | grep -qi "text/html" && log_success "HTML has text/html MIME" || log_fail "HTML MIME type incorrect"
    
    ct=$(curl -s -I "http://$HOST:$PORT/test_mime.css" 2>/dev/null | grep -i "Content-Type" | tr -d '\r')
    echo "$ct" | grep -qi "text/css" && log_success "CSS has text/css MIME" || log_fail "CSS MIME type incorrect"
    
    # Cleanup
    rm -f "$PROJECT_DIR/www/test_mime.html" "$PROJECT_DIR/www/test_mime.css" 2>/dev/null
}

run_cgi_tests() {
    log_section "CGI Tests"
    
    # Find available CGI script
    local cgi_script=""
    for s in test.py info.py env.py; do
        [ -f "$PROJECT_DIR/cgi-bin/$s" ] && { cgi_script="$s"; break; }
    done
    
    [ -z "$cgi_script" ] && { log_skip "No CGI scripts found"; return; }
    
    chmod +x "$PROJECT_DIR/cgi-bin/"*.py 2>/dev/null || true
    
    test_status "GET" "http://$HOST:$PORT/cgi-bin/$cgi_script" "200" "CGI GET returns 200"
    test_status "POST" "http://$HOST:$PORT/cgi-bin/$cgi_script" "200" "CGI POST returns 200" "name=test&email=test@test.com"
    test_status "GET" "http://$HOST:$PORT/cgi-bin/$cgi_script?param=value" "200" "CGI with query string"
    
    # Test other CGI scripts if available
    [ -f "$PROJECT_DIR/cgi-bin/info.py" ] && test_status "GET" "http://$HOST:$PORT/cgi-bin/info.py" "200" "CGI info.py"
    [ -f "$PROJECT_DIR/cgi-bin/session.py" ] && test_status "GET" "http://$HOST:$PORT/cgi-bin/session.py" "200" "CGI session.py"
}

run_redirect_tests() {
    log_section "Redirect Tests"
    
    # 301 redirect
    local status=$(curl -s -o /dev/null -w "%{http_code}" --max-redirs 0 "http://$HOST:$PORT/old-page" 2>/dev/null)
    [ "$status" = "301" ] && log_success "301 redirect works ($status)" || log_skip "301 redirect not configured ($status)"
    
    # 302 redirect
    status=$(curl -s -o /dev/null -w "%{http_code}" --max-redirs 0 "http://$HOST:$PORT/google" 2>/dev/null)
    [ "$status" = "302" ] && log_success "302 redirect works ($status)" || log_skip "302 redirect not configured ($status)"
}

run_multiport_tests() {
    log_section "Multiple Ports Tests"
    
    if wait_for_server $PORT2 3; then
        test_status "GET" "http://$HOST:$PORT2/" "200" "Server on port $PORT2"
    else
        log_skip "Port $PORT2 not available"
    fi
    
    if wait_for_server $PORT3 3; then
        test_status "GET" "http://$HOST:$PORT3/" "200" "Server on port $PORT3"
    else
        log_skip "Port $PORT3 not available"
    fi
}

run_vhost_tests() {
    log_section "Virtual Host Tests"
    
    local status=$(curl -s -o /dev/null -w "%{http_code}" -H "Host: example.local" "http://$HOST:$PORT/" 2>/dev/null)
    [ "$status" = "200" ] && log_success "Virtual host example.local ($status)" || log_skip "Virtual host not configured ($status)"
}

run_upload_tests() {
    log_section "File Upload Tests"
    
    echo "test upload content" > /tmp/test_upload.txt
    local status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -F "file=@/tmp/test_upload.txt" "http://$HOST:$PORT/upload" 2>/dev/null)
    [[ "$status" =~ ^(200|201)$ ]] && log_success "File upload works ($status)" || log_skip "Upload not configured ($status)"
    rm -f /tmp/test_upload.txt
}

run_body_limit_tests() {
    log_section "Body Size Limit Tests"
    
    # Create 2MB file (larger than typical 1MB limit)
    dd if=/dev/zero bs=1M count=2 2>/dev/null | tr '\0' 'A' > /tmp/large_body.txt
    local status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "@/tmp/large_body.txt" "http://$HOST:$PORT/upload" 2>/dev/null)
    [ "$status" = "413" ] && log_success "Body limit enforced (413)" || log_skip "Body limit test ($status)"
    rm -f /tmp/large_body.txt
}

run_concurrent_tests() {
    log_section "Concurrent Connection Tests"
    
    [ "$QUICK_MODE" = true ] && { log_skip "Concurrent tests (quick mode)"; return; }
    
    log_info "Testing 20 concurrent connections..."
    local pids=() failed=0
    for i in {1..20}; do
        curl -s "http://$HOST:$PORT/" >/dev/null 2>&1 &
        pids+=($!)
    done
    for pid in "${pids[@]}"; do
        wait $pid 2>/dev/null || ((failed++))
    done
    
    [ $failed -eq 0 ] && log_success "Handled 20 concurrent connections" || log_fail "Failed $failed/20 connections"
    
    # Server still responsive?
    local status=$(curl -s -o /dev/null -w "%{http_code}" "http://$HOST:$PORT/" 2>/dev/null)
    [ "$status" = "200" ] && log_success "Server responsive after load" || log_fail "Server not responsive ($status)"
}

run_keepalive_tests() {
    log_section "Keep-Alive Tests"
    
    local resp=$(curl -s -I "http://$HOST:$PORT/" -H "Connection: keep-alive" 2>/dev/null)
    echo "$resp" | grep -qi "keep-alive" && log_success "Server supports keep-alive" || log_skip "Keep-alive not confirmed"
}

run_error_tests() {
    log_section "Error Handling Tests"
    
    test_status "GET" "http://$HOST:$PORT/this_does_not_exist_404" "404" "404 for missing file"
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo ""
    echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║              Webserv Complete Test Suite                          ║${NC}"
    echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    [ "$QUICK_MODE" = true ] && log_info "Running in QUICK mode (some tests skipped)"
    
    # Setup directories
    mkdir -p "$PROJECT_DIR/www/uploads" "$PROJECT_DIR/www/errors" "$PROJECT_DIR/www/deletable" "$PROJECT_DIR/logs" 2>/dev/null
    [ -f "$PROJECT_DIR/www/index.html" ] || echo "<html><body>Webserv Test</body></html>" > "$PROJECT_DIR/www/index.html"
    [ -f "$PROJECT_DIR/www/errors/404.html" ] || echo "<html><body>404 Not Found</body></html>" > "$PROJECT_DIR/www/errors/404.html"
    
    # Start or check server
    if [ "$START_SERVER" = true ]; then
        log_info "Starting server..."
        start_server || exit 1
        log_success "Server started (PID: $SERVER_PID)"
    else
        if ! wait_for_server $PORT 5; then
            log_fail "Server not running on port $PORT"
            echo "Start server first: ./bin/webserv config/webserv.conf"
            exit 1
        fi
        log_info "Using existing server on port $PORT"
    fi
    
    # Run all test suites
    run_basic_tests
    run_method_tests
    run_header_tests
    run_mime_type_tests
    run_cgi_tests
    run_redirect_tests
    run_multiport_tests
    run_vhost_tests
    run_upload_tests
    run_body_limit_tests
    run_concurrent_tests
    run_keepalive_tests
    run_error_tests
    
    # Summary
    log_section "Test Summary"
    echo -e "Total:   ${CYAN}$TOTAL_TESTS${NC}"
    echo -e "Passed:  ${GREEN}$PASSED_TESTS${NC}"
    echo -e "Failed:  ${RED}$FAILED_TESTS${NC}"
    echo -e "Skipped: ${YELLOW}$SKIPPED_TESTS${NC}"
    echo ""
    
    [ $FAILED_TESTS -gt 0 ] && { echo -e "${RED}❌ Some tests failed!${NC}"; exit 1; }
    echo -e "${GREEN}✅ All tests passed!${NC}"
}

main "$@"
