#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    security_tests.sh - Security and Input Validation Tests                   #
#                                                                              #
#    STANDALONE SCRIPT - Tests path traversal, request limits, malformed       #
#    requests, HTTP methods, and slow client attacks.                          #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"
HOST="localhost"
PORT=${WEBSERV_PORT:-8080}

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# Counters
PASSED=0
FAILED=0
WARNED=0

# Options
START_SERVER=true

# =============================================================================
# Parse Arguments
# =============================================================================
while [[ $# -gt 0 ]]; do
    case $1 in
        --no-start) START_SERVER=false; shift ;;
        -p|--port) PORT="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --no-start    Don't start server (assume running)"
            echo "  -p, --port N  Port to test (default: 8080)"
            echo "  -h, --help    Show this help"
            exit 0
            ;;
        *) shift ;;
    esac
done

# =============================================================================
# Functions
# =============================================================================

log_pass() { echo -e "  ${GREEN}✅ PASS${NC}: $1"; ((PASSED++)); }
log_fail() { echo -e "  ${RED}❌ FAIL${NC}: $1"; ((FAILED++)); }
log_warn() { echo -e "  ${YELLOW}⚠️  WARN${NC}: $1"; ((WARNED++)); }

wait_for_server() {
    for i in {1..30}; do
        nc -z $HOST $PORT 2>/dev/null && return 0
        sleep 1
    done
    return 1
}

cleanup() {
    [ "$START_SERVER" = true ] && [ -n "$SERVER_PID" ] && {
        kill $SERVER_PID 2>/dev/null
        wait $SERVER_PID 2>/dev/null
    }
}
trap cleanup EXIT

# =============================================================================
# Main
# =============================================================================

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}              Security & Input Validation Tests                ${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""

# Start or check server
if [ "$START_SERVER" = true ]; then
    [ -f "$WEBSERV" ] || { cd "$PROJECT_DIR" && make re; }
    "$WEBSERV" "$CONFIG" &
    SERVER_PID=$!
    wait_for_server || { echo -e "${RED}Server failed to start${NC}"; exit 1; }
    echo -e "${GREEN}✅ Server started${NC}"
else
    if ! wait_for_server; then
        echo -e "${RED}Server not running on $HOST:$PORT${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ Server already running${NC}"
fi

# =============================================================================
echo -e "\n${CYAN}📝 Path Traversal Tests${NC}"
# =============================================================================

TRAVERSAL_PATHS=(
    "/../etc/passwd"
    "/..%2f..%2fetc/passwd"
    "/....//....//etc/passwd"
    "/%2e%2e/%2e%2e/etc/passwd"
    "/..\\..\\etc\\passwd"
    "/..%252f..%252fetc/passwd"
)

for path in "${TRAVERSAL_PATHS[@]}"; do
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "http://$HOST:$PORT$path" 2>/dev/null || echo "000")
    BODY=$(curl -s "http://$HOST:$PORT$path" 2>/dev/null || echo "")
    
    if echo "$BODY" | grep -q "root:"; then
        log_fail "Path traversal possible: $path"
    elif [[ "$STATUS" =~ ^(400|403|404)$ ]]; then
        log_pass "Traversal blocked: $path ($STATUS)"
    else
        log_warn "Traversal inconclusive: $path ($STATUS)"
    fi
done

# =============================================================================
echo -e "\n${CYAN}📝 Request Size Tests${NC}"
# =============================================================================

# Long URL
if command -v python3 &>/dev/null; then
    LONG_PATH=$(python3 -c "print('/' + 'a' * 10000)")
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "http://$HOST:$PORT$LONG_PATH" 2>/dev/null || echo "414")
    [[ "$STATUS" =~ ^(400|404|414)$ ]] && log_pass "Long URL rejected ($STATUS)" || log_warn "Long URL: $STATUS"
    
    # Long header
    LONG_HEADER=$(python3 -c "print('X-Test: ' + 'a' * 10000)")
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "$LONG_HEADER" "http://$HOST:$PORT/" 2>/dev/null || echo "431")
    [[ "$STATUS" =~ ^(200|400|431)$ ]] && log_pass "Long header handled ($STATUS)" || log_warn "Long header: $STATUS"
fi

# Many headers
HEADERS=""
for i in {1..100}; do
    HEADERS="$HEADERS -H 'X-Custom-$i: value$i'"
done
STATUS=$(eval curl -s -o /dev/null -w "%{http_code}" $HEADERS "http://$HOST:$PORT/" 2>/dev/null || echo "431")
[[ "$STATUS" =~ ^(200|400|431)$ ]] && log_pass "Many headers handled ($STATUS)" || log_warn "Many headers: $STATUS"

# =============================================================================
echo -e "\n${CYAN}📝 Malformed Request Tests${NC}"
# =============================================================================

if command -v nc &>/dev/null; then
    # Request with no path
    RESPONSE=$(echo -e "GET HTTP/1.1\r\nHost: $HOST\r\n\r\n" | nc -w 2 $HOST $PORT 2>/dev/null | head -1)
    echo "$RESPONSE" | grep -q "HTTP/1\.[01] [45]" && log_pass "Malformed (no path) rejected" || log_warn "Malformed (no path) unclear"
    
    # Request without version
    RESPONSE=$(echo -e "GET /\r\nHost: $HOST\r\n\r\n" | nc -w 2 $HOST $PORT 2>/dev/null | head -1)
    echo "$RESPONSE" | grep -q "HTTP" && log_pass "Request without version handled" || log_warn "Without version unclear"
    
    # Double Content-Length (HTTP smuggling)
    RESPONSE=$(echo -e "GET / HTTP/1.1\r\nHost: $HOST\r\nContent-Length: 0\r\nContent-Length: 10\r\n\r\n" | nc -w 2 $HOST $PORT 2>/dev/null | head -1)
    echo "$RESPONSE" | grep -q "HTTP/1\.[01] [245]" && log_pass "Double Content-Length handled" || log_warn "Double CL unclear"
fi

# =============================================================================
echo -e "\n${CYAN}📝 HTTP Method Tests${NC}"
# =============================================================================

METHODS=("TRACE" "CONNECT" "OPTIONS" "PATCH" "PROPFIND" "MKCOL" "COPY" "MOVE" "LOCK" "UNLOCK")

for method in "${METHODS[@]}"; do
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" "http://$HOST:$PORT/" 2>/dev/null || echo "501")
    [[ "$STATUS" =~ ^(200|400|405|501)$ ]] && log_pass "Method $method handled ($STATUS)" || log_warn "Method $method: $STATUS"
done

# =============================================================================
echo -e "\n${CYAN}📝 Host Header Tests${NC}"
# =============================================================================

# Empty host
STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "Host:" "http://$HOST:$PORT/" 2>/dev/null || echo "400")
[[ "$STATUS" =~ ^(200|400)$ ]] && log_pass "Empty Host handled ($STATUS)" || log_warn "Empty Host: $STATUS"

# Long host
if command -v python3 &>/dev/null; then
    LONG_HOST=$(python3 -c "print('a' * 1000 + '.com')")
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "Host: $LONG_HOST" "http://$HOST:$PORT/" 2>/dev/null || echo "400")
    [[ "$STATUS" =~ ^(200|400)$ ]] && log_pass "Long Host handled ($STATUS)" || log_warn "Long Host: $STATUS"
fi

# =============================================================================
echo -e "\n${CYAN}📝 Content-Type Tests${NC}"
# =============================================================================

# POST without Content-Type
STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "data" "http://$HOST:$PORT/" 2>/dev/null || echo "200")
[[ "$STATUS" =~ ^(200|400)$ ]] && log_pass "POST without CT handled ($STATUS)" || log_warn "POST without CT: $STATUS"

# =============================================================================
echo -e "\n${CYAN}📝 Slow Client Tests (Slowloris)${NC}"
# =============================================================================

if command -v nc &>/dev/null; then
    # Start slow client in background
    {
        echo -ne "GET / HTTP/1.1\r\n"
        echo -ne "Host: $HOST\r\n"
        sleep 2
        echo -ne "Connection: close\r\n"
        echo -ne "\r\n"
    } | nc -w 5 $HOST $PORT > /dev/null 2>&1 &
    SLOW_PID=$!
    
    # Server should still respond
    sleep 1
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://$HOST:$PORT/" 2>/dev/null || echo "000")
    [ "$STATUS" = "200" ] && log_pass "Server responsive during slow client" || log_warn "Slow client test: $STATUS"
    
    kill $SLOW_PID 2>/dev/null || true
    wait $SLOW_PID 2>/dev/null || true
fi

# =============================================================================
# Summary
# =============================================================================
echo ""
echo -e "═══════════════════════════════════════════════════════════════"
echo -e "Results: ${GREEN}$PASSED passed${NC}, ${RED}$FAILED failed${NC}, ${YELLOW}$WARNED warnings${NC}"
echo ""

if [ $FAILED -gt 0 ]; then
    echo -e "${RED}❌ Some security tests failed${NC}"
    exit 1
fi

echo -e "${GREEN}✅ All security tests passed${NC}"
exit 0
