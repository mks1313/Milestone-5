#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    test.sh - Quick Test Script for Webserv                                   #
#                                                                              #
#    WRAPPER: Calls test_suite.sh with --no-start (assumes server running)     #
#                                                                              #
#    This script maintains backward compatibility.                             #
#    For full control, use test_suite.sh directly:                             #
#      ./test_suite.sh              # Starts server, runs all tests            #
#      ./test_suite.sh --no-start   # Server must be running                   #
#      ./test_suite.sh --quick      # Fast tests for CI/CD                     #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "$SCRIPT_DIR/test_suite.sh" ]; then
    # By default assumes server is already running (original test.sh behavior)
    # Use --start to override and let test_suite.sh start the server
    if [[ " $* " =~ " --start " ]]; then
        # Remove --start and pass remaining args
        args=("${@/--start/}")
        exec "$SCRIPT_DIR/test_suite.sh" "${args[@]}"
    else
        exec "$SCRIPT_DIR/test_suite.sh" --no-start "$@"
    fi
else
    echo "Error: test_suite.sh not found in $SCRIPT_DIR"
    echo "This script is a wrapper for test_suite.sh"
    exit 1
fi
