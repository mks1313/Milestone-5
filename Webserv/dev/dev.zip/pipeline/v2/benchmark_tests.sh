#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    benchmark_tests.sh - Performance and Benchmark Tests                      #
#                                                                              #
#    MAIN BENCHMARK SCRIPT - siege_test.sh is a wrapper for this.              #
#    Includes warmup, siege stress test, metrics evaluation, multi-URL.        #
#                                                                              #
#    Options:                                                                  #
#      --no-start    Don't start server (assume already running)               #
#      --quick       Quick test (10 users, 10s)                                #
#      --multi-url   Test multiple URLs (like siege_test.sh)                   #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
WEBSERV="$PROJECT_DIR/bin/webserv"
CONFIG="$PROJECT_DIR/config/webserv.conf"
HOST="localhost"
PORT=${WEBSERV_PORT:-8080}

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Defaults
CONCURRENT_USERS=50
DURATION=30
WARMUP_REQUESTS=100
START_SERVER=true
QUICK_MODE=false
MULTI_URL=false

# =============================================================================
# Parse Arguments
# =============================================================================
# Support positional args for backward compatibility: $1=concurrent, $2=duration
if [[ "$1" =~ ^[0-9]+$ ]]; then
    CONCURRENT_USERS="$1"
    shift
fi
if [[ "$1" =~ ^[0-9]+$ ]]; then
    DURATION="$1"
    shift
fi

while [[ $# -gt 0 ]]; do
    case $1 in
        -c|--concurrent) CONCURRENT_USERS="$2"; shift 2 ;;
        -t|--time) DURATION="$2"; shift 2 ;;
        -q|--quick) QUICK_MODE=true; CONCURRENT_USERS=10; DURATION=10; shift ;;
        --no-start) START_SERVER=false; shift ;;
        --multi-url) MULTI_URL=true; shift ;;
        -h|--help)
            echo "Usage: $0 [CONCURRENT] [DURATION] [OPTIONS]"
            echo ""
            echo "Positional (optional):"
            echo "  CONCURRENT    Concurrent users (default: 50)"
            echo "  DURATION      Duration in seconds (default: 30)"
            echo ""
            echo "Options:"
            echo "  -c, --concurrent N  Concurrent users"
            echo "  -t, --time N        Duration seconds"
            echo "  -q, --quick         Quick mode (10 users, 10s)"
            echo "  --no-start          Don't start server (assume running)"
            echo "  --multi-url         Test multiple URLs (siege_test.sh mode)"
            echo "  -h, --help          Show this help"
            echo ""
            echo "Examples:"
            echo "  $0                  # 50 users, 30s, starts server"
            echo "  $0 100 60           # 100 users, 60s"
            echo "  $0 --quick          # 10 users, 10s (CI/CD)"
            echo "  $0 --no-start       # Server must be running"
            exit 0
            ;;
        *) shift ;;
    esac
done

# =============================================================================
# Functions
# =============================================================================

wait_for_server() {
    for i in {1..30}; do
        nc -z $HOST $PORT 2>/dev/null && return 0
        sleep 1
    done
    return 1
}

cleanup() {
    [ "$START_SERVER" = true ] && [ -n "$SERVER_PID" ] && {
        kill $SERVER_PID 2>/dev/null
        wait $SERVER_PID 2>/dev/null
    }
    rm -f /tmp/siege_results.txt /tmp/siege_urls.txt 2>/dev/null
}
trap cleanup EXIT

# =============================================================================
# Main
# =============================================================================

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}              Performance & Benchmark Tests                     ${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${BLUE}Configuration:${NC}"
echo "  Concurrent users: $CONCURRENT_USERS"
echo "  Duration: ${DURATION}s"
echo "  Port: $PORT"
[ "$QUICK_MODE" = true ] && echo "  Mode: QUICK (reduced load)"
[ "$MULTI_URL" = true ] && echo "  Multi-URL: enabled"
echo ""

# Check siege
if ! command -v siege &>/dev/null; then
    echo -e "${RED}Error: siege is not installed${NC}"
    echo "Install with: apt install siege / brew install siege"
    exit 1
fi

# Start or check server
if [ "$START_SERVER" = true ]; then
    [ -f "$WEBSERV" ] || { cd "$PROJECT_DIR" && make re; }
    "$WEBSERV" "$CONFIG" &
    SERVER_PID=$!
    wait_for_server || { echo -e "${RED}Server failed to start${NC}"; exit 1; }
    echo -e "${GREEN}✅ Server started (PID: $SERVER_PID)${NC}"
else
    if ! wait_for_server; then
        echo -e "${RED}Error: Server is not running on ${HOST}:${PORT}${NC}"
        echo "Start server first or remove --no-start option"
        exit 1
    fi
    echo -e "${GREEN}✅ Server already running${NC}"
fi

# Configure siege
mkdir -p ~/.siege 2>/dev/null
cat > ~/.siege/siege.conf << EOF
verbose = false
quiet = true
json_output = false
show-logfile = false
logging = false
protocol = HTTP/1.1
chunked = true
connection = keep-alive
concurrent = $CONCURRENT_USERS
time = ${DURATION}S
EOF

# =============================================================================
# Warmup Phase
# =============================================================================
if [ "$QUICK_MODE" = false ]; then
    echo -e "\n${CYAN}📝 Warmup Phase${NC}"
    echo "Running $WARMUP_REQUESTS warmup requests..."
    for i in $(seq 1 $WARMUP_REQUESTS); do
        curl -s "http://$HOST:$PORT/" > /dev/null &
    done
    wait
    echo "Warmup complete"
fi

# =============================================================================
# Main Siege Test
# =============================================================================
echo -e "\n${CYAN}📝 Siege Stress Test${NC}"
echo "Running: $CONCURRENT_USERS concurrent users, ${DURATION}s..."
echo ""

siege -b -c $CONCURRENT_USERS -t ${DURATION}S "http://$HOST:$PORT/" 2>&1 | tee /tmp/siege_results.txt

# =============================================================================
# Multi-URL Test (from siege_test.sh)
# =============================================================================
if [ "$MULTI_URL" = true ]; then
    echo -e "\n${CYAN}📝 Multi-URL Test${NC}"
    
    cat > /tmp/siege_urls.txt << EOF
http://$HOST:$PORT/
http://$HOST:$PORT/index.html
http://$HOST:$PORT/uploads/
EOF
    
    # Add CGI URLs if available
    [ -f "$PROJECT_DIR/cgi-bin/test.py" ] && echo "http://$HOST:$PORT/cgi-bin/test.py" >> /tmp/siege_urls.txt
    [ -f "$PROJECT_DIR/cgi-bin/info.py" ] && echo "http://$HOST:$PORT/cgi-bin/info.py" >> /tmp/siege_urls.txt
    
    echo "Testing $(wc -l < /tmp/siege_urls.txt) URLs..."
    siege -b -c $CONCURRENT_USERS -t 15S -f /tmp/siege_urls.txt 2>&1 | tail -15
    
    # High concurrency test (from siege_test.sh)
    if [ "$QUICK_MODE" = false ]; then
        echo -e "\n${CYAN}📝 High Concurrency Test (100 users, 15s)${NC}"
        siege -b -c 100 -t 15s "http://$HOST:$PORT/" 2>&1 | tail -15
    fi
fi

# =============================================================================
# Parse and Display Results
# =============================================================================
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}                    Benchmark Results                           ${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"

# Parse siege results
AVAILABILITY=$(grep "Availability:" /tmp/siege_results.txt 2>/dev/null | awk '{print $2}' | tr -d '%')
TRANSACTIONS=$(grep "Transactions:" /tmp/siege_results.txt 2>/dev/null | awk '{print $2}')
TRANS_RATE=$(grep "Transaction rate:" /tmp/siege_results.txt 2>/dev/null | awk '{print $3}')
RESPONSE_TIME=$(grep "Response time:" /tmp/siege_results.txt 2>/dev/null | awk '{print $3}')
THROUGHPUT=$(grep "Throughput:" /tmp/siege_results.txt 2>/dev/null | awk '{print $2}')
CONCURRENCY=$(grep "Concurrency:" /tmp/siege_results.txt 2>/dev/null | awk '{print $2}')
FAILED=$(grep "Failed transactions:" /tmp/siege_results.txt 2>/dev/null | awk '{print $3}')
LONGEST=$(grep "Longest transaction:" /tmp/siege_results.txt 2>/dev/null | awk '{print $3}')
SHORTEST=$(grep "Shortest transaction:" /tmp/siege_results.txt 2>/dev/null | awk '{print $3}')

echo ""
echo -e "${BLUE}Performance Metrics:${NC}"
echo "  Availability:       ${AVAILABILITY:-N/A}%"
echo "  Total Transactions: ${TRANSACTIONS:-N/A}"
echo "  Transaction Rate:   ${TRANS_RATE:-N/A} trans/sec"
echo "  Response Time:      ${RESPONSE_TIME:-N/A} secs"
echo "  Throughput:         ${THROUGHPUT:-N/A} MB/sec"
echo "  Concurrency:        ${CONCURRENCY:-N/A}"
echo "  Failed:             ${FAILED:-N/A}"
echo "  Longest Trans:      ${LONGEST:-N/A} secs"
echo "  Shortest Trans:     ${SHORTEST:-N/A} secs"

# =============================================================================
# Performance Evaluation
# =============================================================================
echo -e "\n${CYAN}📝 Performance Evaluation${NC}"

PASS_COUNT=0
WARN_COUNT=0
FAIL_COUNT=0

# Availability check (>= 99.5% = pass, >= 95% = warn)
if [ -n "$AVAILABILITY" ]; then
    if (( $(echo "$AVAILABILITY >= 99.5" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${GREEN}✅ Availability >= 99.5%${NC} ($AVAILABILITY%)"
        ((PASS_COUNT++))
    elif (( $(echo "$AVAILABILITY >= 95" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${YELLOW}⚠️  Availability 95-99.5%${NC} ($AVAILABILITY%)"
        ((WARN_COUNT++))
    else
        echo -e "  ${RED}❌ Availability < 95%${NC} ($AVAILABILITY%)"
        ((FAIL_COUNT++))
    fi
fi

# Response time check (< 1s = pass, < 2s = warn)
if [ -n "$RESPONSE_TIME" ]; then
    if (( $(echo "$RESPONSE_TIME < 1.0" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${GREEN}✅ Response time < 1s${NC} (${RESPONSE_TIME}s)"
        ((PASS_COUNT++))
    elif (( $(echo "$RESPONSE_TIME < 2.0" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${YELLOW}⚠️  Response time 1-2s${NC} (${RESPONSE_TIME}s)"
        ((WARN_COUNT++))
    else
        echo -e "  ${RED}❌ Response time > 2s${NC} (${RESPONSE_TIME}s)"
        ((FAIL_COUNT++))
    fi
fi

# Transaction rate check (>= 100/sec = pass, >= 50/sec = warn)
if [ -n "$TRANS_RATE" ]; then
    if (( $(echo "$TRANS_RATE >= 100" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${GREEN}✅ Transaction rate >= 100/sec${NC} (${TRANS_RATE}/sec)"
        ((PASS_COUNT++))
    elif (( $(echo "$TRANS_RATE >= 50" | bc -l 2>/dev/null || echo "0") )); then
        echo -e "  ${YELLOW}⚠️  Transaction rate 50-100/sec${NC} (${TRANS_RATE}/sec)"
        ((WARN_COUNT++))
    else
        echo -e "  ${RED}❌ Transaction rate < 50/sec${NC} (${TRANS_RATE}/sec)"
        ((FAIL_COUNT++))
    fi
fi

# Failed transactions (0 = pass, < 10 = warn)
if [ -n "$FAILED" ]; then
    if [ "$FAILED" = "0" ]; then
        echo -e "  ${GREEN}✅ No failed transactions${NC}"
        ((PASS_COUNT++))
    elif [ "$FAILED" -lt "10" ]; then
        echo -e "  ${YELLOW}⚠️  Few failed transactions${NC} ($FAILED)"
        ((WARN_COUNT++))
    else
        echo -e "  ${RED}❌ Many failed transactions${NC} ($FAILED)"
        ((FAIL_COUNT++))
    fi
fi

# =============================================================================
# Post-Stress Validation
# =============================================================================
echo -e "\n${CYAN}📝 Post-Stress Validation${NC}"

# Server responsive after stress?
echo -n "  Server responsive: "
STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://$HOST:$PORT/" 2>/dev/null)
if [ "$STATUS" = "200" ]; then
    echo -e "${GREEN}✅ Yes${NC}"
    ((PASS_COUNT++))
else
    echo -e "${RED}❌ No ($STATUS)${NC}"
    ((FAIL_COUNT++))
fi

# Quick consecutive requests
echo -n "  Handles rapid requests: "
SUCCESS=0
for i in {1..10}; do
    S=$(curl -s -o /dev/null -w "%{http_code}" --max-time 2 "http://$HOST:$PORT/" 2>/dev/null)
    [ "$S" = "200" ] && ((SUCCESS++))
done
if [ $SUCCESS -eq 10 ]; then
    echo -e "${GREEN}✅ 10/10${NC}"
    ((PASS_COUNT++))
else
    echo -e "${YELLOW}⚠️  $SUCCESS/10${NC}"
    ((WARN_COUNT++))
fi

# =============================================================================
# Summary
# =============================================================================
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}                       Summary                                  ${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${GREEN}Passed:${NC}   $PASS_COUNT"
echo -e "  ${YELLOW}Warnings:${NC} $WARN_COUNT"
echo -e "  ${RED}Failed:${NC}   $FAIL_COUNT"
echo ""

echo "Key metrics to check:"
echo "  - Availability should be > 99.5%"
echo "  - No failed transactions during normal load"
echo "  - Response time should be reasonable"
echo ""

if [ $FAIL_COUNT -gt 0 ]; then
    echo -e "${RED}❌ Performance issues detected${NC}"
    exit 1
elif [ $WARN_COUNT -gt 0 ]; then
    echo -e "${YELLOW}⚠️  Performance acceptable with warnings${NC}"
    exit 0
else
    echo -e "${GREEN}✅ Performance test passed!${NC}"
    exit 0
fi
