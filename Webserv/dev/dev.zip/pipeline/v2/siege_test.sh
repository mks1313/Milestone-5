#!/bin/bash
# **************************************************************************** #
#                                                                              #
#    siege_test.sh - Quick Siege Stress Test for Webserv                       #
#                                                                              #
#    WRAPPER: Calls benchmark_tests.sh with --no-start --multi-url             #
#                                                                              #
#    This script maintains backward compatibility (original siege_test.sh      #
#    behavior: server must be running, tests multiple URLs).                   #
#                                                                              #
#    For full control, use benchmark_tests.sh directly:                        #
#      ./benchmark_tests.sh              # Starts server, single URL           #
#      ./benchmark_tests.sh --multi-url  # Starts server, multiple URLs        #
#      ./benchmark_tests.sh --no-start   # Server must be running              #
#      ./benchmark_tests.sh --quick      # Fast test for CI/CD                 #
#                                                                              #
#    By: fcela-ga <fcela-ga@student.42barcelona.com>                           #
#                                                                              #
# **************************************************************************** #

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "$SCRIPT_DIR/benchmark_tests.sh" ]; then
    # Original siege_test.sh behavior:
    # - Server must be running (--no-start)
    # - Tests multiple URLs (--multi-url)
    # Use --start to override and let benchmark_tests.sh start the server
    if [[ " $* " =~ " --start " ]]; then
        args=("${@/--start/}")
        exec "$SCRIPT_DIR/benchmark_tests.sh" --multi-url "${args[@]}"
    else
        exec "$SCRIPT_DIR/benchmark_tests.sh" --no-start --multi-url "$@"
    fi
else
    echo "Error: benchmark_tests.sh not found in $SCRIPT_DIR"
    echo "This script is a wrapper for benchmark_tests.sh"
    exit 1
fi
