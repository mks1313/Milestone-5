# Webserv 2.0 - OOP Refactored

HTTP/1.1 compliant web server implementation in C++98.

## 🏗️ Architecture

```
webserv_refactored/
├── inc/                    # Header files
│   ├── core/               # Base types and exceptions
│   │   ├── Types.hpp       # HttpStatus, enums, structs
│   │   └── Exceptions.hpp  # Custom exception hierarchy
│   ├── utils/              # Utility classes
│   │   ├── Logger.hpp      # Singleton logger with levels
│   │   ├── StringUtils.hpp # String manipulation
│   │   ├── FileUtils.hpp   # File operations
│   │   └── HttpUtils.hpp   # HTTP helpers
│   ├── config/             # Configuration management
│   │   ├── Config.hpp      # Main config parser
│   │   ├── ServerConfig.hpp
│   │   └── LocationConfig.hpp
│   ├── http/               # HTTP protocol
│   │   ├── Request.hpp     # HTTP request parser
│   │   ├── Response.hpp    # HTTP response builder
│   │   └── MimeTypes.hpp   # MIME type mapping
│   ├── server/             # Server core
│   │   ├── Server.hpp      # Main server orchestrator
│   │   ├── Client.hpp      # Client connection state
│   │   ├── SocketManager.hpp
│   │   └── PollManager.hpp
│   ├── handlers/           # Request handlers
│   │   ├── IRequestHandler.hpp
│   │   ├── GetHandler.hpp
│   │   ├── PostHandler.hpp
│   │   ├── PutHandler.hpp
│   │   ├── DeleteHandler.hpp
│   │   └── HandlerFactory.hpp
│   ├── cgi/                # CGI support
│   │   ├── CGIEnvironment.hpp
│   │   ├── CGIExecutor.hpp
│   │   └── CGIHandler.hpp
│   └── session/            # Session management
│       └── SessionManager.hpp
├── src/                    # Implementation files
│   └── [mirrors inc/ structure]
├── config/                 # Configuration files
│   └── webserv.conf
├── www/                    # Web root
│   ├── index.html
│   └── errors/
├── cgi-bin/                # CGI scripts
└── Makefile
```

## 🎯 Design Patterns Used

| Pattern | Implementation | Purpose |
|---------|---------------|---------|
| **Singleton** | Logger, MimeTypes, SessionManager, HandlerFactory | Single instance across application |
| **Factory** | HandlerFactory | Create appropriate handler for HTTP method |
| **Strategy** | IRequestHandler hierarchy | Pluggable request handling |
| **Builder** | Response (fluent interface) | Construct HTTP responses |
| **Composition** | Server uses SocketManager, PollManager | Modular server components |

## 📊 Statistics

| Metric | Original | Refactored |
|--------|----------|------------|
| Files | 24 | 52 |
| Source Lines | 5,651 | 7,419 |
| Header Lines | 1,041 | 2,408 |
| Modules | 1 | 8 |
| Classes | ~8 | 33 |

## 🔧 Build

```bash
make          # Build release
make debug    # Build with sanitizers
make clean    # Clean objects
make fclean   # Full clean
make re       # Rebuild
make info     # Show architecture info
```

## 🚀 Usage

```bash
./webserv [config_file]       # Start server (default: config/webserv.conf)
./webserv --help              # Show help
./webserv --version           # Show version
```

## ✨ Features

- **HTTP/1.1** compliant
- **Methods**: GET, HEAD, POST, PUT, DELETE
- **CGI Support**: Python, PHP, Perl, Shell, custom handlers
- **Session Management**: Cookie-based sessions
- **File Uploads**: Multipart form-data support
- **Directory Listing**: Auto-generated listings
- **Virtual Hosts**: Multiple server configurations
- **Error Pages**: Custom error page support
- **Redirections**: 301/302 redirects
- **Timeouts**: Configurable client/CGI timeouts

## 📋 42 Project Requirements

| Requirement | Status |
|------------|--------|
| C++98 Standard | ✅ |
| No external libraries | ✅ |
| Non-blocking I/O | ✅ |
| Single poll()/select()/epoll() | ✅ |
| Configuration file | ✅ |
| Multiple ports | ✅ |
| Static files | ✅ |
| File uploads | ✅ |
| CGI execution | ✅ |
| Error pages | ✅ |
| HTTP methods (GET/POST/DELETE) | ✅ |

## 🏛️ Class Hierarchy

```
WebServException (base)
├── ConfigException
├── ParseException
├── HttpException
├── SocketException
├── FileException
├── CGIException
└── TimeoutException

IRequestHandler (interface)
├── GetHandler
├── PostHandler
├── PutHandler
└── DeleteHandler
```

## 📝 Module Responsibilities

| Module | Responsibility |
|--------|---------------|
| **Core** | Base types, HTTP status codes, exceptions |
| **Utils** | Logging, string/file/HTTP utilities |
| **Config** | Configuration parsing, validation |
| **HTTP** | Request parsing, response building, MIME types |
| **Server** | Main loop, socket/poll management, client handling |
| **Handlers** | HTTP method-specific request processing |
| **CGI** | CGI environment setup, execution, response handling |
| **Session** | Cookie-based session management |

---

*Webserv 2.0 - 42 Barcelona Project - OOP Refactored Edition*
