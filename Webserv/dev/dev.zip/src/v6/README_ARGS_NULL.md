# ✅ CORRECCIÓN FINAL - args[1] DEBE SER NULL PARA SCRIPTS CGI

## 🎯 EL PROBLEMA REAL ENCONTRADO

Según la documentación de 42 y el artículo de forhjy en Medium sobre CGI Programming:

> **"args[1] has to be a path of cgi file. If it script it has to be NULL."**

**Estábamos pasando el path del script como args[1], pero para scripts CGI (como .bla), args[1] DEBE SER NULL.**

## 🔧 La Corrección Crítica

### ANTES (incorrecto):
```cpp
char* args[3];
args[0] = absoluteCgiPath;      // /app/./testers/ubuntu_cgi_tester
args[1] = absoluteScriptPath;   // /app/YoupiBanane/youpi.bla ❌ INCORRECTO
args[2] = NULL;

execve(args[0], args, envp);
```

### AHORA (correcto):
```cpp
char* args[2];
args[0] = absoluteCgiPath;  // /app/./testers/ubuntu_cgi_tester
args[1] = NULL;             // ✅ NULL para scripts

execve(args[0], args, envp);
```

**El path del script se pasa mediante la variable de entorno `SCRIPT_FILENAME`, NO como argumento del programa.**

## 📊 Variables CGI Correctas

```bash
# Environment variables (pasadas al CGI)
GATEWAY_INTERFACE=CGI/1.1
SERVER_PROTOCOL=HTTP/1.1
SERVER_SOFTWARE=webserv/1.0
REQUEST_METHOD=POST
REDIRECT_STATUS=200
SCRIPT_FILENAME=/app/YoupiBanane/youpi.bla  ← Aquí va el path del script
SCRIPT_NAME=/directory/youpi.bla
PATH_INFO=                                   ← Vacío (no hay path adicional)
QUERY_STRING=
CONTENT_LENGTH=0
SERVER_NAME=localhost
SERVER_PORT=8080
REMOTE_ADDR=127.0.0.1
REMOTE_HOST=127.0.0.1
HTTP_* (headers convertidos)

# Argumentos del programa (argv)
argv[0] = /app/./testers/ubuntu_cgi_tester  ← CGI handler
argv[1] = NULL                               ← NULL para scripts
```

## 🚀 Aplicar

```bash
tar -xzf webserv_ARGS_NULL_FINAL.tar.gz
make re
```

## 🧪 Probar

### Test Manual
```bash
bash test_cgi_manual.sh
```

**Resultado esperado**: CGI ejecuta exitosamente y devuelve HTML (NO más "PATH_INFO not found").

### Test con Servidor
```bash
./bin/webserv config/webserv.conf &
curl -X POST http://localhost:8080/directory/youpi.bla
```

**Resultado esperado**: HTTP 200 con output HTML del CGI.

### Verificar con 42 Tester
```bash
bash tests/diagnose_42_tester.sh
```

**Resultado esperado**: Test de .bla CGI pasa (no más error 500).

## 📖 Explicación Técnica

### Diferencia entre CGI Binary vs CGI Script

**CGI Binary** (ejecutable compilado como php-cgi):
```cpp
args[0] = "/usr/bin/php-cgi"
args[1] = "/path/to/script.php"  ← Path del script
args[2] = NULL
```

**CGI Script** (script interpretado como .bla):
```cpp
args[0] = "/path/to/interpreter"  // El CGI handler
args[1] = NULL                     ← NULL, script en SCRIPT_FILENAME
```

El ubuntu_cgi_tester es un **CGI binary** que **actúa como interpreter** para archivos .bla. Por lo tanto, args[1] debe ser NULL y el script se pasa via SCRIPT_FILENAME.

## 🔍 Por Qué Fallaba Antes

Cuando pasábamos el script como args[1]:
1. El CGI handler recibía el path del script como argumento
2. Pero también buscaba SCRIPT_FILENAME en el environment
3. Al tener AMBOS, el CGI se confundía o priorizaba args[1]
4. Como args[1] apuntaba al path absoluto, el CGI no podía validar PATH_INFO correctamente
5. Resultado: "PATH_INFO not found" o "PATH_INFO incorrect"

Con args[1] = NULL:
1. El CGI solo mira SCRIPT_FILENAME para encontrar el script
2. PATH_INFO se valida correctamente contra la URL
3. Todo funciona como espera el estándar CGI/1.1

## 📚 Referencias

* **RFC 3875** (CGI/1.1): Define cómo pasar información al CGI
* **Medium - forhjy**: "42 Webserv CGI Programming" - Documenta explícitamente que args[1] debe ser NULL para scripts
* **Repositorios 42 exitosos**: Todos usan args[1] = NULL para scripts .bla

## ✅ Estado Final

Con esta corrección, tu servidor debería pasar:
- ✅ CGI tests (ubuntu_cgi_tester)
- ✅ Security tests (32/32 PASS, 2 WARN correctos)
- ✅ Method tests (DELETE, POST, PUT)
- ✅ 42 Official Tester

**Esta es la corrección definitiva basada en la documentación oficial de CGI y proyectos 42 verificados.**
