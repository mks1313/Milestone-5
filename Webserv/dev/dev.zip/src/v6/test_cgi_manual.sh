#!/bin/bash

# Test CGI manually with proper environment variables

echo "Testing CGI with proper environment variables..."
echo ""

cd YoupiBanane

# Get absolute path
SCRIPT_ABS=$(readlink -f youpi.bla)

export REQUEST_METHOD="POST"
export SERVER_PROTOCOL="HTTP/1.1"
export SERVER_SOFTWARE="webserv/1.0"
export GATEWAY_INTERFACE="CGI/1.1"
export CONTENT_LENGTH="0"
export SCRIPT_NAME="/directory/youpi.bla"
export SCRIPT_FILENAME="$SCRIPT_ABS"
export PATH_INFO=""  # Empty for direct script access
export QUERY_STRING=""
export SERVER_NAME="localhost"
export SERVER_PORT="8080"
export REMOTE_ADDR="127.0.0.1"
export REMOTE_HOST="127.0.0.1"
export REDIRECT_STATUS="200"

echo "Environment variables set:"
env | grep -E "REQUEST_METHOD|SERVER|GATEWAY|CONTENT|SCRIPT|PATH_INFO|QUERY|REMOTE|REDIRECT" | sort
echo ""

echo "Executing CGI..."
echo "Command: ../testers/ubuntu_cgi_tester (no arguments - script path in SCRIPT_FILENAME)"
echo ""
echo "=== CGI OUTPUT START ==="
../testers/ubuntu_cgi_tester  # NO arguments, script path is in SCRIPT_FILENAME
echo ""
echo "=== CGI OUTPUT END ==="
echo ""
echo "Exit code: $?"
