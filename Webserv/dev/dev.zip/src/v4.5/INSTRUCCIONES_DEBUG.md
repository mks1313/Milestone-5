# DEBUGGING - Ver Variables CGI Exactas

## Aplicar

```bash
cd ~/Documentos/42-C06-Prj14-Webserv
tar -xzf webserv_DEBUG_ENV.tar.gz
make re
```

## Paso 1: Test Manual del CGI

```bash
chmod +x test_cgi_manual.sh
bash test_cgi_manual.sh
```

**Copia TODA la salida aquí.** Especialmente:
- Las variables mostradas
- El output del CGI
- El exit code

## Paso 2: Test con Servidor

Ejecuta servidor:
```bash
./bin/webserv config/webserv.conf
```

En otra terminal:
```bash
curl -X POST http://localhost:8080/directory/youpi.bla
```

**En los logs del servidor, busca:**
```
[DEBUG] CGI Environment Variables:
  GATEWAY_INTERFACE=CGI/1.1
  SERVER_PROTOCOL=...
  ...
```

**Copia TODAS las líneas de variables CGI.**

## ¿Qué buscar?

El CGI dice "PATH_INFO incorrect". Necesito ver:
1. ¿Qué valor tiene PATH_INFO exactamente?
2. ¿Qué valor tiene SCRIPT_FILENAME?
3. ¿Qué valor tiene SCRIPT_NAME?

Con esa información podré ver exactamente qué espera el CGI.
