#!/bin/bash

# Test CGI manually with proper environment variables

echo "Testing CGI with proper environment variables..."
echo ""

cd YoupiBanane

export REQUEST_METHOD="POST"
export SERVER_PROTOCOL="HTTP/1.1"
export SERVER_SOFTWARE="webserv/1.0"
export GATEWAY_INTERFACE="CGI/1.1"
export CONTENT_LENGTH="0"
export SCRIPT_NAME="/directory/youpi.bla"
export SCRIPT_FILENAME="youpi.bla"
export PATH_INFO=""
export QUERY_STRING=""
export SERVER_NAME="localhost"
export SERVER_PORT="8080"
export REMOTE_ADDR="127.0.0.1"

echo "Environment variables set:"
env | grep -E "REQUEST_METHOD|SERVER_PROTOCOL|CONTENT_LENGTH|SCRIPT|PATH_INFO" | sort
echo ""

echo "Executing CGI..."
echo "Command: ../testers/ubuntu_cgi_tester youpi.bla"
echo ""
echo "=== CGI OUTPUT START ==="
../testers/ubuntu_cgi_tester youpi.bla
echo ""
echo "=== CGI OUTPUT END ==="
echo ""
echo "Exit code: $?"
