# Intento con REDIRECT_STATUS

## Cambios

1. **SCRIPT_FILENAME** = path absoluto (mantenido)
2. **PATH_INFO** = vacío pero presente (mantenido)
3. **REDIRECT_STATUS=200** añadido (NUEVO)

```cpp
envStrings.push_back("REDIRECT_STATUS=200");
envStrings.push_back("SCRIPT_FILENAME=/app/YoupiBanane/youpi.bla");
envStrings.push_back("SCRIPT_NAME=/directory/youpi.bla");
envStrings.push_back(std::string("PATH_INFO="));  // Explícitamente string vacía
```

## Por Qué REDIRECT_STATUS

Algunos CGIs (especialmente en configuraciones FastCGI/PHP-CGI) requieren `REDIRECT_STATUS=200` para funcionar correctamente. Es una variable no estándar pero común.

## Aplicar y Probar

```bash
tar -xzf webserv_WITH_REDIRECT_STATUS.tar.gz
make re
bash test_cgi_manual.sh
```

Si sigue fallando, ejecutar servidor y probar:
```bash
./bin/webserv config/webserv.conf &
curl -X POST http://localhost:8080/directory/youpi.bla
```

## Si TODAVÍA Falla

Si el CGI sigue diciendo "PATH_INFO not found" o "PATH_INFO incorrect", entonces el CGI de 42 tiene requisitos MUY específicos que no están documentados en el estándar CGI/1.1.

En ese caso, necesitamos ver código de referencia de otros proyectos webserv de 42 que hayan pasado este test exitosamente, para ver exactamente qué variables de entorno establecen y con qué valores.

Alternativamente, el CGI de 42 podría tener un bug o requisitos de configuración específicos que no estamos cumpliendo.

## Variables Actuales

Tu servidor ahora envía:
- GATEWAY_INTERFACE=CGI/1.1
- SERVER_PROTOCOL=HTTP/1.1
- SERVER_SOFTWARE=webserv/1.0
- REQUEST_METHOD=POST
- REDIRECT_STATUS=200
- SCRIPT_FILENAME=/app/YoupiBanane/youpi.bla (absoluto)
- SCRIPT_NAME=/directory/youpi.bla
- PATH_INFO= (vacío)
- QUERY_STRING=
- CONTENT_LENGTH=0
- SERVER_NAME=localhost
- SERVER_PORT=8080
- REMOTE_ADDR=127.0.0.1
- HTTP_* headers

Esto debería ser suficiente para cualquier CGI estándar.
