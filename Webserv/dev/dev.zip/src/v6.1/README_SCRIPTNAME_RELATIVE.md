# ✅ CORRECCIÓN: Script Path RELATIVO como args[1]

## 🔍 Análisis de los Errores

Comparando los errores en diferentes contextos:

### Test Manual (con argumento):
```bash
./testers/ubuntu_cgi_tester YoupiBanane/youpi.bla
# Error: "cgi: invalid SERVER_PROTOCOL version"
```

### Servidor (con args[1]=NULL):
```
# Error: "PATH_INFO not found"
```

**Conclusión**: El ubuntu_cgi_tester **SÍ necesita el script path como args[1]**, pero el error "PATH_INFO not found" sugiere que algo más está mal.

## 🔧 La Corrección Aplicada

Después de hacer `chdir()` al directorio del script, el script path debe ser **relativo al directorio actual**.

### ANTES (incorrecto):
```cpp
// Path absoluto como args[1]
args[1] = "/app/YoupiBanane/youpi.bla"  // ❌ 
```

### AHORA (correcto):
```cpp
// Hacemos chdir() al directorio del script primero
chdir("/app/YoupiBanane");

// Luego pasamos solo el nombre del archivo (relativo)
args[1] = "youpi.bla"  // ✅ Relativo al cwd actual
```

## 📝 Estructura Completa

```cpp
// 1. Obtener path absoluto ANTES de chdir
char absoluteScriptPath[PATH_MAX];
realpath("/app/./YoupiBanane/youpi.bla", absoluteScriptPath);
// → "/app/YoupiBanane/youpi.bla"

// 2. Extraer directorio y nombre
std::string scriptDir = "/app/./YoupiBanane";
std::string scriptName = "youpi.bla";

// 3. Cambiar al directorio del script
chdir(scriptDir.c_str());

// 4. Variables de entorno
SCRIPT_FILENAME=/app/YoupiBanane/youpi.bla  ← Path absoluto
SCRIPT_NAME=/directory/youpi.bla             ← Path virtual (URL)
PATH_INFO=                                    ← Vacío

// 5. Argumentos del programa
args[0] = /app/./testers/ubuntu_cgi_tester  ← CGI handler
args[1] = youpi.bla                          ← Nombre relativo (después de chdir)
args[2] = NULL
```

## 🎯 Por Qué Funciona

Esto coincide exactamente con la ejecución manual:

```bash
cd YoupiBanane              # chdir al directorio del script
../testers/ubuntu_cgi_tester youpi.bla  # Ejecutar con nombre relativo
```

El CGI tester:
1. ✅ Recibe el script como args[1] (requerido)
2. ✅ El path es relativo al cwd actual (después de chdir)
3. ✅ SCRIPT_FILENAME tiene el path absoluto
4. ✅ PATH_INFO puede validarse correctamente

## 📊 Variables CGI Completas

```
# Environment
GATEWAY_INTERFACE=CGI/1.1
SERVER_PROTOCOL=HTTP/1.1
SERVER_SOFTWARE=webserv/1.0
REQUEST_METHOD=POST
REDIRECT_STATUS=200
SCRIPT_FILENAME=/app/YoupiBanane/youpi.bla   ← Absoluto
SCRIPT_NAME=/directory/youpi.bla
PATH_INFO=                                    ← Vacío
QUERY_STRING=
CONTENT_LENGTH=0
SERVER_NAME=localhost
SERVER_PORT=8080
REMOTE_ADDR=127.0.0.1
REMOTE_HOST=127.0.0.1
HTTP_* (headers)

# Arguments (después de chdir a /app/YoupiBanane)
argv[0] = /app/./testers/ubuntu_cgi_tester
argv[1] = youpi.bla                           ← Solo nombre de archivo
argv[2] = NULL
```

## 🚀 Aplicar

```bash
tar -xzf webserv_SCRIPTNAME_RELATIVE.tar.gz
make re
```

## 🧪 Probar

### Test Manual
```bash
bash test_cgi_manual.sh
```

**Resultado esperado**: CGI ejecuta exitosamente, devuelve HTML.

### Test con Servidor
```bash
./bin/webserv config/webserv.conf &
curl -X POST http://localhost:8080/directory/youpi.bla
```

**Resultado esperado**: HTTP 200 con HTML del CGI.

### Test 42
```bash
bash tests/diagnose_42_tester.sh
```

**Resultado esperado**: Test 5 (.bla CGI) pasa.

## 💡 Diferencias Clave

| Aspecto | Incorrecto | Correcto |
|---------|-----------|----------|
| **chdir** | ✅ Hecho | ✅ Hecho |
| **args[1]** | Path absoluto o NULL | ✅ Path relativo |
| **SCRIPT_FILENAME** | ✅ Path absoluto | ✅ Path absoluto |
| **cwd al ejecutar** | Directorio del script | ✅ Directorio del script |
| **args[1] relativo a** | / (root) | ✅ cwd (después de chdir) |

## 📚 Lógica del CGI Tester

El ubuntu_cgi_tester probablemente hace algo como:

```c
// Pseudocódigo del CGI tester
char* script_path = argv[1];           // "youpi.bla"
char* absolute_path = getenv("SCRIPT_FILENAME"); // "/app/YoupiBanane/youpi.bla"

// Verificar que el script existe en el cwd actual
if (access(script_path, R_OK) != 0) {
    error("script not found");
}

// Verificar que coincide con SCRIPT_FILENAME
char resolved[PATH_MAX];
realpath(script_path, resolved);  // "youpi.bla" → "/app/YoupiBanane/youpi.bla"

if (strcmp(resolved, absolute_path) != 0) {
    error("script path mismatch");
}

// Ahora validar PATH_INFO...
```

Por eso necesitamos:
1. **args[1] relativo** para que `access()` funcione
2. **SCRIPT_FILENAME absoluto** para verificación
3. **chdir previo** para que el path relativo sea correcto

---

**Esta corrección alinea perfectamente con cómo se ejecuta el CGI manualmente en el diagnóstico.**
