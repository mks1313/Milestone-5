# 🎯 CORRECCIÓN UBUNTU_TESTER - Basada en Evidencia Slack

## 📱 Evidencia del Problema (Thread de seongspa, Agosto 2023)

```
Test GET http://localhost:8888/
Test POST http://localhost:8888/ with a size of 0
FATAL ERROR ON LAST TEST: bad status code
```

**seongspa probó devolver**: 200, 201, **204**, 400, 404 → **TODOS FALLABAN**

**Solución que funcionó**: `405 Method Not Allowed`

**Explicación (hsarhan)**:
> "They only allow GET on that route so any other method is forbidden, 
> which is why they expect 405 METHOD NOT ALLOWED"

---

## ❌ Tu Error EXACTO (Antes de la Corrección)

```bash
GET /  → 200 ✅  # Correcto
POST / → 204 ❌  # INCORRECTO - debe ser 405
```

### Causa del Error

**Server.cpp líneas 735-754**: Existía un "WORKAROUND" que devolvía 204 para POST con Content-Length: 0:

```cpp
// WORKAROUND for ubuntu_tester (42):
// The tester expects POST with Content-Length: 0 to return 200 or 204,
// not 405...  ← ESTO ESTABA MAL

if (method == "POST" && request.getContentLength() == 0)
{
    // Devolvía 204
    resp.setStatusCode(HTTP_NO_CONTENT);
    ...
}
```

**Este workaround contradice la evidencia de Slack**.

---

## ✅ Corrección Aplicada

### Cambio en Server.cpp (líneas 728-741)

**ANTES**:
```cpp
if (location != NULL && !location->isMethodAllowed(methodToCheck))
{
    // Special case: POST with empty body → 204
    if (method == "POST" && request.getContentLength() == 0)
    {
        resp.setStatusCode(HTTP_NO_CONTENT);  // ← INCORRECTO
        ...
        return;
    }
    
    _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
    return;
}
```

**AHORA**:
```cpp
if (location != NULL && !location->isMethodAllowed(methodToCheck))
{
    // According to ubuntu_tester expectations (verified via Slack):
    // POST with size 0 to a GET-only location MUST return 405, not 204
    _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);  // ← CORRECTO
    return;
}
```

### Header "Allow" Ya Implementado

El código ya incluye el header "Allow" en respuestas 405 (RFC 7231):

```cpp
// _sendErrorResponse líneas 1405-1423
if (code == HTTP_METHOD_NOT_ALLOWED)
{
    const LocationConfig* location = serverConfig->findLocation(request.getPath());
    if (location != NULL)
    {
        const std::set<std::string>& methods = location->getAllowedMethods();
        std::string allowHeader;
        for (each method in methods)
            allowHeader += method + ", ";
        
        resp.setHeader("Allow", allowHeader);  // ← Ej: "Allow: GET"
    }
}
```

---

## ✅ CGI NO Modificado

**IMPORTANTE**: Esta corrección **NO toca nada del CGI**.

El código del CGI que corregimos anteriormente (SERVER_PROTOCOL, variables de entorno, etc.) **permanece intacto**.

Los cambios están **solo** en la verificación de métodos permitidos (líneas 728-741).

---

## 🧪 Cómo Probar

### 1. Reemplazar Binario

```bash
cd ~/Documentos/42-C06-Prj14-Webserv
cp webserv bin/webserv  # (el webserv del output)
```

O recompilar desde el código:

```bash
cd ~/Documentos/42-C06-Prj14-Webserv
cp Server.cpp.fixed src/Server.cpp
make re
```

### 2. Iniciar Servidor

```bash
./bin/webserv config/webserv.conf &
sleep 2
```

### 3. Verificar Corrección

```bash
# GET / debe devolver 200
curl -s -o /dev/null -w "GET /: %{http_code}\n" http://localhost:8080/

# POST / debe devolver 405 (NO 204)
curl -s -o /dev/null -w "POST /: %{http_code}\n" -X POST http://localhost:8080/

# Verificar header Allow en respuesta 405
curl -i -X POST http://localhost:8080/ 2>&1 | grep -E "^(HTTP/|Allow:)"
```

**Resultado Esperado**:
```
GET /: 200
POST /: 405

HTTP/1.1 405 Method Not Allowed
Allow: GET
```

### 4. Ejecutar ubuntu_tester

```bash
./testers/ubuntu_tester http://localhost:8080
```

**Resultado Esperado**:
```
Test GET http://localhost:8080/
content returned: [HTML content]

Test POST http://localhost:8080/ with a size of 0
✅ NO MÁS "FATAL ERROR ON LAST TEST: bad status code"
```

---

## 🔍 Verificación de CGI (Asegurar que sigue funcionando)

```bash
# Probar que el CGI todavía funciona
curl -X POST http://localhost:8080/directory/youpi.bla
# Debe devolver 200 con output del CGI
```

---

## 📊 Resumen de Cambios

### Archivos Modificados
- `src/Server.cpp` - Líneas 728-741 (eliminado workaround incorrecto)

### Archivos NO Modificados
- `src/CGIHandler.cpp` - **Sin cambios** (corrección de CGI intacta)
- `config/webserv.conf` - Sin cambios
- Resto de archivos - Sin cambios

### Comportamiento Anterior
```
POST / con Content-Length: 0 → 204 No Content (INCORRECTO)
```

### Comportamiento Ahora
```
POST / con Content-Length: 0 → 405 Method Not Allowed (CORRECTO)
```

---

## ✅ Checklist Final

- [x] Workaround incorrecto eliminado
- [x] Siempre devuelve 405 cuando método no permitido
- [x] Header "Allow" incluido en 405 (ya estaba implementado)
- [x] CGI NO modificado (corrección previa intacta)
- [x] Compilación exitosa sin errores
- [x] Binario actualizado disponible

---

## 🎓 Conclusión

El problema se debía a un **workaround basado en una suposición incorrecta**.

La evidencia del Slack confirma que:
- ✅ POST a location que solo permite GET → **DEBE devolver 405**
- ❌ NO debe devolver 204, 200, 201, etc.

Esta corrección está alineada con:
1. RFC 7231 (HTTP/1.1)
2. Evidencia empírica de 42 (Slack)
3. Comportamiento esperado de ubuntu_tester

**El CGI permanece funcionando** porque no tocamos nada relacionado con CGI.

---

**Fecha**: 27 Diciembre 2025  
**Basado en**: Thread de seongspa (Slack, Agosto 2023)  
**Corrección**: Eliminar workaround que devolvía 204, siempre devolver 405
