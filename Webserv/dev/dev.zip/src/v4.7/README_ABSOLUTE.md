# FIX FINAL: SCRIPT_FILENAME Absoluto + PATH_INFO Vacío

## Cambio Crítico

```cpp
// ANTES
chdir(scriptDir.c_str());
SCRIPT_FILENAME=youpi.bla  // Relativo

// AHORA  
char absoluteScriptPath[PATH_MAX];
realpath(filePath.c_str(), absoluteScriptPath);
chdir(scriptDir.c_str());
SCRIPT_FILENAME=/app/YoupiBanane/youpi.bla  // Absoluto
PATH_INFO=  // Vacío
```

## Por Qué Esto Debería Funcionar

Según el estándar CGI/1.1:
- **SCRIPT_FILENAME** debe ser el path ABSOLUTO completo al archivo del script
- **PATH_INFO** debe estar vacío si no hay path adicional después del script en la URL

El CGI de 42 probablemente verifica que SCRIPT_FILENAME sea un path absoluto válido.

## Aplicar

```bash
tar -xzf webserv_ABSOLUTE_SCRIPT.tar.gz
make re
```

## Probar

```bash
# Test manual
bash test_cgi_manual.sh
```

**Resultado esperado**: El CGI debe funcionar ahora con SCRIPT_FILENAME absoluto.

```bash
# Test servidor
./bin/webserv config/webserv.conf &
curl -X POST http://localhost:8080/directory/youpi.bla
```

**Resultado esperado**: HTTP 200 con output HTML del CGI.

## Si TODAVÍA Falla

Si el CGI sigue fallando incluso con SCRIPT_FILENAME absoluto, el problema puede ser:

1. **El CGI de 42 tiene requisitos específicos no estándar**
2. **Necesitamos ver TODAS las variables que el CGI espera**

En ese caso, ejecuta:
```bash
./bin/webserv config/webserv.conf
```

Y en los logs busca la sección completa:
```
[DEBUG] CGI Environment Variables:
  (copia TODAS las líneas)
```

Compárala con las variables del test manual que funciona.
