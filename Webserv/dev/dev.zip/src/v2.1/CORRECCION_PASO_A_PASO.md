# Guía de Corrección de Server.cpp - DEBUG MODE

## 🚨 PROBLEMA IDENTIFICADO

El código de debug que te proporcioné anteriormente tiene estos errores:
1. ❌ Usa variables (`method`, `methodToCheck`) antes de que se declaren
2. ❌ Llama a `getMethods()` que no existe (el correcto es `getAllowedMethods()`)
3. ❌ Está mal posicionado en el código

## ✅ SOLUCIÓN CORRECTA

### Paso 1: Limpiar el código incorrecto

Abre `src/Server.cpp` y **ELIMINA** todo el bloque de código de debug que insertaste (desde `#ifdef DEBUG_MODE` hasta `#endif`). Tu función `_processRequest` debe quedar así:

```cpp
void Server::_processRequest(Client& client)
{
    const Request& request = client.getRequest();
    
    Utils::logInfo(request.getMethod() + " " + request.getUri() + " from " + client.getIp());

    // Select server configuration
    const ServerConfig* serverConfig = _selectServer(client);
    if (serverConfig == NULL)
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    client.setServerConfig(serverConfig);

    // Find matching location
    const LocationConfig* location = serverConfig->findLocation(request.getPath());

    // Check if redirect
    if (location != NULL && location->hasRedirect())
    {
        _handleRedirect(client, location);
        return;
    }

    // Check method allowed
    const std::string& method = request.getMethod();
    // HEAD should be allowed wherever GET is allowed (HTTP/1.1 spec)
    std::string methodToCheck = method;
    if (method == "HEAD")
        methodToCheck = "GET";
    if (location != NULL && !location->isMethodAllowed(methodToCheck))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }

    // Check body size
    if (request.getContentLength() > serverConfig->getMaxBodySize())
    {
        _sendErrorResponse(client, HTTP_PAYLOAD_TOO_LARGE);
        return;
    }

    // Route by method
    if (method == "GET" || method == "HEAD")
        _handleGet(client, location);
    else if (method == "POST")
        _handlePost(client, location);
    else if (method == "PUT")
        _handlePut(client, location);
    else if (method == "DELETE")
        _handleDelete(client, location);
    else
        _sendErrorResponse(client, HTTP_NOT_IMPLEMENTED);
}
```

### Paso 2: Insertar el código de debug CORRECTO

DESPUÉS de las líneas:
```cpp
    std::string methodToCheck = method;
    if (method == "HEAD")
        methodToCheck = "GET";
```

Y ANTES de la línea:
```cpp
    if (location != NULL && !location->isMethodAllowed(methodToCheck))
```

Inserta este código:

```cpp
    // ========================================================================
    // DEBUG LOGGING
    // ========================================================================
#ifdef DEBUG_MODE
    std::cout << "\n" << CYAN << "╔══════════════════════════════════════════════════════════════" << RESET << std::endl;
    std::cout << CYAN << "║ DEBUG: Request Processing" << RESET << std::endl;
    std::cout << CYAN << "╚══════════════════════════════════════════════════════════════" << RESET << std::endl;
    
    std::cout << YELLOW << "Request Details:" << RESET << std::endl;
    std::cout << "  Method: " << method << std::endl;
    std::cout << "  Path: " << request.getPath() << std::endl;
    std::cout << "  Host: " << request.getHost() << std::endl;
    std::cout << "  Content-Length: " << request.getContentLength() << std::endl;
    
    std::cout << YELLOW << "\nServer Config:" << RESET << std::endl;
    std::cout << "  Server Name: ";
    const std::vector<std::string>& debugNames = serverConfig->getServerNames();
    for (size_t i = 0; i < debugNames.size(); ++i) {
        if (i > 0) std::cout << ", ";
        std::cout << debugNames[i];
    }
    std::cout << std::endl;
    std::cout << "  Max Body Size: " << serverConfig->getMaxBodySize() << std::endl;
    
    std::cout << YELLOW << "\nLocation Matching:" << RESET << std::endl;
    if (location != NULL) {
        std::cout << "  Matched Location: " << GREEN << location->getPath() << RESET << std::endl;
        
        std::cout << "  Allowed Methods: ";
        const std::set<std::string>& debugAllowedMethods = location->getAllowedMethods();
        bool debugFirst = true;
        for (std::set<std::string>::const_iterator it = debugAllowedMethods.begin(); 
             it != debugAllowedMethods.end(); ++it) {
            if (!debugFirst) std::cout << ", ";
            std::cout << *it;
            debugFirst = false;
        }
        std::cout << std::endl;
        
        std::cout << "  isMethodAllowed(\"" << methodToCheck << "\"): "
                  << (location->isMethodAllowed(methodToCheck) ? GREEN "YES" RESET : RED "NO" RESET)
                  << std::endl;
        
        if (!location->getRoot().empty())
            std::cout << "  Root: " << location->getRoot() << std::endl;
        if (!location->getAlias().empty())
            std::cout << "  Alias: " << location->getAlias() << std::endl;
        if (!location->getIndex().empty())
            std::cout << "  Index: " << location->getIndex() << std::endl;
        if (location->hasRedirect())
            std::cout << "  Has Redirect: YES" << std::endl;
        std::cout << "  Max Body Size: " << location->getMaxBodySize() << std::endl;
    } else {
        std::cout << "  " << RED << "No location matched!" << RESET << std::endl;
    }
    
    std::cout << YELLOW << "\nDecision:" << RESET << std::endl;
    if (location != NULL && !location->isMethodAllowed(methodToCheck)) {
        std::cout << "  → " << RED << "405 Method Not Allowed" << RESET << std::endl;
    } else if (request.getContentLength() > serverConfig->getMaxBodySize()) {
        std::cout << "  → " << RED << "413 Payload Too Large" << RESET << std::endl;
    } else if (method == "GET" || method == "HEAD") {
        std::cout << "  → " << GREEN << "_handleGet()" << RESET << std::endl;
    } else if (method == "POST") {
        std::cout << "  → " << GREEN << "_handlePost()" << RESET << std::endl;
    } else if (method == "PUT") {
        std::cout << "  → " << GREEN << "_handlePut()" << RESET << std::endl;
    } else if (method == "DELETE") {
        std::cout << "  → " << GREEN << "_handleDelete()" << RESET << std::endl;
    } else {
        std::cout << "  → " << RED << "501 Not Implemented" << RESET << std::endl;
    }
    
    std::cout << CYAN << "════════════════════════════════════════════════════════════════\n" << RESET << std::endl;
#endif
    // ========================================================================
```

### Paso 3: Resultado Final

Tu función `_processRequest` debe quedar exactamente así:

```cpp
void Server::_processRequest(Client& client)
{
    const Request& request = client.getRequest();
    
    Utils::logInfo(request.getMethod() + " " + request.getUri() + " from " + client.getIp());

    // Select server configuration
    const ServerConfig* serverConfig = _selectServer(client);
    if (serverConfig == NULL)
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    client.setServerConfig(serverConfig);

    // Find matching location
    const LocationConfig* location = serverConfig->findLocation(request.getPath());

    // Check if redirect
    if (location != NULL && location->hasRedirect())
    {
        _handleRedirect(client, location);
        return;
    }

    // Check method allowed
    const std::string& method = request.getMethod();
    // HEAD should be allowed wherever GET is allowed (HTTP/1.1 spec)
    std::string methodToCheck = method;
    if (method == "HEAD")
        methodToCheck = "GET";

    // ========================================================================
    // DEBUG LOGGING
    // ========================================================================
#ifdef DEBUG_MODE
    std::cout << "\n" << CYAN << "╔══════════════════════════════════════════════════════════════" << RESET << std::endl;
    std::cout << CYAN << "║ DEBUG: Request Processing" << RESET << std::endl;
    std::cout << CYAN << "╚══════════════════════════════════════════════════════════════" << RESET << std::endl;
    
    std::cout << YELLOW << "Request Details:" << RESET << std::endl;
    std::cout << "  Method: " << method << std::endl;
    std::cout << "  Path: " << request.getPath() << std::endl;
    std::cout << "  Host: " << request.getHost() << std::endl;
    std::cout << "  Content-Length: " << request.getContentLength() << std::endl;
    
    std::cout << YELLOW << "\nServer Config:" << RESET << std::endl;
    std::cout << "  Server Name: ";
    const std::vector<std::string>& debugNames = serverConfig->getServerNames();
    for (size_t i = 0; i < debugNames.size(); ++i) {
        if (i > 0) std::cout << ", ";
        std::cout << debugNames[i];
    }
    std::cout << std::endl;
    std::cout << "  Max Body Size: " << serverConfig->getMaxBodySize() << std::endl;
    
    std::cout << YELLOW << "\nLocation Matching:" << RESET << std::endl;
    if (location != NULL) {
        std::cout << "  Matched Location: " << GREEN << location->getPath() << RESET << std::endl;
        
        std::cout << "  Allowed Methods: ";
        const std::set<std::string>& debugAllowedMethods = location->getAllowedMethods();
        bool debugFirst = true;
        for (std::set<std::string>::const_iterator it = debugAllowedMethods.begin(); 
             it != debugAllowedMethods.end(); ++it) {
            if (!debugFirst) std::cout << ", ";
            std::cout << *it;
            debugFirst = false;
        }
        std::cout << std::endl;
        
        std::cout << "  isMethodAllowed(\"" << methodToCheck << "\"): "
                  << (location->isMethodAllowed(methodToCheck) ? GREEN "YES" RESET : RED "NO" RESET)
                  << std::endl;
        
        if (!location->getRoot().empty())
            std::cout << "  Root: " << location->getRoot() << std::endl;
        if (!location->getAlias().empty())
            std::cout << "  Alias: " << location->getAlias() << std::endl;
        if (!location->getIndex().empty())
            std::cout << "  Index: " << location->getIndex() << std::endl;
        if (location->hasRedirect())
            std::cout << "  Has Redirect: YES" << std::endl;
        std::cout << "  Max Body Size: " << location->getMaxBodySize() << std::endl;
    } else {
        std::cout << "  " << RED << "No location matched!" << RESET << std::endl;
    }
    
    std::cout << YELLOW << "\nDecision:" << RESET << std::endl;
    if (location != NULL && !location->isMethodAllowed(methodToCheck)) {
        std::cout << "  → " << RED << "405 Method Not Allowed" << RESET << std::endl;
    } else if (request.getContentLength() > serverConfig->getMaxBodySize()) {
        std::cout << "  → " << RED << "413 Payload Too Large" << RESET << std::endl;
    } else if (method == "GET" || method == "HEAD") {
        std::cout << "  → " << GREEN << "_handleGet()" << RESET << std::endl;
    } else if (method == "POST") {
        std::cout << "  → " << GREEN << "_handlePost()" << RESET << std::endl;
    } else if (method == "PUT") {
        std::cout << "  → " << GREEN << "_handlePut()" << RESET << std::endl;
    } else if (method == "DELETE") {
        std::cout << "  → " << GREEN << "_handleDelete()" << RESET << std::endl;
    } else {
        std::cout << "  → " << RED << "501 Not Implemented" << RESET << std::endl;
    }
    
    std::cout << CYAN << "════════════════════════════════════════════════════════════════\n" << RESET << std::endl;
#endif
    // ========================================================================

    if (location != NULL && !location->isMethodAllowed(methodToCheck))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }

    // Check body size
    if (request.getContentLength() > serverConfig->getMaxBodySize())
    {
        _sendErrorResponse(client, HTTP_PAYLOAD_TOO_LARGE);
        return;
    }

    // Route by method
    if (method == "GET" || method == "HEAD")
        _handleGet(client, location);
    else if (method == "POST")
        _handlePost(client, location);
    else if (method == "PUT")
        _handlePut(client, location);
    else if (method == "DELETE")
        _handleDelete(client, location);
    else
        _sendErrorResponse(client, HTTP_NOT_IMPLEMENTED);
}
```

## 🧪 Verificación

### Test 1: Compilar SIN debug (debe funcionar)
```bash
make re
```
**Expected**: Compilación exitosa, sin errores ✅

### Test 2: Compilar CON debug (debe funcionar)
```bash
make re CXXFLAGS="-Wall -Wextra -Werror -std=c++98 -DDEBUG_MODE"
```
**Expected**: Compilación exitosa, sin errores ✅

### Test 3: Probar el servidor con debug
```bash
# Terminal 1
./bin/webserv config/webserv.conf

# Terminal 2  
curl -X DELETE http://localhost:8080/
curl -X POST -d "test" http://localhost:8080/post_body
```

**Expected**: En Terminal 1 verás el output de debug mostrando qué location se matchea y qué métodos están permitidos.

## 📊 Output de Debug Esperado

Cuando hagas `curl -X DELETE http://localhost:8080/` deberías ver algo como:

```
╔══════════════════════════════════════════════════════════════
║ DEBUG: Request Processing
╚══════════════════════════════════════════════════════════════
Request Details:
  Method: DELETE
  Path: /
  Host: localhost
  Content-Length: 0

Server Config:
  Server Name: localhost, webserv.local
  Max Body Size: 1048576

Location Matching:
  Matched Location: /
  Allowed Methods: GET
  isMethodAllowed("DELETE"): NO
  Root: ./www
  Index: index.html
  Max Body Size: 1048576

Decision:
  → 405 Method Not Allowed

════════════════════════════════════════════════════════════════
```

## 🔍 Interpretación del Debug

### Si DELETE / devuelve 403 pero el debug muestra "405 Method Not Allowed":
→ El problema está DESPUÉS de la verificación, probablemente en `_handleDelete()`

### Si el debug muestra "Matched Location" diferente de "/":
→ El problema está en el location matching (ServerConfig::findLocation)

### Si el debug muestra "isMethodAllowed(DELETE): YES":
→ El problema está en la configuración - DELETE está permitido cuando no debería

## ✅ Checklist

- [ ] Eliminar código de debug incorrecto anterior
- [ ] Insertar código de debug correcto en la posición exacta
- [ ] Compilar sin debug: `make re` → ✅ Sin errores
- [ ] Compilar con debug: `make re CXXFLAGS="... -DDEBUG_MODE"` → ✅ Sin errores
- [ ] Ejecutar servidor con debug
- [ ] Hacer pruebas con curl
- [ ] Analizar output de debug
- [ ] Identificar la causa raíz del problema

## 💡 Notas Importantes

1. **Nombres de variables con prefijo "debug"**: Para evitar conflictos, las variables temporales del debug tienen prefijo "debug" (debugNames, debugAllowedMethods, debugFirst)

2. **Se compila con y sin DEBUG_MODE**: El código es completamente opcional gracias a `#ifdef DEBUG_MODE`

3. **Compatible con C++98**: No usa características modernas de C++

4. **No afecta el rendimiento en producción**: Cuando compilas sin -DDEBUG_MODE, el código de debug no existe en el binario

## 🚀 Próximos Pasos

Después de ver el output de debug, sabrás exactamente cuál es el problema y podrás:
1. Corregir el location matching si es necesario
2. Corregir la configuración si es necesario  
3. Corregir la lógica de verificación de métodos si es necesario

Una vez resueltos los problemas, **ELIMINA** el código de debug y compila sin -DDEBUG_MODE para producción.
