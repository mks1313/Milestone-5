/*
 * DEBUG_PATCH_CORRECTED.cpp
 * 
 * VERSIÓN CORREGIDA - Compila perfectamente con y sin DEBUG_MODE
 *
 * Este código debe insertarse en Server.cpp en _processRequest()
 * DESPUÉS de las líneas donde se declaran method y methodToCheck
 */

// ============================================================================
// UBICACIÓN EXACTA EN Server.cpp
// ============================================================================
/*
 * Busca estas líneas en _processRequest() (aproximadamente línea 800):
 *
 *     // Check method allowed
 *     const std::string& method = request.getMethod();
 *     // HEAD should be allowed wherever GET is allowed (HTTP/1.1 spec)
 *     std::string methodToCheck = method;
 *     if (method == "HEAD")
 *         methodToCheck = "GET";
 *
 * JUSTO DESPUÉS de esas líneas (DESPUÉS de declarar methodToCheck), 
 * ANTES de la línea:
 *     if (location != NULL && !location->isMethodAllowed(methodToCheck))
 *
 * Insertar el siguiente código:
 */

// ============================================================================
// DEBUG LOGGING - INICIO
// ============================================================================

#ifdef DEBUG_MODE
    std::cout << "\n" << CYAN << "╔══════════════════════════════════════════════════════════════" << RESET << std::endl;
    std::cout << CYAN << "║ DEBUG: Request Processing" << RESET << std::endl;
    std::cout << CYAN << "╚══════════════════════════════════════════════════════════════" << RESET << std::endl;
    
    // Request info
    std::cout << YELLOW << "Request Details:" << RESET << std::endl;
    std::cout << "  Method: " << method << std::endl;
    std::cout << "  Path: " << request.getPath() << std::endl;
    std::cout << "  Host: " << request.getHost() << std::endl;
    std::cout << "  Content-Length: " << request.getContentLength() << std::endl;
    
    // Server config
    std::cout << YELLOW << "\nServer Config:" << RESET << std::endl;
    std::cout << "  Server Name: ";
    const std::vector<std::string>& names = serverConfig->getServerNames();
    for (size_t i = 0; i < names.size(); ++i) {
        if (i > 0) std::cout << ", ";
        std::cout << names[i];
    }
    std::cout << std::endl;
    std::cout << "  Max Body Size: " << serverConfig->getMaxBodySize() << std::endl;
    
    // Location matching
    std::cout << YELLOW << "\nLocation Matching:" << RESET << std::endl;
    if (location != NULL) {
        std::cout << "  Matched Location: " << GREEN << location->getPath() << RESET << std::endl;
        
        // Allowed methods (usando getAllowedMethods que devuelve set<string>)
        std::cout << "  Allowed Methods: ";
        const std::set<std::string>& allowedMethods = location->getAllowedMethods();
        bool first = true;
        for (std::set<std::string>::const_iterator it = allowedMethods.begin(); 
             it != allowedMethods.end(); ++it) {
            if (!first) std::cout << ", ";
            std::cout << *it;
            first = false;
        }
        std::cout << std::endl;
        
        // Method check
        std::cout << "  isMethodAllowed(\"" << methodToCheck << "\"): "
                  << (location->isMethodAllowed(methodToCheck) ? GREEN "YES" RESET : RED "NO" RESET)
                  << std::endl;
        
        // Other location properties
        if (!location->getRoot().empty())
            std::cout << "  Root: " << location->getRoot() << std::endl;
        if (!location->getAlias().empty())
            std::cout << "  Alias: " << location->getAlias() << std::endl;
        if (!location->getIndex().empty())
            std::cout << "  Index: " << location->getIndex() << std::endl;
        if (location->hasRedirect())
            std::cout << "  Has Redirect: YES" << std::endl;
        std::cout << "  Max Body Size: " << location->getMaxBodySize() << std::endl;
    } else {
        std::cout << "  " << RED << "No location matched!" << RESET << std::endl;
    }
    
    // Decision
    std::cout << YELLOW << "\nDecision:" << RESET << std::endl;
    if (location != NULL && !location->isMethodAllowed(methodToCheck)) {
        std::cout << "  → " << RED << "405 Method Not Allowed" << RESET << std::endl;
    } else if (request.getContentLength() > serverConfig->getMaxBodySize()) {
        std::cout << "  → " << RED << "413 Payload Too Large" << RESET << std::endl;
    } else if (method == "GET" || method == "HEAD") {
        std::cout << "  → " << GREEN << "_handleGet()" << RESET << std::endl;
    } else if (method == "POST") {
        std::cout << "  → " << GREEN << "_handlePost()" << RESET << std::endl;
    } else if (method == "PUT") {
        std::cout << "  → " << GREEN << "_handlePut()" << RESET << std::endl;
    } else if (method == "DELETE") {
        std::cout << "  → " << GREEN << "_handleDelete()" << RESET << std::endl;
    } else {
        std::cout << "  → " << RED << "501 Not Implemented" << RESET << std::endl;
    }
    
    std::cout << CYAN << "════════════════════════════════════════════════════════════════\n" << RESET << std::endl;
#endif

// ============================================================================
// DEBUG LOGGING - FIN
// ============================================================================

/*
 * DESPUÉS de este código de debug, continúa el código normal:
 *
 *     if (location != NULL && !location->isMethodAllowed(methodToCheck))
 *     {
 *         _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
 *         return;
 *     }
 *     ... resto del código ...
 */

// ============================================================================
// CÓDIGO COMPLETO DE _processRequest CON DEBUG
// ============================================================================

/*
 * Aquí está la función _processRequest COMPLETA con el debug integrado
 * correctamente. Puedes copiar esta función completa y reemplazar la que tienes:
 */

void Server::_processRequest(Client& client)
{
    const Request& request = client.getRequest();
    
    Utils::logInfo(request.getMethod() + " " + request.getUri() + " from " + client.getIp());

    // Select server configuration
    const ServerConfig* serverConfig = _selectServer(client);
    if (serverConfig == NULL)
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    client.setServerConfig(serverConfig);

    // Find matching location
    const LocationConfig* location = serverConfig->findLocation(request.getPath());

    // Check if redirect
    if (location != NULL && location->hasRedirect())
    {
        _handleRedirect(client, location);
        return;
    }

    // Check method allowed
    const std::string& method = request.getMethod();
    // HEAD should be allowed wherever GET is allowed (HTTP/1.1 spec)
    std::string methodToCheck = method;
    if (method == "HEAD")
        methodToCheck = "GET";

    // ========================================================================
    // DEBUG LOGGING - Solo se compila si DEBUG_MODE está definido
    // ========================================================================
#ifdef DEBUG_MODE
    std::cout << "\n" << CYAN << "╔══════════════════════════════════════════════════════════════" << RESET << std::endl;
    std::cout << CYAN << "║ DEBUG: Request Processing" << RESET << std::endl;
    std::cout << CYAN << "╚══════════════════════════════════════════════════════════════" << RESET << std::endl;
    
    // Request info
    std::cout << YELLOW << "Request Details:" << RESET << std::endl;
    std::cout << "  Method: " << method << std::endl;
    std::cout << "  Path: " << request.getPath() << std::endl;
    std::cout << "  Host: " << request.getHost() << std::endl;
    std::cout << "  Content-Length: " << request.getContentLength() << std::endl;
    
    // Server config
    std::cout << YELLOW << "\nServer Config:" << RESET << std::endl;
    std::cout << "  Server Name: ";
    const std::vector<std::string>& names = serverConfig->getServerNames();
    for (size_t i = 0; i < names.size(); ++i) {
        if (i > 0) std::cout << ", ";
        std::cout << names[i];
    }
    std::cout << std::endl;
    std::cout << "  Max Body Size: " << serverConfig->getMaxBodySize() << std::endl;
    
    // Location matching
    std::cout << YELLOW << "\nLocation Matching:" << RESET << std::endl;
    if (location != NULL) {
        std::cout << "  Matched Location: " << GREEN << location->getPath() << RESET << std::endl;
        
        // Allowed methods
        std::cout << "  Allowed Methods: ";
        const std::set<std::string>& allowedMethods = location->getAllowedMethods();
        bool first = true;
        for (std::set<std::string>::const_iterator it = allowedMethods.begin(); 
             it != allowedMethods.end(); ++it) {
            if (!first) std::cout << ", ";
            std::cout << *it;
            first = false;
        }
        std::cout << std::endl;
        
        // Method check
        std::cout << "  isMethodAllowed(\"" << methodToCheck << "\"): "
                  << (location->isMethodAllowed(methodToCheck) ? GREEN "YES" RESET : RED "NO" RESET)
                  << std::endl;
        
        // Other location properties
        if (!location->getRoot().empty())
            std::cout << "  Root: " << location->getRoot() << std::endl;
        if (!location->getAlias().empty())
            std::cout << "  Alias: " << location->getAlias() << std::endl;
        if (!location->getIndex().empty())
            std::cout << "  Index: " << location->getIndex() << std::endl;
        if (location->hasRedirect())
            std::cout << "  Has Redirect: YES" << std::endl;
        std::cout << "  Max Body Size: " << location->getMaxBodySize() << std::endl;
    } else {
        std::cout << "  " << RED << "No location matched!" << RESET << std::endl;
    }
    
    // Decision
    std::cout << YELLOW << "\nDecision:" << RESET << std::endl;
    if (location != NULL && !location->isMethodAllowed(methodToCheck)) {
        std::cout << "  → " << RED << "405 Method Not Allowed" << RESET << std::endl;
    } else if (request.getContentLength() > serverConfig->getMaxBodySize()) {
        std::cout << "  → " << RED << "413 Payload Too Large" << RESET << std::endl;
    } else if (method == "GET" || method == "HEAD") {
        std::cout << "  → " << GREEN << "_handleGet()" << RESET << std::endl;
    } else if (method == "POST") {
        std::cout << "  → " << GREEN << "_handlePost()" << RESET << std::endl;
    } else if (method == "PUT") {
        std::cout << "  → " << GREEN << "_handlePut()" << RESET << std::endl;
    } else if (method == "DELETE") {
        std::cout << "  → " << GREEN << "_handleDelete()" << RESET << std::endl;
    } else {
        std::cout << "  → " << RED << "501 Not Implemented" << RESET << std::endl;
    }
    
    std::cout << CYAN << "════════════════════════════════════════════════════════════════\n" << RESET << std::endl;
#endif
    // ========================================================================
    // FIN DEBUG LOGGING
    // ========================================================================

    // Verificación de método permitido
    if (location != NULL && !location->isMethodAllowed(methodToCheck))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }

    // Check body size
    if (request.getContentLength() > serverConfig->getMaxBodySize())
    {
        _sendErrorResponse(client, HTTP_PAYLOAD_TOO_LARGE);
        return;
    }

    // Route by method
    if (method == "GET" || method == "HEAD")
        _handleGet(client, location);
    else if (method == "POST")
        _handlePost(client, location);
    else if (method == "PUT")
        _handlePut(client, location);
    else if (method == "DELETE")
        _handleDelete(client, location);
    else
        _sendErrorResponse(client, HTTP_NOT_IMPLEMENTED);
}

// ============================================================================
// INSTRUCCIONES DE USO
// ============================================================================

/*
 * OPCIÓN 1: Copiar la función _processRequest completa
 * -------------------------------------------------------
 * 1. Copia toda la función _processRequest de arriba
 * 2. Reemplaza la función _processRequest actual en src/Server.cpp
 * 3. Compila:
 *    - Sin debug: make re
 *    - Con debug: make re CXXFLAGS="-Wall -Wextra -Werror -std=c++98 -DDEBUG_MODE"
 *
 * OPCIÓN 2: Insertar solo el bloque de debug
 * -------------------------------------------
 * 1. Busca en src/Server.cpp la función _processRequest
 * 2. Encuentra estas líneas:
 *        const std::string& method = request.getMethod();
 *        std::string methodToCheck = method;
 *        if (method == "HEAD")
 *            methodToCheck = "GET";
 * 
 * 3. JUSTO DESPUÉS de esas líneas, ANTES de:
 *        if (location != NULL && !location->isMethodAllowed(methodToCheck))
 *
 * 4. Inserta el bloque #ifdef DEBUG_MODE ... #endif completo de arriba
 *
 * VERIFICACIÓN:
 * -------------
 * 1. Compilar SIN debug (debe compilar sin errores):
 *    make re
 *
 * 2. Compilar CON debug (debe compilar sin errores):
 *    make re CXXFLAGS="-Wall -Wextra -Werror -std=c++98 -DDEBUG_MODE"
 *
 * 3. Ejecutar servidor con debug:
 *    ./bin/webserv config/webserv.conf
 *
 * 4. Probar en otro terminal:
 *    curl -X DELETE http://localhost:8080/
 *    curl -X POST -d "test" http://localhost:8080/post_body
 *
 * 5. Ver el output de debug en el terminal del servidor
 */

// ============================================================================
// IMPORTANTE
// ============================================================================

/*
 * Este código:
 * ✅ Compila correctamente sin -DDEBUG_MODE (el código de debug se omite)
 * ✅ Compila correctamente con -DDEBUG_MODE (el código de debug se incluye)
 * ✅ Usa los métodos correctos de LocationConfig (getAllowedMethods devuelve set)
 * ✅ Las variables method y methodToCheck están declaradas ANTES de usarse
 * ✅ No interfiere con el flujo normal del programa
 * ✅ Es compatible con C++98
 *
 * El código de debug anterior estaba mal porque:
 * ❌ Usaba variables antes de declararlas
 * ❌ Llamaba a getMethods() que no existe (es getAllowedMethods())
 * ❌ El #ifdef estaba mal colocado
 */
