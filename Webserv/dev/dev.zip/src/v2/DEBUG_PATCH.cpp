/*
 * DEBUG_PATCH.cpp
 * 
 * Añadir este código de debug en Server.cpp para investigar los problemas
 * de DELETE / y POST /post_body
 *
 * UBICACIÓN: Justo después de la línea 720 en Server.cpp
 *            (antes de la verificación de métodos permitidos)
 */

// ============================================================================
// DEBUG LOGGING - INICIO
// ============================================================================

#ifdef DEBUG_MODE
    std::cout << "\n" << CYAN << "╔══════════════════════════════════════════════════════════════" << RESET << std::endl;
    std::cout << CYAN << "║ DEBUG: Request Processing" << RESET << std::endl;
    std::cout << CYAN << "╚══════════════════════════════════════════════════════════════" << RESET << std::endl;
    
    // Request info
    std::cout << YELLOW << "Request Details:" << RESET << std::endl;
    std::cout << "  Method: " << method << std::endl;
    std::cout << "  Path: " << request.getPath() << std::endl;
    std::cout << "  Host: " << request.getHost() << std::endl;
    std::cout << "  Content-Length: " << request.getContentLength() << std::endl;
    
    // Server config
    std::cout << YELLOW << "\nServer Config:" << RESET << std::endl;
    std::cout << "  Server Name: ";
    const std::vector<std::string>& names = serverConfig->getServerNames();
    for (size_t i = 0; i < names.size(); ++i) {
        if (i > 0) std::cout << ", ";
        std::cout << names[i];
    }
    std::cout << std::endl;
    std::cout << "  Max Body Size: " << serverConfig->getMaxBodySize() << std::endl;
    
    // Location matching
    std::cout << YELLOW << "\nLocation Matching:" << RESET << std::endl;
    if (location != NULL) {
        std::cout << "  Matched Location: " << GREEN << location->getPath() << RESET << std::endl;
        
        // Allowed methods
        std::cout << "  Allowed Methods: ";
        const std::vector<std::string>& allowedMethods = location->getMethods();
        for (size_t i = 0; i < allowedMethods.size(); ++i) {
            if (i > 0) std::cout << ", ";
            std::cout << allowedMethods[i];
        }
        std::cout << std::endl;
        
        // Method check
        std::cout << "  isMethodAllowed(\"" << methodToCheck << "\"): "
                  << (location->isMethodAllowed(methodToCheck) ? GREEN "YES" RESET : RED "NO" RESET)
                  << std::endl;
        
        // Other location properties
        if (!location->getRoot().empty())
            std::cout << "  Root: " << location->getRoot() << std::endl;
        if (!location->getAlias().empty())
            std::cout << "  Alias: " << location->getAlias() << std::endl;
        if (!location->getIndex().empty())
            std::cout << "  Index: " << location->getIndex() << std::endl;
        if (location->hasRedirect())
            std::cout << "  Has Redirect: YES" << std::endl;
        std::cout << "  Max Body Size: " << location->getMaxBodySize() << std::endl;
    } else {
        std::cout << "  " << RED << "No location matched!" << RESET << std::endl;
    }
    
    // Decision
    std::cout << YELLOW << "\nDecision:" << RESET << std::endl;
    if (location != NULL && !location->isMethodAllowed(methodToCheck)) {
        std::cout << "  → " << RED << "405 Method Not Allowed" << RESET << std::endl;
    } else if (request.getContentLength() > serverConfig->getMaxBodySize()) {
        std::cout << "  → " << RED << "413 Payload Too Large" << RESET << std::endl;
    } else if (method == "GET" || method == "HEAD") {
        std::cout << "  → " << GREEN << "_handleGet()" << RESET << std::endl;
    } else if (method == "POST") {
        std::cout << "  → " << GREEN << "_handlePost()" << RESET << std::endl;
    } else if (method == "PUT") {
        std::cout << "  → " << GREEN << "_handlePut()" << RESET << std::endl;
    } else if (method == "DELETE") {
        std::cout << "  → " << GREEN << "_handleDelete()" << RESET << std::endl;
    } else {
        std::cout << "  → " << RED << "501 Not Implemented" << RESET << std::endl;
    }
    
    std::cout << CYAN << "════════════════════════════════════════════════════════════════\n" << RESET << std::endl;
#endif

// ============================================================================
// DEBUG LOGGING - FIN
// ============================================================================

/*
 * INSTRUCCIONES DE USO:
 *
 * 1. Editar src/Server.cpp:
 *    - Buscar la línea ~720 donde dice:
 *      // Check method allowed
 *      const std::string& method = request.getMethod();
 *
 *    - DESPUÉS de esas líneas, copiar el código de DEBUG LOGGING de arriba
 *
 * 2. Compilar con flag DEBUG_MODE:
 *    make re CXXFLAGS="-Wall -Wextra -Werror -std=c++98 -DDEBUG_MODE"
 *
 * 3. Ejecutar el servidor:
 *    ./bin/webserv config/webserv.conf
 *
 * 4. En otro terminal, hacer las pruebas:
 *    curl -X DELETE http://localhost:8080/
 *    curl -X POST -d "test" http://localhost:8080/post_body
 *
 * 5. Analizar la salida de debug en el terminal del servidor
 *
 * EJEMPLO DE SALIDA ESPERADA:
 *
 * ╔══════════════════════════════════════════════════════════════
 * ║ DEBUG: Request Processing
 * ╚══════════════════════════════════════════════════════════════
 * Request Details:
 *   Method: DELETE
 *   Path: /
 *   Host: localhost
 *   Content-Length: 0
 *
 * Server Config:
 *   Server Name: localhost, webserv.local
 *   Max Body Size: 1048576
 *
 * Location Matching:
 *   Matched Location: /
 *   Allowed Methods: GET
 *   isMethodAllowed("DELETE"): NO    ← DEBERÍA SER NO
 *   Root: ./www
 *   Index: index.html
 *   Max Body Size: 1048576
 *
 * Decision:
 *   → 405 Method Not Allowed    ← DEBERÍA SER ESTO, NO 403
 *
 * ════════════════════════════════════════════════════════════════
 *
 * SI LA SALIDA ES DIFERENTE:
 *
 * - Si "Matched Location" NO es "/", entonces el problema está en el location matching
 * - Si "isMethodAllowed(DELETE)" es "YES", entonces el problema está en la configuración
 * - Si "Decision" es "405" pero el cliente recibe "403", el problema está después
 *
 * NOTA: Después de resolver los bugs, REMOVER este código de debug y recompilar sin -DDEBUG_MODE
 */

// ============================================================================
// CÓDIGO ADICIONAL: Debug para _handleDelete
// ============================================================================

/*
 * Si el debug anterior muestra que el método NO está permitido pero aún así
 * llega a _handleDelete(), añadir este código al INICIO de _handleDelete():
 */

#ifdef DEBUG_MODE
void Server::_handleDelete(Client& client, const LocationConfig* location)
{
    std::cout << RED << "╔═══════════════════════════════════════" << RESET << std::endl;
    std::cout << RED << "║ ERROR: _handleDelete() called!" << RESET << std::endl;
    std::cout << RED << "╚═══════════════════════════════════════" << RESET << std::endl;
    std::cout << "This function should NOT be called if DELETE is not allowed!" << std::endl;
    std::cout << "Check method verification logic in _processRequest()" << std::endl;
    std::cout << std::endl;
    
    // ... resto del código de _handleDelete ...
#endif

// ============================================================================
// CÓDIGO ADICIONAL: Debug para findLocation
// ============================================================================

/*
 * Si sospechas que el problema está en el location matching, añade este código
 * en ServerConfig.cpp, en la función findLocation():
 */

#ifdef DEBUG_MODE
const LocationConfig* ServerConfig::findLocation(const std::string& path) const
{
    std::cout << BLUE << "╔═══════════════════════════════════════" << RESET << std::endl;
    std::cout << BLUE << "║ DEBUG: findLocation()" << RESET << std::endl;
    std::cout << BLUE << "╚═══════════════════════════════════════" << RESET << std::endl;
    std::cout << "  Searching location for path: " << path << std::endl;
    std::cout << "  Available locations:" << std::endl;
    
    for (size_t i = 0; i < _locations.size(); ++i) {
        std::cout << "    [" << i << "] " << _locations[i].getPath() << std::endl;
    }
    
    // ... código existente de matching ...
    
    if (bestMatch != NULL) {
        std::cout << "  → Matched: " << GREEN << bestMatch->getPath() << RESET << std::endl;
    } else {
        std::cout << "  → " << RED << "No match found" << RESET << std::endl;
    }
    std::cout << std::endl;
    
    return bestMatch;
}
#endif

// ============================================================================
// RESUMEN DE PASOS
// ============================================================================

/*
 * PASO 1: Añadir debug logging a Server.cpp (línea ~720)
 * PASO 2: Compilar con DEBUG_MODE:
 *         make re CXXFLAGS="-Wall -Wextra -Werror -std=c++98 -DDEBUG_MODE"
 * PASO 3: Ejecutar servidor y hacer pruebas
 * PASO 4: Analizar output de debug
 * PASO 5: Identificar dónde está el problema
 * PASO 6: Corregir el bug
 * PASO 7: Remover código de debug
 * PASO 8: Compilar sin DEBUG_MODE: make re
 * PASO 9: Verificar que los tests pasan
 */
