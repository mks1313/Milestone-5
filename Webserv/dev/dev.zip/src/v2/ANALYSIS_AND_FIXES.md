# WebServ - Análisis de Problemas y Correcciones

## Resumen Ejecutivo

Análisis completo de los fallos detectados en los tests del proyecto webserv de 42 Barcelona.

**Estado Actual:**
- Security Tests: 30 PASS, 4 WARN, 0 FAIL ✅
- Benchmark Tests: CRASH (descriptor table full, connection refused)
- 42 Tester Diagnostic: 5 PASS, 5 FAIL
- Test Suite: 38 PASS, 0 FAIL (pero con warnings de inicialización)

---

## PROBLEMA 1: DELETE / devuelve 403 en lugar de 405

### Diagnóstico
```
Expected: 405 (Method Not Allowed)
Actual:   403 (Forbidden)
```

### Causa Raíz
El flujo del código es:
1. Request llega con `DELETE /`
2. Server.cpp línea 727: Verifica si el método está permitido en la location `/`
3. **ERROR**: La location `/` NO tiene DELETE en los métodos permitidos (solo GET)
4. **DEBERÍA** devolver 405 aquí, pero continúa
5. Llega a `_handleDelete()` (línea 922)
6. Intenta hacer stat() en "/" (que es un directorio)
7. Verifica si es archivo regular (línea 936): `S_ISREG(fileStat.st_mode)`
8. Como "/" es directorio, devuelve 403 (FORBIDDEN)

### Análisis del Código

**Server.cpp líneas 727-731:**
```cpp
if (location != NULL && !location->isMethodAllowed(methodToCheck))
{
    _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
    return;
}
```

El problema es que esta verificación SÍ está funcionando correctamente, pero algo más está pasando. Necesito verificar la configuración de métodos permitidos.

### Solución

**OPCIÓN A: Verificar que la configuración esté correcta**

El archivo `config/webserv.conf` línea 39 dice:
```nginx
location / {
    methods GET;
    autoindex on;
}
```

Esto está CORRECTO. Solo permite GET. Sin embargo, el servidor devuelve 403 en lugar de 405.

**Posible causa**: El servidor está matcheando con otra location o el método DELETE se está permitiendo globalmente.

**OPCIÓN B: Mejorar la verificación de métodos**

En `Server.cpp`, ANTES de llamar a `_handleDelete`, verificar explícitamente:

```cpp
// En handleRequest(), líneas 720-750
// Después de la línea 731, añadir para métodos específicos:

// Check method allowed
const std::string& method = request.getMethod();
std::string methodToCheck = method;
if (method == "HEAD")
    methodToCheck = "GET";
    
// NUEVA VERIFICACIÓN EXPLÍCITA
if (location != NULL && !location->isMethodAllowed(methodToCheck))
{
    _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
    return;
}

// Verificación adicional: si el método no está implementado globalmente
if (method != "GET" && method != "HEAD" && method != "POST" && 
    method != "DELETE" && method != "PUT")
{
    _sendErrorResponse(client, HTTP_NOT_IMPLEMENTED);
    return;
}

// CORRECCIÓN: Verificar que si location existe y método no permitido, devolver 405
if (location != NULL)
{
    // Para DELETE, verificar explícitamente
    if (method == "DELETE" && !location->isMethodAllowed("DELETE"))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }
    // Para PUT, verificar explícitamente
    if (method == "PUT" && !location->isMethodAllowed("PUT"))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }
}
```

**INVESTIGACIÓN ADICIONAL NECESARIA:**

Necesito ver cómo funciona `isMethodAllowed()` en LocationConfig.cpp:

---

## PROBLEMA 2: PUT no está implementado (devuelve 501)

### Diagnóstico
```
Request: PUT /put_test/testfile.txt
Expected: 200 or 201 (Created)
Actual:   501 (Not Implemented)
```

### Causa Raíz

**Server.cpp líneas 740-748:**
```cpp
// Route by method
if (method == "GET" || method == "HEAD")
    _handleGet(client, location);
else if (method == "POST")
    _handlePost(client, location);
else if (method == "DELETE")
    _handleDelete(client, location);
else
    _sendErrorResponse(client, HTTP_NOT_IMPLEMENTED);  // ← AQUÍ ESTÁ EL PROBLEMA
```

PUT no está implementado. Cuando llega un request con PUT, cae en el `else` y devuelve 501.

### Solución

Necesitas implementar el método PUT. Aquí está la implementación completa:

**1. Añadir la declaración en Server.hpp:**
```cpp
void    _handlePut(Client& client, const LocationConfig* location);
```

**2. Implementar _handlePut en Server.cpp:**

```cpp
void Server::_handlePut(Client& client, const LocationConfig* location)
{
    const Request& request = client.getRequest();
    const ServerConfig* serverConfig = client.getServerConfig();
    
    // Resolver el path del archivo
    std::string filePath = _resolvePath(request, location, serverConfig);
    
    // Verificar que no sea un directorio
    struct stat fileStat;
    if (stat(filePath.c_str(), &fileStat) == 0 && S_ISDIR(fileStat.st_mode))
    {
        _sendErrorResponse(client, HTTP_FORBIDDEN);
        return;
    }
    
    // Determinar si el archivo existe (para status code 200 vs 201)
    bool fileExists = (access(filePath.c_str(), F_OK) == 0);
    
    // Crear directorios padre si no existen
    size_t lastSlash = filePath.rfind('/');
    if (lastSlash != std::string::npos)
    {
        std::string directory = filePath.substr(0, lastSlash);
        if (!directory.empty())
        {
            // Crear directorio recursivamente si no existe
            std::string cmd = "mkdir -p " + directory;
            system(cmd.c_str());
        }
    }
    
    // Escribir el contenido del body al archivo
    std::ofstream file(filePath.c_str(), std::ios::binary | std::ios::trunc);
    if (!file.is_open())
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }
    
    const std::string& body = request.getBody();
    file.write(body.c_str(), body.length());
    file.close();
    
    if (file.fail())
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }
    
    // Devolver 201 si el archivo fue creado, 200 si fue modificado
    Response resp;
    resp.setStatusCode(fileExists ? HTTP_OK : HTTP_CREATED);
    resp.setHeader("Content-Length", "0");
    std::string response = resp.build();
    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}
```

**3. Modificar el routing en handleRequest (Server.cpp líneas 740-750):**

```cpp
// Route by method
if (method == "GET" || method == "HEAD")
    _handleGet(client, location);
else if (method == "POST")
    _handlePost(client, location);
else if (method == "DELETE")
    _handleDelete(client, location);
else if (method == "PUT")                           // ← AÑADIR ESTO
    _handlePut(client, location);                   // ← AÑADIR ESTO
else
    _sendErrorResponse(client, HTTP_NOT_IMPLEMENTED);
```

---

## PROBLEMA 3: POST /post_body devuelve 405 en lugar de 200/204

### Diagnóstico
```
Request: POST /post_body (small body)
Expected: 200 or 204
Actual:   405 (Method Not Allowed)

Request: POST /post_body (large body >100)
Expected: 413 (Payload Too Large)
Actual:   405 (Method Not Allowed)
```

### Análisis

La configuración en `config/webserv.conf` líneas 61-64 dice:
```nginx
location /post_body {
    methods POST GET;
    client_max_body_size 100;
}
```

Esto está correcto. POST SÍ está permitido.

### Causa Raíz Posible

**HIPÓTESIS 1**: El matching de location no está funcionando correctamente.
- El servidor podría estar matcheando `/post_body` con otra location (por ejemplo, `/`)
- La location `/` solo permite GET, por eso devuelve 405

**HIPÓTESIS 2**: El orden de las locations en la configuración está causando el problema.

### Solución

**Verificar el algoritmo de matching de locations:**

En `Server.cpp`, necesitas asegurarte de que el matching de locations se hace del más específico al menos específico.

El orden correcto de búsqueda debería ser:
1. Exact match: `/post_body` → match
2. Longest prefix: `/post` → no match
3. Root: `/` → fallback

**CÓDIGO A VERIFICAR:**

Busca la función que hace el matching de locations (probablemente algo como `_findLocation` o `_matchLocation`).

**DEBUG TEMPORAL:**

Añade logging en `handleRequest()` para ver qué location se está usando:

```cpp
std::cout << "[DEBUG] Request path: " << request.getPath() << std::endl;
std::cout << "[DEBUG] Matched location: " << (location ? location->getPath() : "NULL") << std::endl;
if (location)
{
    std::cout << "[DEBUG] Allowed methods: ";
    const std::vector<std::string>& methods = location->getMethods();
    for (size_t i = 0; i < methods.size(); i++)
        std::cout << methods[i] << " ";
    std::cout << std::endl;
}
```

---

## PROBLEMA 4: CGI .bla files devuelven 500

### Diagnóstico
```
Request: POST /directory/youpi.bla
Expected: 200 (CGI ejecutado correctamente)
Actual:   500 (Internal Server Error)
```

### Causas Posibles

1. El ejecutable `./testers/ubuntu_cgi_tester` no existe o no tiene permisos de ejecución
2. El CGI no está recibiendo las variables de entorno correctas
3. El CGI está fallando al ejecutarse
4. Los pipes de comunicación con el CGI están fallando

### Verificación

```bash
# Verificar que el tester existe y tiene permisos
ls -la ./testers/ubuntu_cgi_tester

# Probar ejecutarlo manualmente
./testers/ubuntu_cgi_tester
```

### Solución

**Verificar en `_handleCgi()` (Server.cpp línea 955+):**

1. Añadir logging para debug:
```cpp
std::cout << "[DEBUG] CGI path: " << cgiPath << std::endl;
std::cout << "[DEBUG] Script path: " << filePath << std::endl;
std::cout << "[DEBUG] Extension: " << extension << std::endl;
```

2. Verificar que las variables de entorno CGI están correctas:
   - REQUEST_METHOD
   - CONTENT_LENGTH
   - CONTENT_TYPE
   - QUERY_STRING
   - PATH_INFO
   - SCRIPT_NAME

3. Verificar el manejo de errores en el fork() y exec():
```cpp
if (pid == 0)  // Child process
{
    // Setup environment
    char* envp[] = {
        strdup(("REQUEST_METHOD=" + request.getMethod()).c_str()),
        strdup(("CONTENT_LENGTH=" + Utils::toString(request.getContentLength())).c_str()),
        // ... más variables
        NULL
    };
    
    // Redirect stdin/stdout
    dup2(pipeIn[0], STDIN_FILENO);
    dup2(pipeOut[1], STDOUT_FILENO);
    
    // Close unused pipe ends
    close(pipeIn[0]);
    close(pipeIn[1]);
    close(pipeOut[0]);
    close(pipeOut[1]);
    
    // Execute CGI
    char* argv[] = { (char*)cgiPath.c_str(), (char*)filePath.c_str(), NULL };
    execve(cgiPath.c_str(), argv, envp);
    
    // If execve fails
    std::cerr << "[ERROR] CGI execve failed: " << strerror(errno) << std::endl;
    exit(1);
}
```

---

## PROBLEMA 5: Benchmark Test - Connection Refused

### Diagnóstico
```
[error] socket: unable to connect sock.c:282: Connection refused
[error] descriptor table full sock.c:402: Too many open files
```

### Causa Raíz

El servidor está crasheando o agotando file descriptors bajo carga alta (50 conexiones concurrentes durante 30 segundos).

### Causas Posibles

1. **File descriptor leak**: El servidor no está cerrando conexiones correctamente
2. **Límite de sistema**: El límite de file descriptors es muy bajo
3. **Backlog de conexiones**: El backlog de listen() es insuficiente
4. **Resource exhaustion**: El servidor se queda sin memoria o recursos

### Solución

**1. Verificar límites del sistema:**
```bash
ulimit -n  # Ver límite actual de file descriptors
ulimit -n 4096  # Aumentar límite
```

**2. Verificar que las conexiones se cierran correctamente:**

En `Server.cpp`, busca donde se manejan las conexiones y asegúrate de que siempre se cierran:

```cpp
// En _closeConnection o similar
if (client.getFd() >= 0)
{
    close(client.getFd());
    client.setFd(-1);
}
```

**3. Mejorar el manejo de errores en accept():**
```cpp
int clientFd = accept(serverFd, (struct sockaddr*)&clientAddr, &addrLen);
if (clientFd < 0)
{
    if (errno == EMFILE || errno == ENFILE)
    {
        // Too many open files - close some idle connections
        _closeIdleConnections();
        continue;
    }
    std::cerr << "[ERROR] accept() failed: " << strerror(errno) << std::endl;
    continue;
}
```

**4. Implementar timeout de conexiones:**

Asegúrate de que `CONNECTION_TIMEOUT` (60 segundos) se está aplicando y las conexiones inactivas se cierran.

**5. Aumentar BACKLOG:**

En `webserv.hpp` línea 68:
```cpp
# define BACKLOG 128  // Ya está configurado, pero puede aumentarse a 256 o 512
```

---

## PROBLEMA 6: Test Suite - Server Already Running

### Diagnóstico
```
[ERROR] bind() failed on port 8080: Address already in use
[ERROR] Failed to create socket on 0.0.0.0:8080
[ERROR] Failed to initialize server
```

### Causa
El script intenta iniciar el servidor cuando ya está corriendo.

### Solución

**Modificar `tests/test_suite.sh` líneas 127-144:**

```bash
start_server() {
    local config=${1:-$CONFIG}
    
    # Verificar si el servidor ya está corriendo
    if nc -z localhost $PORT 2>/dev/null; then
        log_info "Server already running on port $PORT, using existing instance"
        SERVER_PID=""  # No tenemos el PID pero está corriendo
        return 0
    fi
    
    # Si ya tenemos un PID, no iniciar otro
    if [ -n "$SERVER_PID" ]; then
        return 0
    fi
    
    # Iniciar servidor en background
    "$WEBSERV" "$config" &
    SERVER_PID=$!
    
    # Esperar a que el servidor esté listo
    if ! wait_for_server $PORT 10; then
        echo -e "  ${RED}❌ FAIL:${NC} Server failed to start"
        kill "$SERVER_PID" 2>/dev/null || true
        SERVER_PID=""
        return 1
    fi
    
    log_info "Server started with PID $SERVER_PID"
    return 0
}
```

**Modificar `stop_server()` líneas 146-154:**

```bash
stop_server() {
    # Si no tenemos el PID, intentar encontrarlo
    if [ -z "$SERVER_PID" ]; then
        # Buscar el proceso webserv
        SERVER_PID=$(pgrep -f "bin/webserv" | head -1)
    fi
    
    if [ -n "$SERVER_PID" ]; then
        log_info "Stopping server (PID $SERVER_PID)..."
        kill "$SERVER_PID" 2>/dev/null || true
        wait "$SERVER_PID" 2>/dev/null || true
        SERVER_PID=""
    fi
    
    # Cleanup adicional por si hay procesos huérfanos
    pkill -f "./bin/webserv" 2>/dev/null || true
    pkill -f "bin/webserv" 2>/dev/null || true
    
    # Esperar un momento para que el puerto se libere
    sleep 1
}
```

---

## PROBLEMA 7: 42 Tester - "FATAL ERROR ON LAST TEST: bad status code"

### Diagnóstico

El tester oficial de 42 falla inmediatamente con "bad status code" al hacer `GET /`.

### Debug

Según los logs del servidor:
```
[DEBUG] New connection from 172.17.0.1 on fd 6
[DEBUG] Closing connection fd 6
```

La conexión se abre y cierra inmediatamente sin procesar la request.

### Causas Posibles

1. **El servidor cierra la conexión antes de leer la request**
2. **El servidor no está enviando respuesta HTTP válida**
3. **El tester espera un formato específico de respuesta**

### Solución

**Verificar en el código del servidor:**

1. **Asegurarse de que se lee la request completa antes de cerrar:**

```cpp
// En el main loop del servidor
if (fds[i].revents & POLLIN)
{
    // Leer datos
    char buffer[BUFFER_SIZE];
    ssize_t bytesRead = recv(fd, buffer, sizeof(buffer) - 1, 0);
    
    if (bytesRead <= 0)
    {
        if (bytesRead == 0)
            std::cout << "[DEBUG] Client disconnected on fd " << fd << std::endl;
        else
            std::cerr << "[ERROR] recv() failed: " << strerror(errno) << std::endl;
        _closeConnection(fd);
        continue;
    }
    
    buffer[bytesRead] = '\0';
    client.appendToReadBuffer(buffer, bytesRead);
    
    // Procesar request solo cuando está completa
    if (client.isRequestComplete())
    {
        _handleRequest(client);
    }
}
```

2. **Verificar el formato de la respuesta HTTP:**

En `Response.cpp`, asegúrate de que la respuesta tiene este formato exacto:

```
HTTP/1.1 200 OK\r\n
Content-Type: text/html\r\n
Content-Length: 123\r\n
\r\n
<html>...</html>
```

**NO DEBE HABER:**
- Espacios extra
- Headers en minúsculas (deben ser `Content-Type`, no `content-type`)
- Falta de `\r\n\r\n` antes del body
- Body sin Content-Length correcto

3. **Log de debug para ver qué se está enviando:**

```cpp
void Server::_sendResponse(Client& client, const std::string& response)
{
    std::cout << "[DEBUG] Sending response to fd " << client.getFd() << ":" << std::endl;
    std::cout << response.substr(0, 200) << "..." << std::endl;  // Primeros 200 chars
    
    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}
```

---

## RESUMEN DE CORRECCIONES NECESARIAS

### Archivos a Modificar

1. **src/Server.cpp**
   - ✅ Implementar método `_handlePut()`
   - ✅ Añadir routing para PUT
   - ✅ Mejorar verificación de métodos permitidos
   - ✅ Añadir debug logging
   - ✅ Mejorar manejo de file descriptors

2. **inc/Server.hpp**
   - ✅ Añadir declaración de `_handlePut()`

3. **tests/test_suite.sh**
   - ✅ Mejorar `start_server()` para detectar servidor corriendo
   - ✅ Mejorar `stop_server()` para cleanup robusto

4. **tests/benchmark_tests.sh**
   - ✅ Añadir verificación de límites del sistema
   - ✅ Mejorar manejo de errores

5. **Verificar configuración**
   - ✅ Asegurar que el matching de locations funciona correctamente
   - ✅ Verificar permisos del CGI tester

---

## PLAN DE ACCIÓN

### Paso 1: Implementar PUT
**Prioridad: ALTA** - Requerido para 42 tester

1. Añadir `_handlePut()` en Server.cpp
2. Actualizar routing en `handleRequest()`
3. Compilar y probar

### Paso 2: Corregir DELETE /
**Prioridad: ALTA** - Requerido para 42 tester

1. Investigar por qué DELETE llega a `_handleDelete()` cuando no debería
2. Mejorar verificación de métodos permitidos
3. Añadir logs de debug

### Paso 3: Corregir POST /post_body
**Prioridad: ALTA** - Requerido para 42 tester

1. Debug del location matching
2. Verificar que `/post_body` se matchea correctamente
3. Añadir logs

### Paso 4: Corregir CGI .bla
**Prioridad: MEDIA** - Requerido para 42 tester

1. Verificar permisos del cgi_tester
2. Debug de variables de entorno
3. Mejorar error handling

### Paso 5: Corregir Benchmark
**Prioridad: MEDIA** - Performance

1. Fix file descriptor leaks
2. Aumentar límites del sistema
3. Mejorar timeout handling

### Paso 6: Mejorar Test Scripts
**Prioridad: BAJA** - Quality of life

1. Modificar start_server()
2. Modificar stop_server()
3. Añadir más checks

---

## TESTING DESPUÉS DE CORRECCIONES

### Test Individual de PUT
```bash
curl -X PUT -d "test content" http://localhost:8080/put_test/testfile.txt
# Expected: 201 Created (si el archivo no existía) o 200 OK (si existía)
```

### Test Individual de DELETE /
```bash
curl -X DELETE http://localhost:8080/
# Expected: 405 Method Not Allowed
```

### Test Individual de POST /post_body
```bash
# Small body
curl -X POST -d "small" http://localhost:8080/post_body
# Expected: 200 OK or 204 No Content

# Large body (>100 bytes)
curl -X POST -d "$(printf 'A%.0s' {1..150})" http://localhost:8080/post_body
# Expected: 413 Payload Too Large
```

### Test Individual de CGI .bla
```bash
curl -X POST http://localhost:8080/directory/youpi.bla
# Expected: 200 OK con output del CGI
```

### Test Completo
```bash
# Compilar
make re

# Iniciar servidor
./bin/webserv config/webserv.conf &

# Esperar a que arranque
sleep 2

# Ejecutar diagnóstico
bash tests/diagnose_42_tester.sh

# Ejecutar suite completa
bash tests/test_suite.sh

# Ejecutar 42 tester
./testers/ubuntu_tester http://localhost:8080

# Detener servidor
pkill webserv
```
