/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Server.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcela-ga <fcela-ga@student.42barcelona.co  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/01 00:00:00 by fcela-ga          #+#    #+#             */
/*   Updated: 2024/01/01 00:00:00 by fcela-ga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Server.hpp"
#include "webserv.hpp"
#include "Utils.hpp"
#include "MimeTypes.hpp"
#include "SessionManager.hpp"
#include "Response.hpp"
#include "CGIHandler.hpp"

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <limits.h>
#include <fcntl.h>
#include <poll.h>
#include <csignal>
#include <cerrno>
#include <cstring>
#include <cstdio>
#include <dirent.h>
#include <fstream>
#include <algorithm>

// Global running flag for signal handling
static volatile sig_atomic_t g_serverRunning = 1;

// ============================================================================
// Signal handler
// ============================================================================

void Server::_signalHandler(int sig)
{
    (void)sig;
    g_serverRunning = 0;
}

// ============================================================================
// Constructors / Destructor
// ============================================================================

Server::Server() : _running(false)
{
}

Server::Server(const Config& config) : _config(config), _running(false)
{
}

Server::Server(const Server& other)
{
    *this = other;
}

Server& Server::operator=(const Server& other)
{
    if (this != &other)
    {
        _config = other._config;
        _running = false;
        // Note: we don't copy active connections/sockets
    }
    return *this;
}

Server::~Server()
{
    _closeAllSockets();
}

// ============================================================================
// Initialization
// ============================================================================

bool Server::init()
{
    // Setup signal handlers
    struct sigaction sa;
    std::memset(&sa, 0, sizeof(sa));
    sa.sa_handler = _signalHandler;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);

    return _createListenSockets();
}

bool Server::init(const Config& config)
{
    _config = config;
    return init();
}

bool Server::_createListenSockets()
{
    const std::vector<ServerConfig>& servers = _config.getServers();
    
    if (servers.empty())
    {
        Utils::logError("No servers configured");
        return false;
    }

    std::set<std::pair<std::string, int> > createdSockets;

    for (size_t i = 0; i < servers.size(); ++i)
    {
        const ServerConfig& serverConf = servers[i];
        std::string host = serverConf.getHost();
        int port = serverConf.getPort();

        std::pair<std::string, int> hostPort(host, port);
        
        // Skip if already created
        if (createdSockets.find(hostPort) != createdSockets.end())
            continue;

        int fd = _createSocket(host, port);
        if (fd < 0)
        {
            Utils::logError("Failed to create socket on " + host + ":" + Utils::intToString(port));
            _closeAllSockets();
            return false;
        }

        _listenSockets[fd] = port;
        createdSockets.insert(hostPort);

        Utils::logInfo("Listening on " + host + ":" + Utils::intToString(port));
    }

    if (_listenSockets.empty())
    {
        Utils::logError("No listening sockets created");
        return false;
    }

    return true;
}

int Server::_createSocket(const std::string& host, int port)
{
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        Utils::logError("socket() failed: " + std::string(std::strerror(errno)));
        return -1;
    }

    // Set socket options
    int opt = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
    {
        Utils::logError("setsockopt(SO_REUSEADDR) failed");
        close(sockfd);
        return -1;
    }

    // Set non-blocking
    if (!_setNonBlocking(sockfd))
    {
        close(sockfd);
        return -1;
    }

    // Bind
    struct sockaddr_in addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    
    if (host.empty() || host == "0.0.0.0" || host == "*")
        addr.sin_addr.s_addr = INADDR_ANY;
    else
        addr.sin_addr.s_addr = inet_addr(host.c_str());

    if (bind(sockfd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0)
    {
        Utils::logError("bind() failed on port " + Utils::intToString(port) + ": " + std::strerror(errno));
        close(sockfd);
        return -1;
    }

    // Listen
    if (listen(sockfd, BACKLOG) < 0)
    {
        Utils::logError("listen() failed");
        close(sockfd);
        return -1;
    }

    return sockfd;
}

bool Server::_setNonBlocking(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0)
        return false;
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK) >= 0;
}

void Server::_closeAllSockets()
{
    // Close listen sockets
    for (std::map<int, int>::iterator it = _listenSockets.begin(); 
         it != _listenSockets.end(); ++it)
    {
        close(it->first);
    }
    _listenSockets.clear();

    // Close client sockets
    for (std::map<int, Client>::iterator it = _clients.begin();
         it != _clients.end(); ++it)
    {
        close(it->first);
    }
    _clients.clear();

    // Close CGI pipes
    for (std::map<int, int>::iterator it = _cgiToClient.begin();
         it != _cgiToClient.end(); ++it)
    {
        close(it->first);
    }
    _cgiToClient.clear();

    _pollFds.clear();
}

// ============================================================================
// Poll management
// ============================================================================

void Server::_rebuildPollFds()
{
    _pollFds.clear();

    // Add listen sockets
    for (std::map<int, int>::iterator it = _listenSockets.begin();
         it != _listenSockets.end(); ++it)
    {
        struct pollfd pfd;
        pfd.fd = it->first;
        pfd.events = POLLIN;
        pfd.revents = 0;
        _pollFds.push_back(pfd);
    }

    // Add client sockets
    for (std::map<int, Client>::iterator it = _clients.begin();
         it != _clients.end(); ++it)
    {
        struct pollfd pfd;
        pfd.fd = it->first;
        pfd.events = 0;

        Client& client = it->second;
        ClientState state = client.getState();
        
        if (state == CLIENT_READING || state == CLIENT_PROCESSING)
        {
            pfd.events |= POLLIN;
        }
        if (state == CLIENT_WRITING || client.getWriteBufferSize() > 0)
        {
            pfd.events |= POLLOUT;
        }

        pfd.revents = 0;
        _pollFds.push_back(pfd);
    }

    // Add CGI pipes
    for (std::map<int, int>::iterator it = _cgiToClient.begin();
         it != _cgiToClient.end(); ++it)
    {
        struct pollfd pfd;
        pfd.fd = it->first;
        pfd.events = POLLIN;
        pfd.revents = 0;
        _pollFds.push_back(pfd);
    }
}

void Server::_addToPoll(int fd, short events)
{
    struct pollfd pfd;
    pfd.fd = fd;
    pfd.events = events;
    pfd.revents = 0;
    _pollFds.push_back(pfd);
}

void Server::_removeFromPoll(int fd)
{
    for (size_t i = 0; i < _pollFds.size(); ++i)
    {
        if (_pollFds[i].fd == fd)
        {
            _pollFds.erase(_pollFds.begin() + i);
            return;
        }
    }
}

void Server::_setEvents(int fd, short events)
{
    for (size_t i = 0; i < _pollFds.size(); ++i)
    {
        if (_pollFds[i].fd == fd)
        {
            _pollFds[i].events = events;
            return;
        }
    }
}

// ============================================================================
// Main loop
// ============================================================================

void Server::run()
{
    _running = true;
    g_serverRunning = 1;
    
    time_t lastCleanup = std::time(NULL);

    Utils::logInfo("Server started, entering main loop");

    while (_running && g_serverRunning)
    {
        _rebuildPollFds();

        if (_pollFds.empty())
        {
            Utils::logError("No file descriptors to poll");
            break;
        }

        int pollResult = poll(&_pollFds[0], _pollFds.size(), 1000);

        if (pollResult < 0)
        {
            if (errno == EINTR)
                continue;
            Utils::logError("poll() failed: " + std::string(std::strerror(errno)));
            break;
        }

        if (pollResult == 0)
        {
            _checkTimeouts();
            continue;
        }

        // Process events
        for (size_t i = 0; i < _pollFds.size() && pollResult > 0; ++i)
        {
            if (_pollFds[i].revents == 0)
                continue;
            
            --pollResult;
            int fd = _pollFds[i].fd;
            short revents = _pollFds[i].revents;

            // Check for errors
            if (revents & (POLLERR | POLLHUP | POLLNVAL))
            {
                if (_listenSockets.find(fd) != _listenSockets.end())
                {
                    Utils::logError("Error on listen socket");
                    continue;
                }
                else if (_clients.find(fd) != _clients.end())
                {
                    _closeClient(fd);
                    continue;
                }
                else if (_cgiToClient.find(fd) != _cgiToClient.end())
                {
                    _handleCgiRead(fd);
                    continue;
                }
            }

            // Handle listen socket
            if (_listenSockets.find(fd) != _listenSockets.end())
            {
                if (revents & POLLIN)
                    _acceptNewConnection(fd);
            }
            // Handle CGI pipe
            else if (_cgiToClient.find(fd) != _cgiToClient.end())
            {
                if (revents & POLLIN)
                    _handleCgiRead(fd);
            }
            // Handle client socket
            else if (_clients.find(fd) != _clients.end())
            {
                if (revents & POLLIN)
                    _handleClientRead(fd);
                if (revents & POLLOUT)
                    _handleClientWrite(fd);
            }
        }

        _checkTimeouts();

        // Periodic session cleanup
        time_t now = std::time(NULL);
        if (now - lastCleanup >= 60)
        {
            SessionManager::getInstance().cleanExpiredSessions();
            lastCleanup = now;
        }
    }

    Utils::logInfo("Server shutting down");
    _closeAllSockets();
    _running = false;
}

void Server::stop()
{
    _running = false;
    g_serverRunning = 0;
}

bool Server::isRunning() const
{
    return _running;
}

size_t Server::getClientCount() const
{
    return _clients.size();
}

const Config& Server::getConfig() const
{
    return _config;
}

// ============================================================================
// Connection handling
// ============================================================================

void Server::_acceptNewConnection(int listenFd)
{
    struct sockaddr_in clientAddr;
    socklen_t clientLen = sizeof(clientAddr);

    int clientFd = accept(listenFd, reinterpret_cast<struct sockaddr*>(&clientAddr), &clientLen);
    
    if (clientFd < 0)
    {
        if (errno != EAGAIN && errno != EWOULDBLOCK)
            Utils::logError("accept() failed: " + std::string(std::strerror(errno)));
        return;
    }

    // Check client limit
    if (_clients.size() >= MAX_CLIENTS)
    {
        Utils::logWarning("Maximum clients reached, rejecting connection");
        close(clientFd);
        return;
    }

    // Set non-blocking
    if (!_setNonBlocking(clientFd))
    {
        close(clientFd);
        return;
    }

    // Create client
    std::string clientIp = inet_ntoa(clientAddr.sin_addr);
    int clientPort = _listenSockets[listenFd];
    Client client(clientFd, clientIp, clientPort);
    
    _clients[clientFd] = client;

    Utils::logDebug("New connection from " + clientIp + 
                    " on fd " + Utils::intToString(clientFd));
}

void Server::_handleClientRead(int clientFd)
{
    std::map<int, Client>::iterator it = _clients.find(clientFd);
    if (it == _clients.end())
        return;

    Client& client = it->second;

    char buffer[BUFFER_SIZE];
    ssize_t bytesRead = recv(clientFd, buffer, sizeof(buffer), 0);

    if (bytesRead <= 0)
    {
        if (bytesRead < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
            return;
        _closeClient(clientFd);
        return;
    }

    client.appendToReadBuffer(buffer, bytesRead);
    client.updateLastActivity();

    // Try to parse request
    Request& request = client.getRequest();
    request.parse(client.getReadBuffer());

    // Check for parse errors FIRST (e.g., invalid method returns 501)
    if (request.hasError())
    {
        client.clearReadBuffer();
        _sendErrorResponse(client, request.getErrorCode());
        return;
    }

    // Check if request is complete
    if (request.isComplete())
    {
        client.clearReadBuffer();
        client.setState(CLIENT_PROCESSING);
        _processRequest(client);
    }
    // else: need more data, keep buffer for next read
}

void Server::_handleClientWrite(int clientFd)
{
    std::map<int, Client>::iterator it = _clients.find(clientFd);
    if (it == _clients.end())
        return;

    Client& client = it->second;

    if (client.getWriteBufferSize() == 0)
    {
        // Check if we should close or keep alive
        if (!client.shouldKeepAlive())
        {
            _closeClient(clientFd);
        }
        else
        {
            client.reset();
        }
        return;
    }

    std::string& buffer = client.getWriteBuffer();
    ssize_t sent = send(clientFd, buffer.c_str(), buffer.size(), 0);

    if (sent < 0)
    {
        if (errno != EAGAIN && errno != EWOULDBLOCK)
            _closeClient(clientFd);
        return;
    }

    client.eraseFromWriteBuffer(sent);
    client.updateLastActivity();

    if (client.getWriteBufferSize() == 0)
    {
        if (!client.shouldKeepAlive())
            _closeClient(clientFd);
        else
            client.reset();
    }
}

void Server::_handleCgiRead(int cgiFd)
{
    std::map<int, int>::iterator it = _cgiToClient.find(cgiFd);
    if (it == _cgiToClient.end())
        return;

    int clientFd = it->second;
    std::map<int, Client>::iterator clientIt = _clients.find(clientFd);
    if (clientIt == _clients.end())
    {
        close(cgiFd);
        _cgiToClient.erase(it);
        return;
    }

    Client& client = clientIt->second;

    char buffer[BUFFER_SIZE];
    ssize_t bytesRead = read(cgiFd, buffer, sizeof(buffer));

    Utils::logDebug("CGI read: " + Utils::intToString(bytesRead) + " bytes");

    if (bytesRead > 0)
    {
        client.appendCgiOutput(std::string(buffer, bytesRead));
        Utils::logDebug("CGI output accumulated: " + Utils::intToString(client.getCgiOutput().size()) + " bytes");
    }
    else
    {
        // CGI finished or error
        Utils::logDebug("CGI finished, total output: " + Utils::intToString(client.getCgiOutput().size()) + " bytes");
        
        close(cgiFd);
        _cgiToClient.erase(it);

        // Wait for CGI process
        pid_t pid = client.getCgiPid();
        if (pid > 0)
        {
            int status;
            waitpid(pid, &status, 0);
            Utils::logDebug("CGI process exited with status: " + Utils::intToString(WEXITSTATUS(status)));
        }

        // Prepare response from CGI output
        _prepareCgiResponse(client);
    }
}

void Server::_closeClient(int clientFd)
{
    std::map<int, Client>::iterator it = _clients.find(clientFd);
    if (it == _clients.end())
        return;

    Client& client = it->second;
    
    // Clean up CGI if any
    int cgiFdOut = client.getCgiFdOut();
    if (cgiFdOut >= 0)
    {
        close(cgiFdOut);
        _cgiToClient.erase(cgiFdOut);
    }

    pid_t pid = client.getCgiPid();
    if (pid > 0)
    {
        kill(pid, SIGTERM);
        waitpid(pid, NULL, WNOHANG);
    }

    Utils::logDebug("Closing connection fd " + Utils::intToString(clientFd));
    close(clientFd);
    _clients.erase(clientFd);
}

void Server::_checkTimeouts()
{
    std::vector<int> toClose;

    for (std::map<int, Client>::iterator it = _clients.begin();
         it != _clients.end(); ++it)
    {
        Client& client = it->second;
        
        if (client.hasTimedOut(CONNECTION_TIMEOUT))
        {
            toClose.push_back(it->first);
        }
        else if (client.getState() == CLIENT_CGI_RUNNING && 
                 client.hasCgiTimedOut(CGI_TIMEOUT))
        {
            toClose.push_back(it->first);
        }
    }

    for (size_t i = 0; i < toClose.size(); ++i)
    {
        Utils::logDebug("Client timeout on fd " + Utils::intToString(toClose[i]));
        _closeClient(toClose[i]);
    }
}

// ============================================================================
// Request processing
// ============================================================================

void Server::_processRequest(Client& client)
{
    const Request& request = client.getRequest();
    
    Utils::logInfo(request.getMethod() + " " + request.getUri() + " from " + client.getIp());

    // Select server configuration
    const ServerConfig* serverConfig = _selectServer(client);
    if (serverConfig == NULL)
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    client.setServerConfig(serverConfig);

    // Find matching location
    const LocationConfig* location = serverConfig->findLocation(request.getPath());

    // Check if redirect
    if (location != NULL && location->hasRedirect())
    {
        _handleRedirect(client, location);
        return;
    }

    // Check method allowed
    const std::string& method = request.getMethod();
	// HEAD should be allowed wherever GET is allowed (HTTP/1.1 spec)
	std::string methodToCheck = method;
	if (method == "HEAD")
		methodToCheck = "GET";
	if (location != NULL && !location->isMethodAllowed(methodToCheck))
    {
        _sendErrorResponse(client, HTTP_METHOD_NOT_ALLOWED);
        return;
    }

    // Check body size - use location's limit if defined, otherwise server's limit
    size_t maxBodySize = serverConfig->getMaxBodySize();
    if (location != NULL && location->getMaxBodySize() > 0)
        maxBodySize = location->getMaxBodySize();
    
    if (request.getContentLength() > maxBodySize)
    {
        _sendErrorResponse(client, HTTP_PAYLOAD_TOO_LARGE);
        return;
    }

    // Route by method
    if (method == "GET" || method == "HEAD")
        _handleGet(client, location);
    else if (method == "POST")
        _handlePost(client, location);
    else if (method == "PUT")
        _handlePut(client, location);
    else if (method == "DELETE")
        _handleDelete(client, location);
    else
        _sendErrorResponse(client, HTTP_NOT_IMPLEMENTED);
}

const ServerConfig* Server::_selectServer(const Client& client)
{
    const Request& request = client.getRequest();
    std::string host = request.getHost();
    int port = client.getPort();

    const std::vector<ServerConfig>& servers = _config.getServers();
    const ServerConfig* defaultServer = NULL;

    for (size_t i = 0; i < servers.size(); ++i)
    {
        const ServerConfig& server = servers[i];
        
        if (server.getPort() != port)
            continue;

        if (defaultServer == NULL)
            defaultServer = &server;

        // Check server names
        const std::vector<std::string>& names = server.getServerNames();
        for (size_t j = 0; j < names.size(); ++j)
        {
            if (names[j] == host)
                return &server;
        }
    }

    return defaultServer;
}

// ============================================================================
// Response handlers
// ============================================================================

void Server::_handleGet(Client& client, const LocationConfig* location)
{
    const Request& request = client.getRequest();
    const ServerConfig* serverConfig = client.getServerConfig();
    
    std::string filePath = _resolvePath(request, location, serverConfig);

    // Check if CGI
    if (location != NULL && _isCgiRequest(filePath, location))
    {
        _handleCgi(client, location, filePath);
        return;
    }

    struct stat fileStat;
    if (stat(filePath.c_str(), &fileStat) < 0)
    {
        _sendErrorResponse(client, HTTP_NOT_FOUND);
        return;
    }

    // Directory handling
    if (S_ISDIR(fileStat.st_mode))
    {
        // Try index files
        std::vector<std::string> indexFiles;
        if (location != NULL && !location->getIndex().empty())
            indexFiles.push_back(location->getIndex());
        if (indexFiles.empty() && serverConfig != NULL && !serverConfig->getIndex().empty())
            indexFiles.push_back(serverConfig->getIndex());
        if (indexFiles.empty())
            indexFiles.push_back("index.html");

        bool indexFound = false;
        for (size_t i = 0; i < indexFiles.size(); ++i)
        {
            std::string indexPath = filePath;
            if (indexPath[indexPath.length() - 1] != '/')
                indexPath += '/';
            indexPath += indexFiles[i];

            if (stat(indexPath.c_str(), &fileStat) == 0 && S_ISREG(fileStat.st_mode))
            {
                filePath = indexPath;
                indexFound = true;
                break;
            }
        }

        if (!indexFound)
        {
            // Check autoindex
            bool autoindex = (location != NULL) ? location->getAutoindex() : false;
            if (autoindex)
            {
                _handleDirectoryListing(client, filePath, request.getPath());
                return;
            }
            else
            {
                _sendErrorResponse(client, HTTP_FORBIDDEN);
                return;
            }
        }
    }

    // Check file exists and is readable
    if (stat(filePath.c_str(), &fileStat) < 0 || !S_ISREG(fileStat.st_mode))
    {
        _sendErrorResponse(client, HTTP_NOT_FOUND);
        return;
    }

    if (access(filePath.c_str(), R_OK) < 0)
    {
        _sendErrorResponse(client, HTTP_FORBIDDEN);
        return;
    }

    // Read file
    std::ifstream file(filePath.c_str(), std::ios::binary);
    if (!file)
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    std::string content((std::istreambuf_iterator<char>(file)),
                        std::istreambuf_iterator<char>());
    file.close();

    // Build response
    std::string mimeType = MimeTypes::getInstance().getMimeTypeByFile(filePath);
    Response resp;
    resp.setStatusCode(HTTP_OK);
    resp.setContentType(mimeType);
    resp.setBody(content);
    std::string response = resp.build();

    // For HEAD, remove body
    if (request.getMethod() == "HEAD")
    {
        size_t headerEnd = response.find("\r\n\r\n");
        if (headerEnd != std::string::npos)
            response = response.substr(0, headerEnd + 4);
    }

    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}

void Server::_handlePost(Client& client, const LocationConfig* location)
{
    const Request& request = client.getRequest();
    const ServerConfig* serverConfig = client.getServerConfig();
    
    std::string filePath = _resolvePath(request, location, serverConfig);

    // Check if CGI
    if (location != NULL && _isCgiRequest(filePath, location))
    {
        _handleCgi(client, location, filePath);
        return;
    }

    // Handle file upload
    if (location != NULL && location->getUploadEnabled())
    {
        _handleFileUpload(client, location);
        return;
    }

    // If POST is allowed but no specific handler, return 204 No Content
    // This allows testing POST requests without requiring CGI or upload
    Response resp;
    resp.setStatusCode(HTTP_NO_CONTENT);
    std::string response = resp.build();
    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}

void Server::_handlePut(Client& client, const LocationConfig* location)
{
    const Request& request = client.getRequest();
    const ServerConfig* serverConfig = client.getServerConfig();
    
    // Resolve file path
    std::string filePath = _resolvePath(request, location, serverConfig);
    
    // Check if path is a directory
    struct stat fileStat;
    if (stat(filePath.c_str(), &fileStat) == 0 && S_ISDIR(fileStat.st_mode))
    {
        _sendErrorResponse(client, HTTP_FORBIDDEN);
        return;
    }
    
    // Determine if file exists (for status code 200 vs 201)
    bool fileExists = (access(filePath.c_str(), F_OK) == 0);
    
    // Create parent directories if they don't exist
    size_t lastSlash = filePath.rfind('/');
    if (lastSlash != std::string::npos && lastSlash > 0)
    {
        std::string directory = filePath.substr(0, lastSlash);
        if (!directory.empty())
        {
            // Create directory recursively using mkdir -p
            std::string cmd = "mkdir -p \"" + directory + "\" 2>/dev/null";
            int ret = system(cmd.c_str());
            (void)ret; // Suppress unused variable warning
        }
    }
    
    // Write body content to file
    std::ofstream file(filePath.c_str(), std::ios::binary | std::ios::trunc);
    if (!file.is_open())
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }
    
    const std::string& body = request.getBody();
    if (!body.empty())
    {
        file.write(body.c_str(), body.length());
    }
    file.close();
    
    if (file.fail())
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }
    
    // Return 201 if file was created, 200 if file was modified
    Response resp;
    resp.setStatusCode(fileExists ? HTTP_OK : HTTP_CREATED);
    resp.setHeader("Content-Length", "0");
    std::string response = resp.build();
    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}

void Server::_handleDelete(Client& client, const LocationConfig* location)
{
    const Request& request = client.getRequest();
    const ServerConfig* serverConfig = client.getServerConfig();
    
    std::string filePath = _resolvePath(request, location, serverConfig);

    struct stat fileStat;
    if (stat(filePath.c_str(), &fileStat) < 0)
    {
        _sendErrorResponse(client, HTTP_NOT_FOUND);
        return;
    }

    if (!S_ISREG(fileStat.st_mode))
    {
        _sendErrorResponse(client, HTTP_FORBIDDEN);
        return;
    }

    if (std::remove(filePath.c_str()) != 0)
    {
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    Response resp;
    resp.setStatusCode(HTTP_NO_CONTENT);
    std::string response = resp.build();
    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}

void Server::_handleCgi(Client& client, const LocationConfig* location, 
                        const std::string& filePath)
{
    const Request& request = client.getRequest();
    const ServerConfig* serverConfig = client.getServerConfig();

    // Find CGI handler
    std::string extension;
    size_t dotPos = filePath.rfind('.');
    if (dotPos != std::string::npos)
        extension = filePath.substr(dotPos);

    std::string cgiPath;
    if (location != NULL)
        cgiPath = location->getCgiHandler(extension);
    
    if (cgiPath.empty())
    {
        Utils::logError("CGI handler not configured for extension: " + extension);
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    // CRITICAL: Check if CGI handler (executable) exists and is executable
    if (access(cgiPath.c_str(), X_OK) < 0)
    {
        Utils::logError("CGI handler not found or not executable: " + cgiPath);
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    // Convert CGI path to absolute path BEFORE chdir
    // This is critical because we'll change directory to the script's directory
    std::string absoluteCgiPath;
    if (cgiPath[0] == '/')
    {
        // Already absolute
        absoluteCgiPath = cgiPath;
    }
    else
    {
        // Relative path - convert to absolute
        char currentDir[PATH_MAX];
        if (getcwd(currentDir, sizeof(currentDir)) != NULL)
        {
            absoluteCgiPath = std::string(currentDir) + "/" + cgiPath;
        }
        else
        {
            Utils::logError("Failed to get current directory for CGI");
            _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
            return;
        }
    }

    // Check script exists and is readable
    if (access(filePath.c_str(), R_OK) < 0)
    {
        Utils::logError("CGI script not found: " + filePath);
        _sendErrorResponse(client, HTTP_NOT_FOUND);
        return;
    }

    // Create pipes for CGI
    int pipeIn[2];
    int pipeOut[2];
    
    if (pipe(pipeIn) < 0 || pipe(pipeOut) < 0)
    {
        Utils::logError("Failed to create pipes for CGI");
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    pid_t pid = fork();
    if (pid < 0)
    {
        close(pipeIn[0]);
        close(pipeIn[1]);
        close(pipeOut[0]);
        close(pipeOut[1]);
        Utils::logError("Failed to fork for CGI");
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    if (pid == 0)
    {
        // Child process
        close(pipeIn[1]);
        close(pipeOut[0]);
        
        dup2(pipeIn[0], STDIN_FILENO);
        dup2(pipeOut[1], STDOUT_FILENO);
        
        close(pipeIn[0]);
        close(pipeOut[1]);

        // Change to script directory
        std::string scriptDir = filePath.substr(0, filePath.rfind('/'));
        std::string scriptName = filePath.substr(filePath.rfind('/') + 1);
        if (!scriptDir.empty())
            chdir(scriptDir.c_str());

        // Build environment
        std::vector<std::string> envStrings;
        envStrings.push_back("GATEWAY_INTERFACE=CGI/1.1");
        envStrings.push_back("SERVER_PROTOCOL=" + request.getVersion());
        envStrings.push_back("SERVER_SOFTWARE=webserv/1.0");
        envStrings.push_back("REQUEST_METHOD=" + request.getMethod());
        envStrings.push_back("SCRIPT_FILENAME=" + filePath);
        envStrings.push_back("SCRIPT_NAME=" + request.getPath());
        envStrings.push_back("PATH_INFO=");  // Empty - no additional path info
        envStrings.push_back("QUERY_STRING=" + request.getQuery());
        
        std::string contentType = request.getHeader("Content-Type");
        if (!contentType.empty())
            envStrings.push_back("CONTENT_TYPE=" + contentType);
        
        if (request.getContentLength() > 0)
            envStrings.push_back("CONTENT_LENGTH=" + Utils::intToString(request.getContentLength()));
        else
            envStrings.push_back("CONTENT_LENGTH=0");
        
        if (serverConfig != NULL)
        {
            envStrings.push_back("SERVER_NAME=" + serverConfig->getServerNames()[0]);
            envStrings.push_back("SERVER_PORT=" + Utils::intToString(serverConfig->getPort()));
        }

        envStrings.push_back("REMOTE_ADDR=" + client.getIp());

        // Add HTTP headers as HTTP_* environment variables
        const std::map<std::string, std::string>& headers = request.getHeaders();
        for (std::map<std::string, std::string>::const_iterator it = headers.begin();
             it != headers.end(); ++it)
        {
            std::string envName = "HTTP_" + it->first;
            for (size_t i = 0; i < envName.length(); ++i)
            {
                if (envName[i] == '-')
                    envName[i] = '_';
                else
                    envName[i] = std::toupper(envName[i]);
            }
            envStrings.push_back(envName + "=" + it->second);
        }

        std::vector<char*> env;
        for (size_t i = 0; i < envStrings.size(); ++i)
            env.push_back(const_cast<char*>(envStrings[i].c_str()));
        env.push_back(NULL);

        // Build args - use absolute CGI path and script name
        char* args[3];
        args[0] = const_cast<char*>(absoluteCgiPath.c_str());
        args[1] = const_cast<char*>(scriptName.c_str());
        args[2] = NULL;

        execve(absoluteCgiPath.c_str(), args, &env[0]);
        
        // If we get here, execve failed
        Utils::logError("execve failed for CGI: " + absoluteCgiPath);
        _exit(1);
    }

    // Parent process
    close(pipeIn[0]);
    close(pipeOut[1]);

    // Write body to CGI stdin
    const std::string& body = request.getBody();
    if (!body.empty())
    {
        write(pipeIn[1], body.c_str(), body.size());
    }
    close(pipeIn[1]);

    // Set up for reading CGI output
    if (!_setNonBlocking(pipeOut[0]))
    {
        close(pipeOut[0]);
        kill(pid, SIGTERM);
        waitpid(pid, NULL, 0);
        Utils::logError("Failed to set non-blocking on CGI pipe");
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    _cgiToClient[pipeOut[0]] = client.getFd();
    client.setCgiPid(pid);
    client.setCgiFdOut(pipeOut[0]);
    client.setCgiStartTime(std::time(NULL));
    client.setState(CLIENT_CGI_RUNNING);
    
    Utils::logDebug("CGI started: " + absoluteCgiPath + " for script: " + filePath);
}

void Server::_handleRedirect(Client& client, const LocationConfig* location)
{
    int code = location->getRedirectCode();
    std::string url = location->getRedirect();

    Response resp = Response::makeRedirect(code, url);
    std::string response = resp.build();
    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}

void Server::_handleDirectoryListing(Client& client, const std::string& path, 
                                     const std::string& uri)
{
    Response resp = Response::makeDirectoryListing(path, uri);
    std::string response = resp.build();

    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}

void Server::_handleFileUpload(Client& client, const LocationConfig* location)
{
    const Request& request = client.getRequest();
    
    std::string uploadPath = location->getUploadPath();
    if (uploadPath.empty())
        uploadPath = "/tmp/uploads";

    // Create upload directory if needed
    mkdir(uploadPath.c_str(), 0755);

    const std::vector<UploadedFile>& files = request.getUploadedFiles();
    
    if (files.empty())
    {
        // No multipart, save raw body
        std::string filename = "upload_" + Utils::intToString(std::time(NULL));
        std::string fullPath = uploadPath + "/" + filename;

        std::ofstream file(fullPath.c_str(), std::ios::binary);
        if (!file)
        {
            _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
            return;
        }
        file << request.getBody();
        file.close();
    }
    else
    {
        // Save each uploaded file
        for (size_t i = 0; i < files.size(); ++i)
        {
            std::string filename = files[i].filename;
            if (filename.empty())
                filename = "upload_" + Utils::intToString(std::time(NULL)) + "_" + Utils::intToString(i);

            // Sanitize filename - remove path separators and special characters
            std::string cleanFilename;
            for (size_t j = 0; j < filename.length(); ++j)
            {
                char c = filename[j];
                if (c != '/' && c != '\\' && c != ':' && c != '*' && c != '?' && 
                    c != '"' && c != '<' && c != '>' && c != '|')
                    cleanFilename += c;
            }
            filename = cleanFilename;

            std::string fullPath = uploadPath + "/" + filename;

            std::ofstream file(fullPath.c_str(), std::ios::binary);
            if (!file)
            {
                _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
                return;
            }
            file << files[i].data;
            file.close();
        }
    }

    Response resp;
    resp.setStatusCode(HTTP_CREATED);
    std::string response = resp.build();
    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}

// ============================================================================
// Helper methods
// ============================================================================

std::string Server::_resolvePath(const Request& request, const LocationConfig* location,
                                 const ServerConfig* server)
{
    std::string uri = request.getPath();
    std::string root;

    if (location != NULL && !location->getRoot().empty())
        root = location->getRoot();
    else if (server != NULL)
        root = server->getRoot();
    else
        root = "./www";

    // Handle alias
    if (location != NULL && !location->getAlias().empty())
    {
        std::string locPath = location->getPath();
        if (uri.find(locPath) == 0)
            uri = uri.substr(locPath.length());
        return location->getAlias() + uri;
    }

    // Normal path resolution
    std::string path = root + uri;

    // Normalize (remove .. etc)
    path = Utils::normalizePath(path);

    return path;
}

void Server::_sendResponse(Client& client)
{
    // Response already in write buffer
    client.setState(CLIENT_WRITING);
}

void Server::_sendErrorResponse(Client& client, int code)
{
    const ServerConfig* serverConfig = client.getServerConfig();
    const Request& request = client.getRequest();
    
    Response resp = Response::makeError(code, serverConfig);
    
    // RFC 7231: 405 responses MUST include an Allow header
    if (code == HTTP_METHOD_NOT_ALLOWED && serverConfig != NULL)
    {
        const LocationConfig* location = serverConfig->findLocation(request.getPath());
        if (location != NULL)
        {
            const std::set<std::string>& methods = location->getAllowedMethods();
            std::string allowHeader;
            for (std::set<std::string>::const_iterator it = methods.begin(); 
                 it != methods.end(); ++it)
            {
                if (!allowHeader.empty())
                    allowHeader += ", ";
                allowHeader += *it;
            }
            if (!allowHeader.empty())
                resp.setHeader("Allow", allowHeader);
        }
    }
    
    std::string response = resp.build();

    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
    client.setKeepAlive(false);
}

void Server::_prepareCgiResponse(Client& client)
{
    std::string& output = client.getCgiOutput();

    Utils::logDebug("Preparing CGI response, output size: " + Utils::intToString(output.size()));

    if (output.empty())
    {
        Utils::logError("CGI produced no output!");
        _sendErrorResponse(client, HTTP_INTERNAL_SERVER_ERROR);
        return;
    }

    // Log first 200 chars of CGI output for debugging
    std::string preview = output.substr(0, output.size() < 200 ? output.size() : 200);
    Utils::logDebug("CGI output preview: " + preview);

    // Parse CGI output
    Response resp = Response::makeFromCGI(output);
    std::string response = resp.build();
    
    client.appendToWriteBuffer(response);
    client.setState(CLIENT_WRITING);
}

bool Server::_isCgiRequest(const std::string& path, const LocationConfig* location)
{
    if (location == NULL)
        return false;

    size_t dotPos = path.rfind('.');
    if (dotPos == std::string::npos)
        return false;

    std::string extension = path.substr(dotPos);
    return !location->getCgiHandler(extension).empty();
}
