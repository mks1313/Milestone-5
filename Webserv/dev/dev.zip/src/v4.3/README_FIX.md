# FIX: CGI PATH_INFO

## Problema Encontrado

El CGI producía output pero con error:
```
Status: 500 Internal Server Error
PATH_INFO incorrect
```

## Causa

```cpp
// ANTES (INCORRECTO)
envStrings.push_back("SCRIPT_NAME=" + request.getPath());  // /directory/youpi.bla
envStrings.push_back("PATH_INFO=" + request.getPath());    // /directory/youpi.bla ❌
```

PATH_INFO y SCRIPT_NAME eran IGUALES. Esto es incorrecto según CGI spec.

## Solución

```cpp
// AHORA (CORRECTO)
envStrings.push_back("SCRIPT_NAME=" + request.getPath());  // /directory/youpi.bla
envStrings.push_back("PATH_INFO=");                        // vacío ✅
```

PATH_INFO debe estar vacío si no hay información adicional después del script.

## Aplicar

```bash
tar -xzf webserv_FIX_PATH_INFO.tar.gz
make re
./bin/webserv config/webserv.conf
```

Probar:
```bash
curl -X POST http://localhost:8080/directory/youpi.bla
```

Debería devolver HTTP 200 con output HTML del CGI.

## Sobre los Warnings

Si ves:
```
⚠️  WARN: POST no CT: 204
⚠️  WARN: Invalid CT: 204
```

Significa que POST a `/` devuelve 204.

Si tu config dice `methods GET` para `/`, entonces POST debería devolver 405.

**Reinicia el servidor** después de cambiar webserv.conf:
```bash
pkill webserv
./bin/webserv config/webserv.conf
```

Si la config tiene `methods GET` en `/` y reinicias el servidor, los warnings deberían ser:
```
⚠️  WARN: POST no CT: 405
⚠️  WARN: Invalid CT: 405
```

Y esto es CORRECTO - POST rechazado porque solo GET permitido.
