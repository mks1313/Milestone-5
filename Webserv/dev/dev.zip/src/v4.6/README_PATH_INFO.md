# FIX: PATH_INFO debe ser "/" no vacío

## El Problema

El CGI de 42 dice: **"PATH_INFO not found"**

Esto ocurría incluso con `PATH_INFO=""` (vacío). El CGI de 42 **requiere** que PATH_INFO tenga un valor.

## La Solución

```cpp
// ANTES (incorrecto)
envStrings.push_back("PATH_INFO=");  // Vacío

// AHORA (correcto)
envStrings.push_back("PATH_INFO=/");  // Slash
```

Para CGI en directorios, PATH_INFO debe ser "/" (raíz relativa).

## Aplicar

```bash
tar -xzf webserv_PATH_INFO_SLASH.tar.gz
make re
```

## Probar

### Test manual primero:
```bash
bash test_cgi_manual.sh
```

**Resultado esperado**: CGI devuelve HTML exitoso (NO más "PATH_INFO not found").

### Test con servidor:
```bash
./bin/webserv config/webserv.conf &
curl -X POST http://localhost:8080/directory/youpi.bla
```

**Resultado esperado**: HTTP 200 con HTML del CGI.

## ¿Por qué "/"?

Según el estándar CGI:
- Si accedes a `/directory/youpi.bla` directamente
- PATH_INFO debe ser "/" (raíz del recurso)
- NO puede estar vacío o ausente

El CGI de 42 verifica explícitamente que PATH_INFO exista y tenga un valor válido.
