# DEBUG CGI - Instrucciones

## Aplicar versión debug

```bash
cd ~/Documentos/42-C06-Prj14-Webserv
tar -xzf webserv_DEBUG_CGI.tar.gz
make re
```

## Paso 1: Probar CGI manualmente

```bash
chmod +x test_cgi_manual.sh
bash test_cgi_manual.sh
```

**Esto probará el CGI con las MISMAS variables de entorno que el servidor usa.**

Si esto falla o no produce output, el problema está en:
- El CGI tester en sí
- Las variables de entorno
- El archivo youpi.bla

## Paso 2: Ejecutar servidor y ver logs DETALLADOS

```bash
./bin/webserv config/webserv.conf
```

En otra terminal:
```bash
curl -X POST http://localhost:8080/directory/youpi.bla
```

**BUSCA ESTOS LOGS**:
```
[DEBUG] CGI started: ...
[DEBUG] CGI read: X bytes          ← ¿Cuántos bytes lee?
[DEBUG] CGI output accumulated: X bytes
[DEBUG] CGI finished, total output: X bytes
[DEBUG] CGI process exited with status: X
[DEBUG] Preparing CGI response, output size: X
[DEBUG] CGI output preview: ...    ← ¿Qué output produce?
```

## Análisis

### Si ves "CGI read: 0 bytes" inmediatamente
→ El CGI no está produciendo output en stdout

### Si ves "CGI produced no output!"
→ El CGI se ejecuta pero no escribe nada a stdout

### Si ves "CGI process exited with status: 1"
→ El CGI falló, revisar que:
  - ubuntu_cgi_tester existe y es ejecutable
  - youpi.bla existe
  - Las variables de entorno son correctas

## Warnings de Security

Los 2 warnings de POST sin/con CT a `/` son CORRECTOS.
Tu configuración dice:
```
location / {
    methods GET;
}
```

Por eso POST devuelve 405. **No es un error.**

Si quieres que POST funcione en `/`, cambia la configuración a:
```
location / {
    methods GET POST;
}
```

Pero entonces el test fallará porque espera que `/` rechace POST.
