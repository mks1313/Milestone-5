#!/bin/bash
#############################################################################
# debug_server.sh - Script de Debug para Webserv
#
# Este script ayuda a debugear los problemas identificados en los tests:
# 1. DELETE / devuelve 403 en lugar de 405
# 2. POST /post_body devuelve 405 en lugar de 200/413
# 3. CGI .bla devuelve 500
#
# Uso: ./debug_server.sh [problema]
#   problema: delete | post | cgi | all (default: all)
#############################################################################

set -u

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

PORT=8080
BASE_URL="http://localhost:$PORT"

# Check if server is running
check_server() {
    if ! nc -z localhost $PORT 2>/dev/null; then
        echo -e "${RED}❌ Server not running on port $PORT${NC}"
        echo "Please start the server first:"
        echo "  ./bin/webserv config/webserv.conf"
        exit 1
    fi
    echo -e "${GREEN}✓ Server is running on port $PORT${NC}"
    echo ""
}

# Test DELETE / problem
test_delete() {
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  DEBUG: DELETE / Problem${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    echo -e "${YELLOW}Expected:${NC} 405 Method Not Allowed"
    echo -e "${YELLOW}Problem:${NC} Returns 403 Forbidden instead"
    echo ""
    
    echo -e "${BLUE}Testing DELETE /${NC}"
    status=$(curl -s -o /dev/null -w "%{http_code}" -X DELETE "$BASE_URL/" 2>/dev/null)
    
    if [ "$status" = "405" ]; then
        echo -e "  ${GREEN}✅ FIXED: DELETE / → $status (correct!)${NC}"
    else
        echo -e "  ${RED}❌ FAIL: DELETE / → $status (expected 405)${NC}"
    fi
    
    echo ""
    echo -e "${YELLOW}Possible Causes:${NC}"
    echo "  1. Location / incorrectly allows DELETE method"
    echo "  2. Method checking happens after path resolution"
    echo "  3. Server calls _handleDelete() before checking if method is allowed"
    echo ""
    echo -e "${YELLOW}Check in Server.cpp:${NC}"
    echo "  Line ~727: if (location != NULL && !location->isMethodAllowed(methodToCheck))"
    echo "  Line ~746: else if (method == \"DELETE\")"
    echo ""
    echo -e "${YELLOW}Add debug logging before line 727:${NC}"
    echo '  std::cout << "[DEBUG] Method: " << method << std::endl;'
    echo '  std::cout << "[DEBUG] Path: " << request.getPath() << std::endl;'
    echo '  if (location) {'
    echo '      std::cout << "[DEBUG] Location: " << location->getPath() << std::endl;'
    echo '      std::cout << "[DEBUG] DELETE allowed: " << (location->isMethodAllowed("DELETE") ? "YES" : "NO") << std::endl;'
    echo '  }'
    echo ""
}

# Test POST /post_body problem
test_post() {
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  DEBUG: POST /post_body Problem${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    echo -e "${YELLOW}Expected (small body):${NC} 200 OK or 204 No Content"
    echo -e "${YELLOW}Expected (large body >100):${NC} 413 Payload Too Large"
    echo -e "${YELLOW}Problem:${NC} Both return 405 Method Not Allowed"
    echo ""
    
    # Test small body
    echo -e "${BLUE}Testing POST /post_body (small body)${NC}"
    status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "small" "$BASE_URL/post_body" 2>/dev/null)
    
    if [ "$status" = "200" ] || [ "$status" = "204" ]; then
        echo -e "  ${GREEN}✅ FIXED: POST /post_body (small) → $status (correct!)${NC}"
    else
        echo -e "  ${RED}❌ FAIL: POST /post_body (small) → $status (expected 200 or 204)${NC}"
    fi
    
    # Test large body
    echo -e "${BLUE}Testing POST /post_body (large body >100 bytes)${NC}"
    large_body=$(printf 'A%.0s' {1..150})
    status=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "$large_body" "$BASE_URL/post_body" 2>/dev/null)
    
    if [ "$status" = "413" ]; then
        echo -e "  ${GREEN}✅ FIXED: POST /post_body (large) → $status (correct!)${NC}"
    else
        echo -e "  ${RED}❌ FAIL: POST /post_body (large) → $status (expected 413)${NC}"
    fi
    
    echo ""
    echo -e "${YELLOW}Possible Causes:${NC}"
    echo "  1. Location matching is broken - /post_body matches / instead"
    echo "  2. Config parsing doesn't set methods correctly for /post_body"
    echo "  3. Location / is being used as fallback when it shouldn't"
    echo ""
    echo -e "${YELLOW}Check in config/webserv.conf:${NC}"
    echo "  Lines 61-64: location /post_body { methods POST GET; ... }"
    echo ""
    echo -e "${YELLOW}Add debug logging in Server.cpp before line 727:${NC}"
    echo '  std::cout << "[DEBUG] Method: " << method << std::endl;'
    echo '  std::cout << "[DEBUG] Path: " << request.getPath() << std::endl;'
    echo '  if (location) {'
    echo '      std::cout << "[DEBUG] Matched Location: " << location->getPath() << std::endl;'
    echo '      const std::vector<std::string>& methods = location->getMethods();'
    echo '      std::cout << "[DEBUG] Allowed methods: ";'
    echo '      for (size_t i = 0; i < methods.size(); i++)'
    echo '          std::cout << methods[i] << " ";'
    echo '      std::cout << std::endl;'
    echo '  }'
    echo ""
    echo -e "${YELLOW}Check in ServerConfig.cpp (findLocation):${NC}"
    echo "  Add logging to see which location is being matched"
    echo ""
}

# Test CGI .bla problem
test_cgi() {
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  DEBUG: CGI .bla Problem${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    echo -e "${YELLOW}Expected:${NC} 200 OK with CGI output"
    echo -e "${YELLOW}Problem:${NC} Returns 500 Internal Server Error"
    echo ""
    
    # Check if YoupiBanane directory exists
    if [ ! -d "YoupiBanane" ]; then
        echo -e "${RED}❌ YoupiBanane directory not found${NC}"
        echo "  Create it with: mkdir -p YoupiBanane/nop YoupiBanane/Yeah"
        echo ""
    else
        echo -e "${GREEN}✓ YoupiBanane directory exists${NC}"
    fi
    
    # Check if youpi.bla exists
    if [ ! -f "YoupiBanane/youpi.bla" ]; then
        echo -e "${RED}❌ YoupiBanane/youpi.bla not found${NC}"
        echo "  Create it with: echo 'test content' > YoupiBanane/youpi.bla"
        echo ""
    else
        echo -e "${GREEN}✓ YoupiBanane/youpi.bla exists${NC}"
    fi
    
    # Check if CGI tester exists
    if [ ! -f "testers/ubuntu_cgi_tester" ]; then
        echo -e "${RED}❌ testers/ubuntu_cgi_tester not found${NC}"
        echo "  Download it from the 42 tester repository"
        echo ""
    else
        echo -e "${GREEN}✓ testers/ubuntu_cgi_tester exists${NC}"
        
        # Check if it's executable
        if [ -x "testers/ubuntu_cgi_tester" ]; then
            echo -e "${GREEN}✓ testers/ubuntu_cgi_tester is executable${NC}"
        else
            echo -e "${RED}❌ testers/ubuntu_cgi_tester is not executable${NC}"
            echo "  Fix with: chmod +x testers/ubuntu_cgi_tester"
            echo ""
        fi
    fi
    
    echo ""
    echo -e "${BLUE}Testing POST /directory/youpi.bla${NC}"
    
    # Capture both status and output
    response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/directory/youpi.bla" 2>/dev/null)
    status=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$status" = "200" ]; then
        echo -e "  ${GREEN}✅ FIXED: POST /directory/youpi.bla → $status (correct!)${NC}"
        echo -e "${GREEN}  CGI Output:${NC}"
        echo "$body" | head -5
        if [ $(echo "$body" | wc -l) -gt 5 ]; then
            echo "  ... (truncated)"
        fi
    else
        echo -e "  ${RED}❌ FAIL: POST /directory/youpi.bla → $status (expected 200)${NC}"
        if [ -n "$body" ]; then
            echo -e "${RED}  Error body:${NC}"
            echo "$body"
        fi
    fi
    
    echo ""
    echo -e "${YELLOW}Manual CGI Test:${NC}"
    echo "  Test the CGI manually to verify it works:"
    echo ""
    echo '  export REQUEST_METHOD=POST'
    echo '  export CONTENT_LENGTH=0'
    echo '  export CONTENT_TYPE=""'
    echo '  export QUERY_STRING=""'
    echo '  ./testers/ubuntu_cgi_tester YoupiBanane/youpi.bla'
    echo ""
    echo -e "${YELLOW}Add debug logging in Server.cpp (_handleCgi, line ~955):${NC}"
    echo '  std::cout << "[DEBUG] CGI path: " << cgiPath << std::endl;'
    echo '  std::cout << "[DEBUG] Script: " << filePath << std::endl;'
    echo '  std::cout << "[DEBUG] Extension: " << extension << std::endl;'
    echo '  std::cout << "[DEBUG] REQUEST_METHOD=" << request.getMethod() << std::endl;'
    echo ""
}

# Main function
main() {
    local test_type=${1:-all}
    
    check_server
    
    case "$test_type" in
        delete)
            test_delete
            ;;
        post)
            test_post
            ;;
        cgi)
            test_cgi
            ;;
        all)
            test_delete
            echo ""
            test_post
            echo ""
            test_cgi
            ;;
        *)
            echo "Usage: $0 [delete|post|cgi|all]"
            exit 1
            ;;
    esac
    
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  Summary${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Add debug logging as suggested above"
    echo "  2. Recompile: make re"
    echo "  3. Run server with: ./bin/webserv config/webserv.conf"
    echo "  4. Test again with: ./debug_server.sh"
    echo "  5. Analyze debug output to find the root cause"
    echo ""
}

# Run main
main "$@"
