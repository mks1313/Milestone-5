#!/bin/bash

echo "=== Simulando ubuntu_tester: POST / con size 0 ==="
echo ""

PORT=8080
HOST=localhost

# Verificar servidor
if ! nc -z $HOST $PORT 2>/dev/null; then
    echo "❌ Servidor no corriendo en $HOST:$PORT"
    exit 1
fi

echo "✅ Servidor detectado"
echo ""

# Test 1: El GET que funciona
echo "═══════════════════════════════════════════════════════════"
echo "Test 1: GET / (este debería funcionar)"
echo "═══════════════════════════════════════════════════════════"
RESPONSE=$(curl -s -w "\n---\nHTTP_CODE:%{http_code}\nCONTENT_LENGTH:%{size_download}\n" http://$HOST:$PORT/ 2>&1)
HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP_CODE:" | cut -d: -f2)
echo "Status Code: $HTTP_CODE"
if [ "$HTTP_CODE" = "200" ]; then
    echo "✅ PASS - GET / devuelve 200"
else
    echo "❌ FAIL - GET / devuelve $HTTP_CODE (esperado: 200)"
fi
echo ""

# Test 2: El POST que falla
echo "═══════════════════════════════════════════════════════════"
echo "Test 2: POST / with size 0 (el que falla en el tester)"
echo "═══════════════════════════════════════════════════════════"
echo "Enviando POST con body vacío..."
echo ""

# Mostrar request completo
echo "--- REQUEST ---"
echo "POST / HTTP/1.1"
echo "Host: $HOST:$PORT"
echo "Content-Length: 0"
echo ""

# Hacer el request y capturar respuesta completa
echo "--- RESPONSE ---"
RESPONSE=$(curl -i -s -X POST -H "Content-Length: 0" http://$HOST:$PORT/ 2>&1)
echo "$RESPONSE" | head -20
echo ""

# Extraer status code
HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP/" | head -1 | awk '{print $2}')
echo "═══════════════════════════════════════════════════════════"
echo "Status Code Devuelto: $HTTP_CODE"
echo ""

# Analizar el código
case $HTTP_CODE in
    200)
        echo "ℹ️  Servidor devuelve 200 OK"
        echo "   Pero según config, / solo permite GET"
        echo "   ❌ Esto podría ser el problema"
        ;;
    204)
        echo "ℹ️  Servidor devuelve 204 No Content"
        echo "   Esto podría ser correcto para POST vacío"
        ;;
    405)
        echo "ℹ️  Servidor devuelve 405 Method Not Allowed"
        echo "   Esto es técnicamente correcto según HTTP"
        echo "   Pero el tester dice 'bad status code'"
        echo ""
        echo "   POSIBLES PROBLEMAS:"
        echo "   1. Tester espera 200 o 204 en lugar de 405"
        echo "   2. Tester espera un body vacío (Content-Length: 0)"
        echo "   3. Hay un problema con otros headers"
        ;;
    400)
        echo "ℹ️  Servidor devuelve 400 Bad Request"
        echo "   ¿Por qué? Investiga si hay validación del request"
        ;;
    *)
        echo "ℹ️  Servidor devuelve código inesperado: $HTTP_CODE"
        ;;
esac

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "ANÁLISIS"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Verificar Content-Length de la respuesta
CONTENT_LENGTH=$(echo "$RESPONSE" | grep -i "Content-Length:" | head -1 | awk '{print $2}' | tr -d '\r')
echo "Content-Length de la respuesta: ${CONTENT_LENGTH:-'no especificado'}"

# Verificar Connection header
CONNECTION=$(echo "$RESPONSE" | grep -i "Connection:" | head -1 | awk '{print $2}' | tr -d '\r')
echo "Connection header: ${CONNECTION:-'no especificado'}"

echo ""
echo "RECOMENDACIONES:"
echo ""
if [ "$HTTP_CODE" = "405" ]; then
    echo "El servidor devuelve 405, que es correcto según HTTP,"
    echo "pero el ubuntu_tester parece esperar otro código."
    echo ""
    echo "SOLUCIONES POSIBLES:"
    echo "1. Hacer que POST / devuelva 200 con body vacío"
    echo "2. Hacer que POST / devuelva 204 No Content"
    echo "3. Verificar si el body de error 405 está causando problema"
elif [ "$HTTP_CODE" = "200" ]; then
    echo "El servidor acepta POST /, pero tu config dice 'methods GET'"
    echo "Verifica la implementación del método POST."
fi
