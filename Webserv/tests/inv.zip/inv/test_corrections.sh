#!/bin/bash

# Test rápido de las correcciones

echo "╔══════════════════════════════════════════════════════════════"
echo "║ Pruebas Rápidas - Correcciones de Métodos Permitidos"
echo "╚══════════════════════════════════════════════════════════════"
echo ""

# Verificar que el servidor NO está corriendo
if nc -z localhost 8080 2>/dev/null; then
    echo "⚠️  Servidor ya está corriendo en puerto 8080"
    echo "   Por favor, detén el servidor antes de ejecutar este script"
    exit 1
fi

# Iniciar el servidor en segundo plano
echo "▶️  Iniciando servidor..."
./bin/webserv config/webserv.conf > /tmp/webserv_test.log 2>&1 &
SERVER_PID=$!

# Esperar a que el servidor esté listo
sleep 2

if ! kill -0 $SERVER_PID 2>/dev/null; then
    echo "❌ Error: El servidor no pudo iniciarse"
    cat /tmp/webserv_test.log
    exit 1
fi

echo "✓ Servidor iniciado (PID: $SERVER_PID)"
echo ""

# ============================================================================
# Test 1: DELETE / debe devolver 405 (no 403)
# ============================================================================
echo "═══════════════════════════════════════════════════════════════"
echo "  Test 1: DELETE /"
echo "═══════════════════════════════════════════════════════════════"
echo "Esperado: 405 Method Not Allowed"
echo "Razón: Location / solo permite GET"
echo ""

RESPONSE=$(curl -s -w "\n%{http_code}" -X DELETE http://localhost:8080/)
HTTP_CODE=$(echo "$RESPONSE" | tail -n1)

if [ "$HTTP_CODE" = "405" ]; then
    echo "✅ PASS: DELETE / → 405 Method Not Allowed"
else
    echo "❌ FAIL: DELETE / → $HTTP_CODE (esperado 405)"
fi
echo ""

# ============================================================================
# Test 2: POST /post_body con body pequeño debe devolver 204 (no 405)
# ============================================================================
echo "═══════════════════════════════════════════════════════════════"
echo "  Test 2: POST /post_body (body pequeño)"
echo "═══════════════════════════════════════════════════════════════"
echo "Esperado: 204 No Content"
echo "Razón: Location /post_body permite POST, max_body_size 100"
echo ""

RESPONSE=$(curl -s -w "\n%{http_code}" -X POST -d "test" http://localhost:8080/post_body)
HTTP_CODE=$(echo "$RESPONSE" | tail -n1)

if [ "$HTTP_CODE" = "204" ]; then
    echo "✅ PASS: POST /post_body (pequeño) → 204 No Content"
else
    echo "❌ FAIL: POST /post_body (pequeño) → $HTTP_CODE (esperado 204)"
fi
echo ""

# ============================================================================
# Test 3: POST /post_body con body grande debe devolver 413
# ============================================================================
echo "═══════════════════════════════════════════════════════════════"
echo "  Test 3: POST /post_body (body >100 bytes)"
echo "═══════════════════════════════════════════════════════════════"
echo "Esperado: 413 Payload Too Large"
echo "Razón: Body excede client_max_body_size 100"
echo ""

LARGE_BODY=$(printf 'A%.0s' {1..150})
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST -d "$LARGE_BODY" http://localhost:8080/post_body)
HTTP_CODE=$(echo "$RESPONSE" | tail -n1)

if [ "$HTTP_CODE" = "413" ]; then
    echo "✅ PASS: POST /post_body (grande) → 413 Payload Too Large"
else
    echo "❌ FAIL: POST /post_body (grande) → $HTTP_CODE (esperado 413)"
fi
echo ""

# ============================================================================
# Resumen
# ============================================================================
echo "═══════════════════════════════════════════════════════════════"
echo "  Resumen"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "Si todos los tests pasaron:"
echo "  ✅ Métodos permitidos se leen correctamente de la configuración"
echo "  ✅ POST sin CGI/upload devuelve 204 en lugar de 405"
echo "  ✅ Verificación de max_body_size funciona correctamente"
echo ""
echo "Si DELETE / todavía devuelve 403:"
echo "  ⚠️  La configuración todavía permite DELETE en location /"
echo "  → Revisar que clearAllowedMethods() se llama correctamente"
echo ""
echo "Si POST /post_body todavía devuelve 405:"
echo "  ⚠️  La configuración no permite POST en location /post_body"
echo "  → Revisar el parsing de la directiva 'methods'"
echo ""

# Detener el servidor
echo "🛑 Deteniendo servidor..."
kill $SERVER_PID 2>/dev/null
wait $SERVER_PID 2>/dev/null

echo ""
echo "✓ Tests completados"
echo ""
echo "Para ver el log completo del servidor:"
echo "  cat /tmp/webserv_test.log"
echo ""
