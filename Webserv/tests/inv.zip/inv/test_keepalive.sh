#!/bin/bash
# test_keepalive.sh - Test HTTP/1.1 Keep-Alive functionality

PORT=8080
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  HTTP/1.1 Keep-Alive Test - Multiple Requests             ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check server
if ! nc -z localhost $PORT 2>/dev/null; then
    echo -e "${RED}✗ Server not running on port $PORT${NC}"
    echo "Please start it:"
    echo "  ./bin/webserv config/webserv.conf &"
    exit 1
fi

echo -e "${GREEN}✓ Server is running${NC}"
echo ""

echo -e "${YELLOW}Simulating ubuntu_tester sequence:${NC}"
echo "  1. GET / → expecting 200"
echo "  2. POST / → expecting 405"
echo "  3. GET / → expecting 200 (on SAME connection)"
echo ""

# Create temporary file for response
RESPONSE_FILE=$(mktemp)
trap "rm -f $RESPONSE_FILE" EXIT

# Send 3 requests in sequence on the SAME connection
{
    # Request 1: GET /
    echo -e "GET / HTTP/1.1\r"
    echo -e "Host: localhost:$PORT\r"
    echo -e "\r"
    sleep 0.5
    
    # Request 2: POST / (should be 405)
    echo -e "POST / HTTP/1.1\r"
    echo -e "Host: localhost:$PORT\r"
    echo -e "Content-Length: 0\r"
    echo -e "\r"
    sleep 0.5
    
    # Request 3: GET / (tests if connection is still alive)
    echo -e "GET / HTTP/1.1\r"
    echo -e "Host: localhost:$PORT\r"
    echo -e "\r"
    sleep 0.5
} | nc localhost $PORT > $RESPONSE_FILE 2>&1

# Count how many "HTTP/1.1" responses we got
HTTP_RESPONSES=$(grep -c "^HTTP/1.1" $RESPONSE_FILE)

echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  RESULTS${NC}"
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""

# Extract status codes
STATUS_1=$(grep "^HTTP/1.1" $RESPONSE_FILE | sed -n '1p' | awk '{print $2}')
STATUS_2=$(grep "^HTTP/1.1" $RESPONSE_FILE | sed -n '2p' | awk '{print $2}')
STATUS_3=$(grep "^HTTP/1.1" $RESPONSE_FILE | sed -n '3p' | awk '{print $2}')

# Extract Connection headers
CONN_1=$(grep -i "^Connection:" $RESPONSE_FILE | sed -n '1p' | cut -d: -f2 | xargs)
CONN_2=$(grep -i "^Connection:" $RESPONSE_FILE | sed -n '2p' | cut -d: -f2 | xargs)
CONN_3=$(grep -i "^Connection:" $RESPONSE_FILE | sed -n '3p' | cut -d: -f2 | xargs)

echo "Request 1 (GET /):"
echo -n "  Status: $STATUS_1 ... "
if [ "$STATUS_1" = "200" ]; then
    echo -e "${GREEN}✅ PASS${NC}"
else
    echo -e "${RED}❌ FAIL (expected 200)${NC}"
fi
echo "  Connection: $CONN_1"

echo ""
echo "Request 2 (POST /):"
echo -n "  Status: $STATUS_2 ... "
if [ "$STATUS_2" = "405" ]; then
    echo -e "${GREEN}✅ PASS${NC}"
else
    echo -e "${RED}❌ FAIL (expected 405)${NC}"
fi
echo "  Connection: $CONN_2"

echo ""
echo "Request 3 (GET / after error):"
echo -n "  Status: $STATUS_3 ... "
if [ "$STATUS_3" = "200" ]; then
    echo -e "${GREEN}✅ PASS (keep-alive works!)${NC}"
else
    if [ -z "$STATUS_3" ]; then
        echo -e "${RED}❌ FAIL (no response - connection was closed!)${NC}"
    else
        echo -e "${YELLOW}⚠️  Got $STATUS_3 instead of 200${NC}"
    fi
fi
if [ -n "$CONN_3" ]; then
    echo "  Connection: $CONN_3"
fi

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""

# Final verdict
if [ "$HTTP_RESPONSES" -eq 3 ] && [ "$STATUS_1" = "200" ] && [ "$STATUS_2" = "405" ] && [ "$STATUS_3" = "200" ]; then
    echo -e "${GREEN}✅ KEEP-ALIVE WORKS CORRECTLY!${NC}"
    echo ""
    echo "The server correctly:"
    echo "  1. Responds to GET / with 200"
    echo "  2. Responds to POST / with 405"
    echo "  3. KEEPS CONNECTION ALIVE for next request"
    echo "  4. Responds to subsequent GET / with 200"
    echo ""
    echo "The ubuntu_tester should now pass the sequence of tests."
    echo ""
    echo "Next step: Run the official tester:"
    echo "  ./tests/ubuntu_tester.sh"
elif [ "$HTTP_RESPONSES" -eq 2 ]; then
    echo -e "${RED}❌ KEEP-ALIVE NOT WORKING${NC}"
    echo ""
    echo "Got only 2 HTTP responses instead of 3."
    echo "This means the connection was closed after the 405 response."
    echo ""
    echo "The fix was NOT applied correctly."
    echo "Please:"
    echo "  1. Copy Server.cpp.keepalive_fix to src/Server.cpp"
    echo "  2. Run: make re"
    echo "  3. Restart server and run this script again"
elif [ "$HTTP_RESPONSES" -eq 1 ]; then
    echo -e "${RED}❌ SEVERE ERROR - Only 1 response received${NC}"
    echo "Connection closed immediately. Check server logs."
else
    echo -e "${YELLOW}⚠️  UNEXPECTED RESULT${NC}"
    echo "Got $HTTP_RESPONSES HTTP responses (expected 3)"
    echo "Check the full response in: $RESPONSE_FILE"
fi

echo ""

# Offer to show full response if there was an error
if [ "$HTTP_RESPONSES" -ne 3 ]; then
    echo "Show full server response? (y/n)"
    read -r answer
    if [ "$answer" = "y" ]; then
        echo ""
        echo -e "${CYAN}Full Response:${NC}"
        cat $RESPONSE_FILE
    fi
fi
