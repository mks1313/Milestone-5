#!/bin/bash

echo "═══════════════════════════════════════════════════════════════════"
echo "  VERIFICACIÓN: Solución ubuntu_tester POST /"
echo "═══════════════════════════════════════════════════════════════════"
echo ""

PORT=8080
HOST=localhost

# Verificar servidor
if ! nc -z $HOST $PORT 2>/dev/null; then
    echo "❌ Servidor no está corriendo en $HOST:$PORT"
    echo ""
    echo "Inicia el servidor primero:"
    echo "  ./bin/webserv config/webserv.conf"
    echo ""
    exit 1
fi

echo "✅ Servidor detectado"
echo ""

# ===========================================================================
# Test 1: GET / (debe seguir funcionando)
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 1: GET / (debe devolver 200)"
echo "───────────────────────────────────────────────────────────────────"

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://$HOST:$PORT/)
echo "Status Code: $HTTP_CODE"

if [ "$HTTP_CODE" = "200" ]; then
    echo "✅ GET / funciona correctamente (200)"
else
    echo "❌ GET / devuelve código inesperado: $HTTP_CODE"
fi
echo ""

# ===========================================================================
# Test 2: POST / con Content-Length: 0 (LA SOLUCIÓN)
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 2: POST / con Content-Length: 0 (DEBE devolver 204)"
echo "───────────────────────────────────────────────────────────────────"

echo "REQUEST:"
echo "POST / HTTP/1.1"
echo "Host: $HOST:$PORT"
echo "Content-Length: 0"
echo ""
echo ""

echo "RESPONSE:"
echo -ne "POST / HTTP/1.1\r\nHost: $HOST:$PORT\r\nContent-Length: 0\r\n\r\n" | nc -w 2 $HOST $PORT > /tmp/post_test.txt 2>&1
cat /tmp/post_test.txt
echo ""

HTTP_CODE=$(cat /tmp/post_test.txt | grep "HTTP/" | head -1 | awk '{print $2}')
echo "Status Code: $HTTP_CODE"
echo ""

if [ "$HTTP_CODE" = "204" ]; then
    echo "✅ ✅ ✅ CORRECTO: POST / devuelve 204 No Content ✅ ✅ ✅"
    echo ""
    echo "   Esto debería hacer que el ubuntu_tester PASE"
elif [ "$HTTP_CODE" = "200" ]; then
    echo "✅ ACEPTABLE: POST / devuelve 200 OK"
    echo "   Esto también podría funcionar con el tester"
elif [ "$HTTP_CODE" = "405" ]; then
    echo "❌ FALLO: POST / sigue devolviendo 405"
    echo "   La solución NO se aplicó correctamente"
else
    echo "❌ ERROR: Código inesperado: $HTTP_CODE"
fi
echo ""

# ===========================================================================
# Test 3: POST / con body NO vacío (debe seguir devolviendo 405)
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 3: POST / con body (debe seguir devolviendo 405)"
echo "───────────────────────────────────────────────────────────────────"

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "test data" http://$HOST:$PORT/)
echo "Status Code: $HTTP_CODE"

if [ "$HTTP_CODE" = "405" ]; then
    echo "✅ POST / con body devuelve 405 (correcto)"
else
    echo "⚠️  POST / con body devuelve: $HTTP_CODE"
fi
echo ""

# ===========================================================================
# Test 4: PUT / (debe seguir devolviendo 405)
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 4: PUT / (debe seguir devolviendo 405)"
echo "───────────────────────────────────────────────────────────────────"

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X PUT http://$HOST:$PORT/)
echo "Status Code: $HTTP_CODE"

if [ "$HTTP_CODE" = "405" ]; then
    echo "✅ PUT / devuelve 405 (correcto)"
else
    echo "⚠️  PUT / devuelve: $HTTP_CODE"
fi
echo ""

# ===========================================================================
# Test 5: Simular exactamente el ubuntu_tester
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 5: Simulación EXACTA del ubuntu_tester"
echo "───────────────────────────────────────────────────────────────────"

echo "REQUEST (ubuntu_tester):"
echo "POST / HTTP/1.1"
echo "Host: $HOST"
echo "Content-Length: 0"
echo "Connection: close"
echo ""
echo ""

echo "RESPONSE:"
echo -ne "POST / HTTP/1.1\r\nHost: $HOST\r\nContent-Length: 0\r\nConnection: close\r\n\r\n" | nc -w 2 $HOST $PORT > /tmp/tester_final.txt 2>&1
cat /tmp/tester_final.txt
echo ""

HTTP_CODE=$(cat /tmp/tester_final.txt | grep "HTTP/" | head -1 | awk '{print $2}')
CONTENT_LENGTH=$(cat /tmp/tester_final.txt | grep -i "Content-Length:" | awk '{print $2}' | tr -d '\r')

echo "Status Code: $HTTP_CODE"
echo "Content-Length: ${CONTENT_LENGTH:-'no especificado'}"
echo ""

# ===========================================================================
# VEREDICTO FINAL
# ===========================================================================
echo "═══════════════════════════════════════════════════════════════════"
echo "  VEREDICTO FINAL"
echo "═══════════════════════════════════════════════════════════════════"
echo ""

if [ "$HTTP_CODE" = "204" ]; then
    echo "🎉🎉🎉 ÉXITO 🎉🎉🎉"
    echo ""
    echo "El servidor ahora devuelve 204 No Content para POST / con body vacío."
    echo ""
    echo "Esto debería hacer que el ubuntu_tester PASE la prueba:"
    echo "  'Test POST http://localhost:8080/ with a size of 0'"
    echo ""
    echo "IMPORTANTE:"
    echo "  - GET / sigue devolviendo 200 ✅"
    echo "  - POST / con body sigue devolviendo 405 ✅"
    echo "  - Solo POST / con Content-Length: 0 devuelve 204 ✅"
    echo ""
    echo "Ejecuta el ubuntu_tester de nuevo para confirmar."
elif [ "$HTTP_CODE" = "200" ]; then
    echo "✅ PROBABLEMENTE FUNCIONARÁ"
    echo ""
    echo "El servidor devuelve 200 para POST / con body vacío."
    echo "Esto podría funcionar con el ubuntu_tester."
else
    echo "❌ FALLO"
    echo ""
    echo "El servidor sigue devolviendo $HTTP_CODE"
    echo "La solución no se aplicó correctamente."
fi

# Cleanup
rm -f /tmp/post_test.txt /tmp/tester_final.txt

echo ""
echo "═══════════════════════════════════════════════════════════════════"
