#!/bin/bash

curl -X DELETE http://localhost:8080/ 
curl -X POST -d "test" http://localhost:8080/post_body

