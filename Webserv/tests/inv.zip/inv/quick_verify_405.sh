#!/bin/bash
# quick_verify_405.sh - Verificación rápida de la corrección ubuntu_tester

PORT=8080
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  Ubuntu Tester Fix - Quick Verification                   ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check server
if ! nc -z localhost $PORT 2>/dev/null; then
    echo -e "${RED}✗ Server not running on port $PORT${NC}"
    echo "Please start it:"
    echo "  ./bin/webserv config/webserv.conf &"
    exit 1
fi

echo -e "${GREEN}✓ Server is running${NC}"
echo ""

# Test 1: GET /
echo -e "${YELLOW}Test 1: GET /${NC}"
status=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:$PORT/)
echo -n "  Status: $status ... "
if [ "$status" = "200" ]; then
    echo -e "${GREEN}✅ PASS${NC}"
else
    echo -e "${RED}❌ FAIL (expected 200)${NC}"
fi
echo ""

# Test 2: POST / (EL CRÍTICO)
echo -e "${YELLOW}Test 2: POST / with Content-Length: 0${NC}"
echo "  (This is the test that was failing in ubuntu_tester)"
response=$(curl -i -s -X POST http://localhost:$PORT/)
status=$(echo "$response" | grep "HTTP/" | head -1 | awk '{print $2}')
allow=$(echo "$response" | grep -i "^Allow:" | cut -d: -f2 | xargs)

echo -n "  Status: $status ... "
if [ "$status" = "405" ]; then
    echo -e "${GREEN}✅ PASS${NC}"
else
    echo -e "${RED}❌ FAIL (expected 405, got $status)${NC}"
    echo ""
    echo -e "${RED}  This means the fix was not applied correctly.${NC}"
    exit 1
fi

echo -n "  Allow header: '$allow' ... "
if [ -n "$allow" ]; then
    echo -e "${GREEN}✅ PASS (header present)${NC}"
else
    echo -e "${YELLOW}⚠️  WARNING (header missing but not critical)${NC}"
fi
echo ""

# Test 3: CGI still works
echo -e "${YELLOW}Test 3: CGI functionality (verify not broken)${NC}"
if [ -f "./YoupiBanane/youpi.bla" ]; then
    status=$(curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:$PORT/directory/youpi.bla)
    echo -n "  POST /directory/youpi.bla: $status ... "
    if [ "$status" = "200" ]; then
        echo -e "${GREEN}✅ PASS (CGI still works)${NC}"
    else
        echo -e "${YELLOW}⚠️  Got $status (check if CGI is configured)${NC}"
    fi
else
    echo -e "${YELLOW}  ⊘ Skipped (YoupiBanane/youpi.bla not found)${NC}"
fi
echo ""

# Summary
echo -e "${CYAN}════════════════════════════════════════════════════════════${NC}"
echo -e "${CYAN}  SUMMARY${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════════════${NC}"
echo ""

if [ "$status" = "405" ]; then
    echo -e "${GREEN}✅ FIX VERIFIED SUCCESSFULLY${NC}"
    echo ""
    echo "The ubuntu_tester should now pass the following test:"
    echo "  Test POST http://localhost:$PORT/ with a size of 0"
    echo ""
    echo "Next step: Run the official tester:"
    echo "  ./testers/ubuntu_tester http://localhost:$PORT"
else
    echo -e "${RED}❌ FIX NOT APPLIED CORRECTLY${NC}"
    echo ""
    echo "POST / is returning $status instead of 405"
    echo "Please:"
    echo "  1. Copy Server.cpp.fixed to src/Server.cpp"
    echo "  2. Run: make re"
    echo "  3. Restart server and run this script again"
fi

echo ""
