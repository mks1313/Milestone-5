#!/bin/bash

echo "═══════════════════════════════════════════════════════════════════"
echo "  DIAGNÓSTICO COMPLETO: POST / con Content-Length: 0"
echo "═══════════════════════════════════════════════════════════════════"
echo ""

PORT=8080
HOST=localhost

# Verificar servidor
if ! nc -z $HOST $PORT 2>/dev/null; then
    echo "❌ Servidor no está corriendo en $HOST:$PORT"
    echo ""
    echo "Inicia el servidor en otra terminal:"
    echo "  ./bin/webserv config/webserv.conf"
    echo ""
    exit 1
fi

echo "✅ Servidor detectado en $HOST:$PORT"
echo ""

# ===========================================================================
# Test 1: GET / (este funciona)
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 1: GET / (debería funcionar)"
echo "───────────────────────────────────────────────────────────────────"

RESPONSE=$(curl -i -s http://$HOST:$PORT/ 2>&1)
HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP/" | head -1 | awk '{print $2}')

echo "Status Code: $HTTP_CODE"
if [ "$HTTP_CODE" = "200" ]; then
    echo "✅ GET / funciona correctamente"
else
    echo "❌ GET / devuelve código inesperado: $HTTP_CODE"
fi
echo ""

# ===========================================================================
# Test 2: POST / con Content-Length: 0 (RAW con nc)
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 2: POST / con Content-Length: 0 (usando nc - RAW)"
echo "───────────────────────────────────────────────────────────────────"
echo ""
echo "REQUEST enviado:"
echo "POST / HTTP/1.1"
echo "Host: $HOST:$PORT"
echo "Content-Length: 0"
echo ""
echo ""

# Enviar request RAW con nc
echo -ne "POST / HTTP/1.1\r\nHost: $HOST:$PORT\r\nContent-Length: 0\r\n\r\n" | nc -w 2 $HOST $PORT > /tmp/nc_response.txt 2>&1

echo "RESPONSE recibido:"
cat /tmp/nc_response.txt
echo ""

if [ -s /tmp/nc_response.txt ]; then
    HTTP_CODE=$(cat /tmp/nc_response.txt | grep "HTTP/" | head -1 | awk '{print $2}')
    echo "Status Code: ${HTTP_CODE:-'NO_RESPONSE'}"
    
    case $HTTP_CODE in
        200)
            echo "⚠️  Servidor devuelve 200 - Pero config dice solo GET permitido"
            ;;
        204)
            echo "ℹ️  Servidor devuelve 204 No Content"
            ;;
        405)
            echo "✅ Servidor devuelve 405 Method Not Allowed (correcto según HTTP)"
            echo "   PERO el ubuntu_tester dice 'bad status code'"
            ;;
        400)
            echo "❌ Servidor devuelve 400 Bad Request"
            ;;
        "")
            echo "❌ NO HAY RESPUESTA - El servidor no está respondiendo"
            echo "   Esto explica por qué no hay logs del POST"
            ;;
        *)
            echo "❌ Código inesperado: $HTTP_CODE"
            ;;
    esac
else
    echo "❌ NO HAY RESPUESTA DEL SERVIDOR"
    echo "   El socket se cierra sin responder"
fi
echo ""

# ===========================================================================
# Test 3: POST / con curl
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 3: POST / con curl"
echo "───────────────────────────────────────────────────────────────────"

RESPONSE=$(curl -i -s -X POST -H "Content-Length: 0" http://$HOST:$PORT/ 2>&1)
HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP/" | head -1 | awk '{print $2}')

echo "Status Code: ${HTTP_CODE:-'NO_RESPONSE'}"
echo ""
echo "Headers de respuesta:"
echo "$RESPONSE" | head -10
echo ""

# ===========================================================================
# Test 4: Simulando exactamente el ubuntu_tester
# ===========================================================================
echo "───────────────────────────────────────────────────────────────────"
echo "Test 4: POST / exactamente como ubuntu_tester"
echo "───────────────────────────────────────────────────────────────────"

# El tester dice "with a size of 0", probablemente envía:
echo "REQUEST (simulado ubuntu_tester):"
echo "POST / HTTP/1.1"
echo "Host: $HOST"
echo "Content-Length: 0"
echo "Connection: close"
echo ""
echo ""

echo -ne "POST / HTTP/1.1\r\nHost: $HOST\r\nContent-Length: 0\r\nConnection: close\r\n\r\n" | nc -w 3 $HOST $PORT > /tmp/tester_sim.txt 2>&1

echo "RESPONSE:"
cat /tmp/tester_sim.txt
echo ""

if [ -s /tmp/tester_sim.txt ]; then
    HTTP_CODE=$(cat /tmp/tester_sim.txt | grep "HTTP/" | head -1 | awk '{print $2}')
    echo "Status Code: ${HTTP_CODE:-'NO_RESPONSE'}"
else
    echo "❌ NO HAY RESPUESTA"
fi
echo ""

# ===========================================================================
# ANÁLISIS FINAL
# ===========================================================================
echo "═══════════════════════════════════════════════════════════════════"
echo "  ANÁLISIS Y RECOMENDACIONES"
echo "═══════════════════════════════════════════════════════════════════"
echo ""

# Verificar logs del servidor
echo "Busca en los logs del servidor:"
echo "  - ¿Aparece algún log del POST?"
echo "  - ¿Hay algún error o excepción?"
echo "  - ¿Se cierra la conexión antes de procesar?"
echo ""

# Cleanup
rm -f /tmp/nc_response.txt /tmp/tester_sim.txt

echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "SIGUIENTE PASO:"
echo "  Copia el output de este script Y los logs del servidor webserv"
echo "  para ver exactamente qué está pasando."
echo ""
